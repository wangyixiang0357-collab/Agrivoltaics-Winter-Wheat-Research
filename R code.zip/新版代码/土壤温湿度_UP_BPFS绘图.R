# -*- coding: UTF-8 -*-
# ============================================================
# 土壤温湿度时间序列绘图
# 输出 4 张独立图片，不进行拼接：
# 土壤温度-UP、土壤温度-BP+FS、土壤含水量-UP、土壤含水量-BP+FS。
#
# BP+FS 图的数据组成：
# CKBP、FBP、MFBP、OFBP，以及无光伏板对照 FS。
# ============================================================

# 首次运行时安装所需包：
# install.packages(c("ggplot2", "dplyr", "tidyr", "svglite", "ragg"))

library(ggplot2)
library(dplyr)
library(tidyr)

# ---------- 1. 文件路径 ----------
data_file <- "C:/Users/Yixiang Wang/Desktop/项目区气象数据/土壤温湿度.csv"
output_dir <- file.path(dirname(data_file), "土壤温湿度图片")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# ---------- 2. 施肥处理颜色与顺序 ----------
fertilizer_colors <- c(
  "CK" = "#8C8C8C",
  "F"  = "#0072B2",
  "MF" = "#009E73",
  "OF" = "#E66101",
  "FS" = "#F0E442"
)

fertilizer_levels <- c("CK", "F", "MF", "OF", "FS")

# 与前述微环境折线图保持一致：线较细，点适当增大。
time_line_width <- 0.52
time_point_size <- 1.20

# ---------- 3. 手动控制纵坐标 ----------
# 同一指标的 UP 与 BP+FS 使用相同纵坐标，便于直接比较。
# 如后续数据范围变化，只需修改这里的 limits 和 breaks。
soil_temp_limits <- c(5, 32)
soil_temp_breaks <- c(5, 10, 15, 20, 25, 30)

soil_water_limits <- c(4, 16)
soil_water_breaks <- c(4, 7, 10, 13, 16)

# ---------- 4. 读取两行表头的 CSV ----------
dat <- read.csv(
  data_file,
  skip = 2,
  header = FALSE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  na.strings = c("", "NA")
)

if (ncol(dat) != 19) {
  stop(
    paste0(
      "CSV 应包含 19 列：日期、9 列土壤温度和 9 列土壤含水量；",
      "当前读取到 ", ncol(dat), " 列。"
    )
  )
}

sample_codes <- c(
  "CKUP", "CKBP",
  "FUP", "FBP",
  "OFUP", "OFBP",
  "MFUP", "MFBP",
  "FS"
)

names(dat) <- c(
  "Date",
  paste0("Temperature_", sample_codes),
  paste0("Water_", sample_codes)
)

dat <- dat %>%
  mutate(
    Date = as.Date(Date, format = "%Y/%m/%d"),
    across(
      starts_with("Temperature_"),
      ~ suppressWarnings(as.numeric(trimws(.x)))
    ),
    across(
      starts_with("Water_"),
      ~ suppressWarnings(
        as.numeric(gsub("%", "", trimws(.x), fixed = TRUE))
      )
    )
  ) %>%
  arrange(Date)

if (anyNA(dat$Date)) {
  stop("部分日期无法按 YYYY/MM/DD 格式识别，请检查 CSV。")
}

if (anyDuplicated(dat$Date)) {
  stop("日期存在重复记录，请先确认是否需要按日求均值。")
}

measurement_data <- dat %>% select(-Date)

if (anyNA(measurement_data)) {
  warning(
    "测定值中存在缺失或无法转换为数值的单元格；",
    "这些缺失值会由 ggplot2 明确提示并跳过。"
  )
}

if (any(!is.finite(as.matrix(measurement_data)), na.rm = TRUE)) {
  stop("测定值中存在 Inf 或 -Inf，请先检查原始 CSV。")
}

# ---------- 5. 明确处理与位置的对应关系 ----------
sample_key <- data.frame(
  Sample_code = sample_codes,
  Treatment = c("CK", "CK", "F", "F", "OF", "OF", "MF", "MF", "FS"),
  Position = c("UP", "BP", "UP", "BP", "UP", "BP", "UP", "BP", "FS"),
  stringsAsFactors = FALSE
)

soil_temperature_long <- dat %>%
  select(Date, starts_with("Temperature_")) %>%
  pivot_longer(
    cols = -Date,
    names_to = "Sample_code",
    values_to = "Value",
    names_prefix = "Temperature_"
  ) %>%
  left_join(sample_key, by = "Sample_code") %>%
  mutate(
    Metric = "Soil temperature",
    Treatment = factor(Treatment, levels = fertilizer_levels)
  )

soil_water_long <- dat %>%
  select(Date, starts_with("Water_")) %>%
  pivot_longer(
    cols = -Date,
    names_to = "Sample_code",
    values_to = "Value",
    names_prefix = "Water_"
  ) %>%
  left_join(sample_key, by = "Sample_code") %>%
  mutate(
    Metric = "Soil water content",
    Treatment = factor(Treatment, levels = fertilizer_levels)
  )

if (
  anyNA(soil_temperature_long$Treatment) ||
  anyNA(soil_temperature_long$Position) ||
  anyNA(soil_water_long$Treatment) ||
  anyNA(soil_water_long$Position)
) {
  stop("处理或位置映射失败，请检查 sample_codes 与 sample_key。")
}

# 保留全部原始日观测，另存为可追溯的绘图源数据。
source_data <- bind_rows(
  soil_temperature_long,
  soil_water_long
) %>%
  arrange(Metric, Position, Treatment, Date)

write.csv(
  source_data,
  file = file.path(output_dir, "土壤温湿度_绘图源数据.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

# ---------- 6. 形成 UP 与 BP+FS 两类绘图数据 ----------
# UP 图：CKUP、FUP、MFUP、OFUP。
temperature_up <- soil_temperature_long %>%
  filter(Position == "UP")

water_up <- soil_water_long %>%
  filter(Position == "UP")

# BP+FS 图：CKBP、FBP、MFBP、OFBP，以及 FS。
temperature_bp_fs <- soil_temperature_long %>%
  filter(Position == "BP" | Treatment == "FS")

water_bp_fs <- soil_water_long %>%
  filter(Position == "BP" | Treatment == "FS")

# ---------- 7. 检查手动纵坐标是否覆盖全部有效值 ----------
check_axis_limits <- function(values, limits, plot_name) {
  value_range <- range(values, na.rm = TRUE)

  if (
    value_range[1] < limits[1] ||
    value_range[2] > limits[2]
  ) {
    stop(
      paste0(
        plot_name, " 的数据范围为 ",
        paste(round(value_range, 2), collapse = "–"),
        "，超出了手动纵坐标 ",
        paste(limits, collapse = "–"),
        "；请修改第 3 节的 limits。"
      )
    )
  }
}

check_axis_limits(
  soil_temperature_long$Value,
  soil_temp_limits,
  "土壤温度"
)

check_axis_limits(
  soil_water_long$Value,
  soil_water_limits,
  "土壤含水量"
)

# ---------- 8. 参考图风格 ----------
theme_reference <- theme_classic(
  base_size = 12,
  base_family = "Arial"
) +
  theme(
    panel.border = element_rect(
      colour = "black",
      fill = NA,
      linewidth = 0.75
    ),
    axis.line = element_blank(),
    axis.ticks = element_line(
      colour = "black",
      linewidth = 0.65
    ),
    axis.ticks.length = grid::unit(-0.07, "cm"),
    axis.title = element_text(
      colour = "black",
      face = "bold",
      size = 13
    ),
    axis.text = element_text(
      colour = "black",
      face = "bold",
      size = 10
    ),
    axis.text.x = element_text(
      size = 8,
      angle = 45,
      hjust = 1,
      margin = margin(t = 7)
    ),
    axis.text.y = element_text(
      margin = margin(r = 7)
    ),
    legend.title = element_blank(),
    legend.text = element_text(
      colour = "black",
      face = "bold",
      size = 9
    ),
    legend.key = element_blank(),
    legend.background = element_rect(
      fill = "white",
      colour = "black",
      linewidth = 0.35
    ),
    legend.direction = "horizontal",
    legend.key.width = grid::unit(0.45, "cm"),
    legend.spacing.x = grid::unit(0.08, "cm"),
    legend.margin = margin(3, 4, 3, 4),
    plot.title = element_text(
      colour = "black",
      face = "bold",
      size = 12,
      hjust = 0
    ),
    plot.margin = margin(8, 10, 8, 8)
  )

# 处理图例统一放在绘图区内部左上角。
# 使用版本判断，同时兼容 ggplot2 3.5.0 之前和之后的写法。
soil_legend_position <- c(0.02, 0.98)
soil_legend_justification <- c(0, 1)

theme_legend_inside <- function(position, justification) {
  if (utils::packageVersion("ggplot2") >= "3.5.0") {
    theme(
      legend.position = "inside",
      legend.position.inside = position,
      legend.justification = justification
    )
  } else {
    theme(
      legend.position = position,
      legend.justification = justification
    )
  }
}

common_date_scale <- scale_x_date(
  date_breaks = "15 days",
  date_labels = "%y/%m/%d",
  expand = expansion(mult = c(0.01, 0.01))
)

# ---------- 9. 通用单图函数 ----------
make_soil_plot <- function(
  plot_data,
  y_label,
  y_limits,
  y_breaks,
  panel_title
) {
  ggplot(
    plot_data,
    aes(
      x = Date,
      y = Value,
      colour = Treatment,
      group = Treatment
    )
  ) +
    geom_line(
      linewidth = time_line_width,
      lineend = "round"
    ) +
    geom_point(
      size = time_point_size,
      shape = 16,
      stroke = 0
    ) +
    scale_colour_manual(
      values = fertilizer_colors,
      breaks = fertilizer_levels,
      drop = TRUE
    ) +
    common_date_scale +
    scale_y_continuous(
      limits = y_limits,
      breaks = y_breaks,
      minor_breaks = NULL,
      expand = expansion(mult = c(0, 0))
    ) +
    labs(
      x = "Date",
      y = y_label,
      title = panel_title
    ) +
    guides(
      colour = guide_legend(
        nrow = 1,
        byrow = TRUE,
        override.aes = list(
          linewidth = 1.0,
          size = 2.2
        )
      )
    ) +
    theme_reference +
    theme_legend_inside(
      position = soil_legend_position,
      justification = soil_legend_justification
    )
}

# ---------- 10. 分别建立 4 张图片 ----------
p_soil_temperature_up <- make_soil_plot(
  plot_data = temperature_up,
  y_label = expression("Soil temperature (" * degree * "C)"),
  y_limits = soil_temp_limits,
  y_breaks = soil_temp_breaks,
  panel_title = "UP"
)

p_soil_temperature_bp_fs <- make_soil_plot(
  plot_data = temperature_bp_fs,
  y_label = expression("Soil temperature (" * degree * "C)"),
  y_limits = soil_temp_limits,
  y_breaks = soil_temp_breaks,
  panel_title = "BP + FS"
)

p_soil_water_up <- make_soil_plot(
  plot_data = water_up,
  y_label = "Soil water content (%)",
  y_limits = soil_water_limits,
  y_breaks = soil_water_breaks,
  panel_title = "UP"
)

p_soil_water_bp_fs <- make_soil_plot(
  plot_data = water_bp_fs,
  y_label = "Soil water content (%)",
  y_limits = soil_water_limits,
  y_breaks = soil_water_breaks,
  panel_title = "BP + FS"
)

# ---------- 11. 分别导出，不拼接 ----------
save_single_plot <- function(
  plot_object,
  filename,
  width_mm = 125,
  height_mm = 95,
  dpi = 600
) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  svglite::svglite(
    file = file.path(output_dir, paste0(filename, ".svg")),
    width = width_in,
    height = height_in,
    bg = "white"
  )
  print(plot_object)
  grDevices::dev.off()

  grDevices::cairo_pdf(
    filename = file.path(output_dir, paste0(filename, ".pdf")),
    width = width_in,
    height = height_in,
    family = "Arial",
    bg = "white",
    onefile = TRUE
  )
  print(plot_object)
  grDevices::dev.off()

  ragg::agg_tiff(
    filename = file.path(output_dir, paste0(filename, ".tiff")),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    compression = "lzw",
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()

  ragg::agg_png(
    filename = file.path(output_dir, paste0(filename, ".png")),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()
}

save_single_plot(
  p_soil_temperature_up,
  "01_土壤温度_UP"
)

save_single_plot(
  p_soil_temperature_bp_fs,
  "02_土壤温度_BP+FS"
)

save_single_plot(
  p_soil_water_up,
  "03_土壤含水量_UP"
)

save_single_plot(
  p_soil_water_bp_fs,
  "04_土壤含水量_BP+FS"
)

# 在 RStudio 中运行脚本后，可分别查看 4 张图。
if (interactive()) {
  print(p_soil_temperature_up)
  print(p_soil_temperature_bp_fs)
  print(p_soil_water_up)
  print(p_soil_water_bp_fs)
}
