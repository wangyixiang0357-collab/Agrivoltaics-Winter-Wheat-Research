# ============================================================================
# 三年产量与 2026 年三指标：原色保留、共享图例、panel 对齐
#
# 输入为本项目三因素/Tukey 分析输出的既有结果，柱高=原始均值，误差线=样本 SD；
# 不在本绘图脚本重新计算检验或字母。三个指标均使用原 PDF 的柱形颜色：
# CK #8C8C8C，F #0072B2，OF #E66101，MF #009E73，FS #F0E442。
# UP：白色填充，施肥色边框；BP：施肥色填充及边框；FS：黄色填充，#595959 边框。
# 位置图例中灰色方块仅表示 BP 为实心，不表示 BP 的柱子统一填灰色。
# 原 PDF 的 P/F/P×F 星号属于旧模型；本脚本不复制旧模型显著性。
#
# 仅输出三年（2024-2026）产量独立图，不再绘制拼接图。
# 三年产量共用 Y 轴：固定 0-5000、刻度间距 1000；
# 轴线包围的内部绘图区（panel）长宽比固定 1:1。每次输出到新的时间戳目录。
# ============================================================================

# 缺少包时手动安装一次；不自动下载安装：
# install.packages(c("ggplot2", "gtable", "systemfonts", "svglite", "ragg"))
# svglite、systemfonts、ragg 为可选包；缺失时分别使用 Cairo SVG、字体提示、Cairo 栅格设备。

INPUT_CSV <- paste0(
  "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/",
  "小麦光合生理/产量与生物量双因素混合模型_三指标结果/",
  "三年三因素_Tukey_Hedgesg_结果/01_各年处理均值SD_Tukey字母.csv"
)
OUTPUT_ROOT <- file.path(dirname(INPUT_CSV), "绘图_保色_新输出")
YIELD_LIMIT <- 5000          # 三年产量统一 Y 轴上限（固定 0-5000）
YIELD_BREAKS_BY <- 1000      # Y 轴刻度间距
FONT_FAMILY <- "Arial"
AXIS_PT <- 8
TITLE_PT <- 9
LETTER_PT <- 7
PANEL_TAG_PT <- 10
SINGLE_SIZE_MM <- c(width = 88.9, height = 76.2)
COMPOSITE_SIZE_MM <- c(width = 177.8, height = 76.2)
DPI <- 600L
FORMATS <- c("pdf", "svg", "png", "tiff")
SVG_TEXT_MODE <- "auto"     # auto：优先可编辑 SVG，svglite 加载失败时使用路径 SVG
                            # editable：必须加载 svglite；outline：使用 Cairo 路径 SVG

PALETTE <- c(CK = "#8C8C8C", F = "#0072B2", OF = "#E66101",
             MF = "#009E73", FS = "#F0E442")
FERTILIZER_LEVELS <- c("CK", "F", "OF", "MF", "FS")
TREATMENTS <- c("CK_UP", "CK_BP", "F_UP", "F_BP", "OF_UP", "OF_BP",
                "MF_UP", "MF_BP", "FS")

probe_package <- function(package) {
  tryCatch({
    loadNamespace(package)
    list(ok = TRUE, error = NULL)
  }, error = function(e) list(ok = FALSE, error = conditionMessage(e)))
}

require_packages <- function(packages) {
  checks <- setNames(lapply(packages, probe_package), packages)
  bad <- names(checks)[!vapply(checks, function(x) x$ok, logical(1))]
  if (length(bad)) {
    details <- vapply(bad, function(pkg) paste0(pkg, ": ", checks[[pkg]]$error), character(1))
    stop("当前 R 会话无法加载必需包：\n", paste(details, collapse = "\n"),
      "\n当前 R：", R.version.string, "\n当前库路径：", paste(.libPaths(), collapse = "; "),
      "\n请检查以上具体错误，或在当前 R 会话安装：install.packages(c(",
      paste(sprintf('"%s"', bad), collapse = ", "), "))", call. = FALSE)
  }
}

resolve_svg_mode <- function(formats = FORMATS, requested = SVG_TEXT_MODE) {
  if (!"svg" %in% formats) return("not_requested")
  if (!requested %in% c("auto", "editable", "outline"))
    stop("SVG_TEXT_MODE 必须为 auto、editable 或 outline。")
  if (requested == "outline") {
    if (!capabilities("cairo")) stop("当前 R 不支持 Cairo SVG，无法输出路径 SVG。")
    return("outline")
  }
  check <- probe_package("svglite")
  if (check$ok) return("editable")
  detail <- paste0("当前 R 会话无法加载 svglite：", check$error,
    "\n当前 R：", R.version.string, "\n当前库路径：", paste(.libPaths(), collapse = "; "))
  if (requested == "editable") stop(detail,
    "\nSVG_TEXT_MODE='editable' 需要能够加载 svglite；请检查依赖或改为 auto。", call. = FALSE)
  if (!capabilities("cairo")) stop(detail,
    "\n当前 R 也不支持 Cairo SVG；可从 FORMATS 删除 svg，并检查其他导出设备是否可用。", call. = FALSE)
  warning(detail, "\n将使用 R 自带 Cairo SVG 输出矢量路径；文字可能无法作为文本编辑。",
    call. = FALSE)
  "outline"
}

read_summary <- function(path = INPUT_CSV) {
  if (!file.exists(path)) stop("找不到均值与字母 CSV：", path,
    "\n请先运行三年三因素分析脚本。", call. = FALSE)
  # 避免在 Excel 已修改后继续绘制旧均值或旧字母。
  provenance <- file.path(dirname(path), "12_方法与版本.txt")
  if (file.exists(provenance)) {
    log <- readLines(provenance, encoding = "UTF-8", warn = FALSE)
    hash_line <- grep("^Input MD5: ", log, value = TRUE)
    input_line <- grep("^Input: ", log, value = TRUE)
    if (length(hash_line) == 1L && length(input_line) == 1L) {
      old_hash <- sub("^Input MD5: ", "", hash_line)
      workbook <- sub("^Input: ", "", input_line)
      if (file.exists(workbook)) {
        actual_hash <- unname(tools::md5sum(workbook))
        if (!is.na(actual_hash) && actual_hash != old_hash)
          stop("Excel 已发生变化：请先重新运行统计脚本，再重新绘图。")
        if (is.na(actual_hash)) warning("无法校验工作簿哈希，请确认绘图汇总来自当前 Excel。")
      } else warning("找不到统计记录中的源 Excel，无法校验绘图汇总是否为最新。")
    } else warning("统计记录缺少源文件或哈希，无法校验绘图汇总是否为最新。")
  } else warning("缺少统计来源记录，无法校验绘图汇总是否为最新。")
  d <- utils::read.csv(path, fileEncoding = "UTF-8-BOM", check.names = FALSE,
    stringsAsFactors = FALSE, na.strings = c("", "NA"))
  names(d) <- sub("^\\ufeff", "", names(d))
  required <- c("Indicator", "Year", "Treatment", "Position", "Fertilization", "n", "Mean", "SD", "Letter")
  if (!all(required %in% names(d))) stop("输入 CSV 缺少字段：",
    paste(setdiff(required, names(d)), collapse = ", "), call. = FALSE)
  for (nm in c("Indicator", "Treatment", "Position", "Fertilization", "Letter"))
    d[[nm]] <- trimws(as.character(d[[nm]]))
  d$Letter <- gsub("[[:space:]]+", "", d$Letter)
  for (nm in c("Year", "n", "Mean", "SD")) {
    original <- d[[nm]]
    d[[nm]] <- suppressWarnings(as.numeric(original))
    if (any(!is.na(original) & !is.finite(d[[nm]]))) stop(nm, " 存在非数值。")
  }
  if (anyNA(d[required])) stop("输入存在缺失值；不能创建未提供的柱高、误差线或字母。")
  if (any(d$n < 2 | d$n != floor(d$n)) || any(d$SD < 0) || any(d$Mean < 0) ||
      any(!nzchar(d$Letter))) stop("样本数、均值、SD 或字母不符合绘图要求。")
  if (any(d$Mean - d$SD < 0)) stop("存在均值−SD低于零，无法在从零起始的柱图完整显示；请核对数据。")
  expected_position <- ifelse(d$Treatment == "FS", "FS", sub("^.*_", "", d$Treatment))
  expected_fertilizer <- ifelse(d$Treatment == "FS", "FS", sub("_.*$", "", d$Treatment))
  if (any(!d$Treatment %in% TREATMENTS) ||
      any(d$Position != expected_position) || any(d$Fertilization != expected_fertilizer))
    stop("处理、位置和施肥列编码不一致。")
  if (anyDuplicated(d[c("Indicator", "Year", "Treatment")])) stop("存在重复的 指标×年份×处理 行。")
  expected <- data.frame(Indicator = c("Yield", "Yield", "Yield", "Biomass", "N"),
                         Year = c(2024, 2025, 2026, 2026, 2026))
  for (j in seq_len(nrow(expected))) {
    s <- d[d$Indicator == expected$Indicator[j] & d$Year == expected$Year[j], , drop = FALSE]
    if (nrow(s) != 9L || !setequal(s$Treatment, TREATMENTS)) stop(
      expected$Year[j], " 年 ", expected$Indicator[j], " 必须有九个处理的均值、SD 和字母。")
    if (!grepl("a", s$Letter[which.max(s$Mean)])) stop(
      expected$Year[j], " 年 ", expected$Indicator[j], " 的最大均值未包含字母 a，请核对分析结果。")
  }
  d
}

# 保留零基线，优先为误差线和文字留白。产量可在所有年份共享 Y 上限。
get_limit <- function(s) {
  upper <- max(s$Mean + s$SD)
  if (!is.finite(upper) || upper <= 0) stop("无法从均值和 SD 确定正的 Y 轴范围。")
  candidate <- pretty(c(0, upper * 1.25), n = 5)
  max(candidate[candidate >= upper * 1.16])
}

make_panel <- function(s, metric, year, tag = NULL, limit) {
  s <- s[s$Indicator == metric & s$Year == year, , drop = FALSE]
  s <- s[match(TREATMENTS, s$Treatment), , drop = FALSE]
  if (nrow(s) != 9L || anyNA(s$Treatment)) stop("图中缺少九处理之一。")
  s$x <- match(s$Fertilization, FERTILIZER_LEVELS) +
    ifelse(s$Position == "UP", -.18, ifelse(s$Position == "BP", .18, 0))
  s$label_y <- s$Mean + s$SD + limit * .035
  # 当同一施肥组中 UP/BP 字母的高度相近时，将较高的字母上移；只改变文字位置。
  for (f in FERTILIZER_LEVELS[1:4]) {
    ii <- which(s$Fertilization == f)
    if (length(ii) == 2L && abs(diff(s$label_y[ii])) < limit * .055) {
      lo <- ii[which.min(s$label_y[ii])]
      hi <- setdiff(ii, lo)
      s$label_y[hi] <- max(s$label_y[hi], s$label_y[lo] + limit * .055)
    }
  }
  if (max(s$label_y) + limit * .045 > limit)
    stop(metric, " ", year, " 年：显著性字母可能被裁切，请增大 Y 轴上限。")
  fill <- setNames(ifelse(s$Position == "UP", "#FFFFFF", unname(PALETTE[s$Fertilization])), s$Treatment)
  edge <- setNames(ifelse(s$Fertilization == "FS", "#595959", unname(PALETTE[s$Fertilization])), s$Treatment)
  # 2024/2025 源数据没有可核实的单位及面积换算；2026 单位沿用原图，亦需核实。
  y_labels <- list(Yield = if (year == 2026) expression("Yield"~(kg~ha^{-1})) else "Yield",
    Biomass = expression("Aboveground biomass"~(kg~ha^{-1})),
    N = expression("Grain N accumulation"~(kg~ha^{-1})))
  ggplot2::ggplot(s, ggplot2::aes(x = x, y = Mean)) +
    ggplot2::geom_col(ggplot2::aes(fill = Treatment, colour = Treatment),
      width = .32, linewidth = .45, show.legend = FALSE) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = Mean - SD, ymax = Mean + SD),
      width = .12, linewidth = .4, colour = "black") +
    ggplot2::geom_text(ggplot2::aes(y = label_y, label = Letter), vjust = 0,
      family = FONT_FAMILY, fontface = "bold", size = LETTER_PT / ggplot2::.pt) +
    ggplot2::scale_fill_manual(values = fill, drop = FALSE) +
    ggplot2::scale_colour_manual(values = edge, drop = FALSE) +
    ggplot2::scale_x_continuous(breaks = 1:5, labels = FERTILIZER_LEVELS,
      limits = c(.4, 5.6), expand = ggplot2::expansion(mult = 0)) +
    ggplot2::scale_y_continuous(breaks = seq(0, limit, by = YIELD_BREAKS_BY),
      expand = ggplot2::expansion(mult = 0)) +
    ggplot2::coord_cartesian(ylim = c(0, limit), clip = "on") +
    ggplot2::labs(x = "Fertilization", y = y_labels[[metric]], tag = tag) +
    ggplot2::theme_classic(base_family = FONT_FAMILY, base_size = AXIS_PT) +
    ggplot2::theme(axis.line = ggplot2::element_blank(),
      aspect.ratio = 1,   # 轴线包围的内部绘图区长宽比 1:1
      panel.border = ggplot2::element_rect(fill = NA, colour = "black", linewidth = .3),
      axis.ticks = ggplot2::element_line(colour = "black", linewidth = .3),
      axis.ticks.length = grid::unit(-1.2, "mm"),
      axis.ticks.x = ggplot2::element_blank(),
      axis.text = ggplot2::element_text(colour = "black", face = "plain", size = AXIS_PT),
      axis.title = ggplot2::element_text(colour = "black", face = "plain", size = TITLE_PT),
      axis.title.y = ggplot2::element_text(margin = ggplot2::margin(r = 3)),
      plot.tag = ggplot2::element_text(size = PANEL_TAG_PT, face = "bold"),
      plot.tag.position = c(.02, .99), legend.position = "none",
      plot.margin = ggplot2::margin(7, 4, 3, 4, unit = "mm"))
}

align_panels <- function(plots) {
  g <- lapply(plots, ggplot2::ggplotGrob)
  if (length(unique(vapply(g, function(x) length(x$widths), integer(1)))) != 1L ||
      length(unique(vapply(g, function(x) length(x$heights), integer(1)))) != 1L)
    stop("各 panel 布局结构不一致，无法安全对齐。")
  widths <- do.call(grid::unit.pmax, lapply(g, `[[`, "widths"))
  heights <- do.call(grid::unit.pmax, lapply(g, `[[`, "heights"))
  for (i in seq_along(g)) { g[[i]]$widths <- widths; g[[i]]$heights <- heights }
  g
}

draw_position_legend <- function() {
  x <- grid::unit(.5, "npc") + grid::unit(c(-27, -8, 15), "mm")
  for (i in 1:3) {
    grid::grid.rect(x = x[i], width = grid::unit(3, "mm"), height = grid::unit(3, "mm"),
      gp = grid::gpar(fill = c("white", PALETTE["CK"], PALETTE["FS"])[i],
                      col = "#333333", lwd = 1))
    grid::grid.text(c("UP (open)", "BP (filled)", "FS")[i],
      x = x[i] + grid::unit(2.8, "mm"), just = "left",
      gp = grid::gpar(fontfamily = FONT_FAMILY, fontface = "plain", fontsize = AXIS_PT))
  }
}

# 多图时各外部单元等宽，统一 gtable 宽高；图例只绘制一次并居中。
draw_aligned <- function(grobs, audit = FALSE) {
  grid::grid.newpage()
  n <- length(grobs)
  grid::pushViewport(grid::viewport(layout = grid::grid.layout(2, n,
    heights = grid::unit.c(grid::unit(1, "null"), grid::unit(7, "mm")),
    widths = grid::unit(rep(1, n), "null"))))
  on.exit(grid::popViewport(), add = TRUE)
  frames <- vector("list", n)
  for (i in seq_along(grobs)) {
    grid::pushViewport(grid::viewport(layout.pos.row = 1, layout.pos.col = i))
    grid::grid.draw(grobs[[i]])
    if (audit) {
      grid::grid.force()
      p <- grobs[[i]]$layout[grobs[[i]]$layout$name == "panel", , drop = FALSE]
      if (nrow(p) != 1L) stop("每图必须恰有一个 panel。")
      vp <- sprintf("%s.%d-%d-%d-%d", p$name, p$t, p$l, p$b, p$r)
      depth <- grid::downViewport(vp)
      lo <- grid::deviceLoc(grid::unit(0, "npc"), grid::unit(0, "npc"), valueOnly = TRUE)
      hi <- grid::deviceLoc(grid::unit(1, "npc"), grid::unit(1, "npc"), valueOnly = TRUE)
      frames[[i]] <- data.frame(Panel = i, Left_mm = lo$x * 25.4, Bottom_mm = lo$y * 25.4,
        Right_mm = hi$x * 25.4, Top_mm = hi$y * 25.4,
        Width_mm = (hi$x - lo$x) * 25.4, Height_mm = (hi$y - lo$y) * 25.4)
      grid::upViewport(depth)
    }
    grid::popViewport()
  }
  grid::pushViewport(grid::viewport(layout.pos.row = 2, layout.pos.col = seq_len(n)))
  draw_position_legend()
  grid::popViewport()
  if (audit) {
    z <- do.call(rbind, frames)
    same <- function(v) diff(range(v)) < .1
    if (n > 1 && (!same(z$Top_mm) || !same(z$Bottom_mm) || !same(z$Width_mm) ||
        !same(z$Height_mm) || (n > 2 && !same(diff(z$Left_mm)))))
      stop("实际 panel 边界/间隔未通过 0.1 mm 对齐检查。")
    return(z)
  }
  invisible(NULL)
}

export_plot <- function(grobs, destination, size, format, svg_mode = NULL) {
  path <- paste0(destination, ".", format)
  if (file.exists(path)) stop("输出文件已存在，拒绝覆盖：", path)
  wi <- unname(size["width"] / 25.4); he <- unname(size["height"] / 25.4)
  tmp <- tempfile("plot_", tmpdir = dirname(path), fileext = paste0(".", format))
  opened <- FALSE
  on.exit({if (opened) grDevices::dev.off(); if (file.exists(tmp)) unlink(tmp)}, add = TRUE)
  switch(format,
    pdf = {
      if (!capabilities("cairo")) stop("R 当前不支持 Cairo PDF。")
      grDevices::cairo_pdf(tmp, width = wi, height = he, family = FONT_FAMILY, bg = "white")
    },
    svg = {
      if (is.null(svg_mode)) svg_mode <- resolve_svg_mode("svg")
      if (identical(svg_mode, "editable")) {
        svglite::svglite(tmp, width = wi, height = he, bg = "white")
      } else if (identical(svg_mode, "outline")) {
        grDevices::svg(tmp, width = wi, height = he, family = FONT_FAMILY, bg = "white")
      } else stop("无法识别的 SVG 导出模式：", svg_mode)
    },
    png = if (requireNamespace("ragg", quietly = TRUE))
      ragg::agg_png(tmp, width = wi, height = he, units = "in", res = DPI, background = "white")
    else grDevices::png(tmp, width = wi, height = he, units = "in", res = DPI, type = "cairo", bg = "white"),
    tiff = if (requireNamespace("ragg", quietly = TRUE))
      ragg::agg_tiff(tmp, width = wi, height = he, units = "in", res = DPI, compression = "lzw", background = "white")
    else grDevices::tiff(tmp, width = wi, height = he, units = "in", res = DPI,
                         type = "cairo", compression = "lzw", bg = "white"),
    stop("未知输出格式：", format))
  opened <- TRUE
  device_size <- grDevices::dev.size("in") * 25.4
  draw_aligned(grobs)
  grDevices::dev.off(); opened <- FALSE
  if (!file.rename(tmp, path)) stop("无法保存文件（可能被其他程序占用）：", path)
  data.frame(File = basename(path), Format = format,
    Requested_width_mm = unname(size["width"]), Requested_height_mm = unname(size["height"]),
    Device_width_mm = device_size[1], Device_height_mm = device_size[2],
    Raster_DPI = ifelse(format %in% c("png", "tiff"), DPI, NA_real_),
    Font = FONT_FAMILY, SVG_text_mode = if (format == "svg") svg_mode else NA_character_,
    Bytes = file.info(path)$size, row.names = NULL)
}

run_plots <- function(input_csv = INPUT_CSV, output_root = OUTPUT_ROOT) {
  require_packages(c("ggplot2", "gtable"))
  font_check <- probe_package("systemfonts")
  if (font_check$ok) {
    if (!FONT_FAMILY %in% systemfonts::system_fonts()$family) stop("字体不可用：", FONT_FAMILY)
  } else {
    warning("当前会话无法加载 systemfonts，无法自动核验 ", FONT_FAMILY,
      " 字体。绘图设备仍会请求该字体，请检查导出文件中是否发生字体替换。\n",
      "加载原因：", font_check$error, call. = FALSE)
  }
  svg_mode <- resolve_svg_mode(FORMATS, SVG_TEXT_MODE)
  dat <- read_summary(input_csv)
  plot_specs <- data.frame(Indicator = rep("Yield", 3),
    Year = 2024:2026, tag = c("2024", "2025", "2026"))
  plots <- lapply(seq_len(nrow(plot_specs)), function(i) {
    metric <- plot_specs$Indicator[i]; year <- plot_specs$Year[i]
    limit <- YIELD_LIMIT
    make_panel(dat, metric, year, plot_specs$tag[i], limit)
  })
  names(plots) <- paste(plot_specs$Year, plot_specs$Indicator, sep = "_")
  # 统一设备和最大轴标签宽度，再把三张产量图分别放到等宽单元。
  scratch <- tempfile(fileext = ".pdf")
  grDevices::cairo_pdf(scratch, width = COMPOSITE_SIZE_MM[1] / 25.4,
    height = COMPOSITE_SIZE_MM[2] / 25.4, family = FONT_FAMILY)
  grobs <- tryCatch(align_panels(plots), finally = {grDevices::dev.off(); unlink(scratch)})
  dir.create(output_root, recursive = TRUE, showWarnings = FALSE)
  stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
  out <- file.path(output_root, stamp)
  suffix <- 1L
  while (dir.exists(out) || file.exists(out)) {
    out <- file.path(output_root, paste0(stamp, "_", suffix)); suffix <- suffix + 1L
  }
  if (!dir.create(out)) stop("无法创建新输出目录：", out)
  manifest <- list()
  for (i in seq_along(grobs)) for (fmt in FORMATS) {
    manifest[[length(manifest) + 1L]] <- export_plot(grobs[i], file.path(out, names(plots)[i]), SINGLE_SIZE_MM, fmt, svg_mode)
  }
  audit_path <- tempfile(fileext = ".pdf")
  grDevices::cairo_pdf(audit_path, width = COMPOSITE_SIZE_MM[1] / 25.4,
    height = COMPOSITE_SIZE_MM[2] / 25.4, family = FONT_FAMILY)
  audit <- tryCatch(draw_aligned(grobs, audit = TRUE),
    finally = {grDevices::dev.off(); unlink(audit_path)})
  utils::write.csv(audit, file.path(out, "绘图区尺寸对齐检查.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  utils::write.csv(do.call(rbind, manifest), file.path(out, "导出尺寸与字体.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  notes <- c("Panels: grain yield for 2024, 2025 and 2026; no composite figure.",
    "Bars: observed mean +/- sample SD; letters: input Tukey results, nine treatments per year and metric.",
    "Color values preserved: CK #8C8C8C, F #0072B2, OF #E66101, MF #009E73, FS #F0E442.",
    "UP = white fill + fertilizer-colored border; BP = fertilizer-colored fill/border; FS = yellow + #595959 border.",
    "The gray BP swatch denotes filled bars; BP bars retain their fertilizer-specific fill colors.",
    "The PDF's old P/F/PxF significance annotations are not used as current three-factor results.",
    "2024/2025 yield units and area conversions are undocumented; axes use 'Yield'.",
    "2026 kg ha^-1 labels are retained from the supplied PDF and require unit verification.",
    "Single figures: 88.9 x 76.2 mm; PNG/TIFF 600 dpi.",
    paste("Yield axis fixed 0 -", YIELD_LIMIT, ", breaks every", YIELD_BREAKS_BY,
      "; panel (axis-enclosed) aspect ratio 1:1."),
    paste("Input summary:", input_csv), paste("Input MD5:", unname(tools::md5sum(input_csv))),
    "Font: Arial; axis text 8 pt and axis titles 9 pt regular, letters 7 pt and panel tags 10 pt bold.",
    paste("SVG text mode:", svg_mode,
      if (svg_mode == "editable") "(editable text; viewer requires Arial)" else
      if (svg_mode == "outline") "(Cairo paths; text is not directly editable)" else "(SVG not requested)"),
    utils::capture.output(utils::sessionInfo()))
  writeLines(enc2utf8(notes), file.path(out, "绘图与字体说明.txt"), useBytes = TRUE)
  message("绘图输出目录：", out)
  invisible(list(directory = out, plots = plots, grobs = grobs, panel_audit = audit))
}

# 从头运行此脚本即可，分析 CSV 不被覆盖；无需重新执行 ANOVA 或效应量计算。
if (!identical(Sys.getenv("EASYPLOT_PLOT_QA"), "1")) plot_results <- run_plots()
