# ============================================================
# 生长构型与生物量形成：5个指标作为一个检验模块
# 与原六指标代码相同的分析方法，不先对重复取平均。
# 1. BP/UP × CK/F/MF/OF：三因素固定效应 ANOVA。
# 2. 每个生育期8组 Tukey：使用三因素模型共同残差均方和自由度。
# 3. 开花期8组 + FS：另外进行9组单因素 ANOVA 和 Tukey。
# 4. 三因素每个效应分别跨5指标做Holm校正；开花期5个单因素
#    总体检验另成一个Holm校正家族。Tukey字母基于Tukey校正p值，
#    不额外跨5指标进行二次Holm校正，保持与原代码一致。
# 前提：每行是独立试验单元；若为同一微区内植株/技术重复，或
# 存在光伏行内相关性，须先明确试验单元，不能直接按独立n分析。
# ============================================================

library(readxl)
library(multcompView)

# 一、可修改的设置 -------------------------------------------
input_file <- paste0(
  "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/",
  "小麦光合生理/生长与资源获取/新建 Microsoft Excel 工作表.xlsx"
)
sheet_name <- "Sheet1"
module_name <- "生长构型与生物量形成"
metrics <- c("Plant height", "Leaf area index", "Specific leaf area",
             "Aboveground biomass", "Root biomass")
alpha <- 0.05
export_excel <- FALSE  # 只在R中查看；如需导出全部结果，改为TRUE。

stages <- c("Erecting stage", "Jointing stage", "Anthesis stage")
locations <- c("BP", "UP")
fertilizations <- c("CK", "F", "MF", "OF")
groups8 <- c("BP_CK", "UP_CK", "BP_F", "UP_F",
             "BP_MF", "UP_MF", "BP_OF", "UP_OF")
groups9 <- c(groups8, "FS_FS")

# 二、读取原始记录与检查数据 ---------------------------------
raw <- as.data.frame(read_excel(input_file, sheet = sheet_name))
needed <- c("Stage", "Location", "Fertilization", metrics)
if (!all(needed %in% names(raw))) {
  stop("缺少列：", paste(setdiff(needed, names(raw)), collapse = ", "))
}
if (anyNA(raw[needed])) stop("所需列存在缺失值，请先核查，不自动删行。")
if (!all(vapply(raw[metrics], is.numeric, logical(1)))) {
  stop("5个指标必须为数值列，请检查Excel中的文本或单位。")
}
if (any(!is.finite(as.matrix(raw[metrics])))) stop("指标存在无穷值。")
if (!all(c("Block", "RowID") %in% names(raw))) {
  warning("表中没有Block/RowID，无法核实试验层级；以下分析以每行记录独立为前提。")
}
for (v in c("Stage", "Location", "Fertilization")) {
  raw[[v]] <- trimws(as.character(raw[[v]]))
}
main_id <- raw$Stage %in% stages & raw$Location %in% locations &
  raw$Fertilization %in% fertilizations
fs_id <- raw$Stage == "Anthesis stage" & raw$Location == "FS" &
  raw$Fertilization == "FS"
if (!all(main_id | fs_id)) stop("发现预期24+1个组合以外的记录，请核查。")
main <- raw[main_id, , drop = FALSE]
fs <- raw[fs_id, , drop = FALSE]
if (nrow(fs) == 0L) stop("开花期FS不存在，不能执行指定的补充检验。")

main$Stage <- factor(main$Stage, levels = stages)
main$Location <- factor(main$Location, levels = locations)
main$Fertilization <- factor(main$Fertilization, levels = fertilizations)
main$Treatment <- factor(paste(main$Location, main$Fertilization, sep = "_"),
                         levels = groups8)
cell_n <- xtabs(~ Stage + Location + Fertilization, data = main)
if (any(cell_n == 0) || length(unique(as.vector(cell_n))) != 1L) {
  stop("主模型存在空组合或重复数不相等；原代码的平衡设计分析不适用。")
}
if (any(cell_n < 2L) || nrow(fs) < 2L) stop("每组至少需要2条独立记录。")
n_cell <- unique(as.vector(cell_n))
message("主模型每组合n = ", n_cell, "；FS n = ", nrow(fs),
        "。请确认这些记录代表独立试验单元。")

# 三、辅助函数：只合并结果，不改变检验方法 -------------------
bind_results <- function(x) {
  z <- do.call(rbind, x)
  rownames(z) <- NULL
  z
}

# 从同一套Tukey p值生成字母，按原始均值降序，最高值从a开始。
# 共享字母表示未检出差异，不表示已经证明两组相等。
make_letters <- function(d, p_values, metric, stage) {
  cld <- multcompLetters2(Y ~ Treatment, p_values, d,
                         threshold = alpha)$Letters
  m <- tapply(d$Y, d$Treatment, mean)
  s <- tapply(d$Y, d$Treatment, sd)
  n <- table(d$Treatment)
  z <- data.frame(
    Module = module_name, Metric = metric, Stage = stage,
    Treatment = names(m),
    n = as.integer(n[names(m)]), Mean = as.numeric(m),
    SD = as.numeric(s[names(m)]),
    Letter = unname(cld[names(m)]), row.names = NULL
  )
  z <- z[order(-z$Mean, match(z$Treatment, levels(d$Treatment))), ]
  rownames(z) <- NULL
  if (!grepl("a", z$Letter[1], fixed = TRUE)) {
    stop(metric, " / ", stage, " 的最高均值字母未从a开始，请核查。")
  }
  z
}

# 四、全部25个组合的算术均值、样本SD和n ----------------------
group_id <- paste(raw$Stage, raw$Location, raw$Fertilization, sep = "|")
summary_table <- bind_results(lapply(
  split(seq_len(nrow(raw)), group_id), function(i) {
    z <- raw[i, , drop = FALSE]
    out <- data.frame(Module = module_name, Stage = z$Stage[1],
                      Location = z$Location[1],
                      Fertilization = z$Fertilization[1], n = nrow(z))
    for (v in metrics) {
      out[[paste0(v, "_mean")]] <- mean(z[[v]])
      out[[paste0(v, "_SD")]] <- sd(z[[v]])
    }
    out
  }
))
summary_table <- summary_table[
  order(match(summary_table$Stage, stages),
        match(summary_table$Location, c(locations, "FS")),
        match(summary_table$Fertilization, c(fertilizations, "FS"))), ]
rownames(summary_table) <- NULL

# 五、三因素ANOVA与各阶段8组Tukey ---------------------------
# 完整平衡设计：各效应正交，沿用原代码的aov顺序平方和。
# 不将FS放入三因素模型，不将生育期作为重复测量因素。
threeway_rows <- stage_tukey_rows <- stage_letter_rows <- list()
diagnostic_rows <- list()
threeway_models <- list()

for (v in metrics) {
  d <- main[c("Stage", "Location", "Fertilization", "Treatment", v)]
  names(d)[5] <- "Y"  # 指标名包含空格时也可直接拟合。
  d$Cell <- interaction(d$Stage, d$Treatment, drop = TRUE)
  fit <- aov(Y ~ Stage * Location * Fertilization, data = d,
             na.action = na.fail)
  threeway_models[[v]] <- fit
  a <- summary(fit)[[1]]
  terms <- rownames(a)[trimws(rownames(a)) != "Residuals"]
  threeway_rows[[v]] <- data.frame(
    Module = module_name, Metric = v, Term = trimws(terms),
    df1 = a[terms, "Df"], df2 = df.residual(fit),
    F = a[terms, "F value"], p = a[terms, "Pr(>F)"], row.names = NULL
  )

  # 相同模型、相同共同残差均方，计算每阶段全部28个两两比较。
  mse <- deviance(fit) / df.residual(fit)
  if (!is.finite(mse) || mse <= 0) stop(v, "的残差均方异常，无法进行Tukey。")
  se_q <- sqrt(mse / n_cell)
  q_crit <- qtukey(1 - alpha, nmeans = length(groups8),
                   df = df.residual(fit))
  for (st in stages) {
    ds <- droplevels(d[d$Stage == st, c("Y", "Treatment"), drop = FALSE])
    means <- tapply(ds$Y, ds$Treatment, mean)
    z <- bind_results(lapply(combn(groups8, 2, simplify = FALSE), function(g) {
      difference <- unname(means[g[1]] - means[g[2]])
      q <- abs(difference) / se_q
      data.frame(
        Module = module_name, Metric = v, Stage = st,
        Contrast = paste(g[1], "-", g[2]), Difference = difference,
        Lower95 = difference - q_crit * se_q,
        Upper95 = difference + q_crit * se_q,
        p_Tukey = ptukey(q, nmeans = length(groups8),
                         df = df.residual(fit), lower.tail = FALSE)
      )
    }))
    key <- paste(v, st, sep = "|")
    stage_tukey_rows[[key]] <- z
    p_stage <- z$p_Tukey
    names(p_stage) <- gsub(" - ", "-", z$Contrast, fixed = TRUE)
    stage_letter_rows[[key]] <- make_letters(ds, p_stage, v, st)
  }
  diagnostic_rows[[paste(v, "threeway")]] <- data.frame(
    Module = module_name, Metric = v, Model = "threeway",
    Shapiro_p = shapiro.test(residuals(fit))$p.value,
    Fligner_p = fligner.test(Y ~ Cell, data = d)$p.value
  )
}

threeway_anova <- bind_results(threeway_rows)
# 每个主效应/交互效应分别组成5项检验家族，不混合不同效应。
threeway_anova$p_Holm5 <- NA_real_
for (term in unique(threeway_anova$Term)) {
  i <- which(threeway_anova$Term == term)
  stopifnot(length(i) == length(metrics))
  threeway_anova$p_Holm5[i] <- p.adjust(threeway_anova$p[i], method = "holm")
}
threeway_anova$Significant_Holm5 <- threeway_anova$p_Holm5 < alpha
tukey_by_stage <- bind_results(stage_tukey_rows)
stage_letters <- bind_results(stage_letter_rows)

# 六、开花期：含FS的9组单因素ANOVA、Tukey和字母 ---------------
anthesis <- raw[raw$Stage == "Anthesis stage", needed, drop = FALSE]
anthesis$Treatment <- factor(paste(anthesis$Location, anthesis$Fertilization,
                                   sep = "_"), levels = groups9)
if (anyNA(anthesis$Treatment) || any(table(anthesis$Treatment) == 0)) {
  stop("开花期9组不完整，请核查。")
}
fs_anova_rows <- fs_tukey_rows <- fs_letter_rows <- list()
anthesis_models <- list()

for (v in metrics) {
  d <- anthesis[c("Treatment", v)]
  names(d)[2] <- "Y"
  fit <- aov(Y ~ Treatment, data = d, na.action = na.fail)
  anthesis_models[[v]] <- fit
  a <- summary(fit)[[1]]
  fs_anova_rows[[v]] <- data.frame(
    Module = module_name, Metric = v, Stage = "Anthesis stage",
    df1 = a["Treatment", "Df"], df2 = a["Residuals", "Df"],
    F = a["Treatment", "F value"], p = a["Treatment", "Pr(>F)"]
  )
  tukey_result <- TukeyHSD(fit, "Treatment", conf.level = 1 - alpha)$Treatment
  fs_tukey_rows[[v]] <- data.frame(
    Module = module_name, Metric = v, Stage = "Anthesis stage",
    Contrast = rownames(tukey_result),
    Difference = tukey_result[, "diff"], Lower95 = tukey_result[, "lwr"],
    Upper95 = tukey_result[, "upr"], p_Tukey = tukey_result[, "p adj"],
    row.names = NULL
  )
  fs_letter_rows[[v]] <- make_letters(
    d, tukey_result[, "p adj"], v, "Anthesis stage"
  )
  diagnostic_rows[[paste(v, "anthesis")]] <- data.frame(
    Module = module_name, Metric = v, Model = "anthesis_9groups",
    Shapiro_p = shapiro.test(residuals(fit))$p.value,
    Fligner_p = fligner.test(Y ~ Treatment, data = d)$p.value
  )
}
fs_anova <- bind_results(fs_anova_rows)
fs_anova$p_Holm5 <- p.adjust(fs_anova$p, method = "holm")
fs_anova$Significant_Holm5 <- fs_anova$p_Holm5 < alpha
tukey_fs <- bind_results(fs_tukey_rows)
anthesis_letters <- bind_results(fs_letter_rows)
diagnostics <- bind_results(diagnostic_rows)

# 七、在R中查看结果 ------------------------------------------
cat("\n=== 全部处理均值、样本SD和n ===\n")
print(summary_table, row.names = FALSE, digits = 6)
cat("\n=== 三因素ANOVA：原始p与每效应跨5指标Holm校正p ===\n")
print(threeway_anova, row.names = FALSE, digits = 6)
cat("\n=== 三个生育期各8组Tukey字母，均值由大到小 ===\n")
print(stage_letters, row.names = FALSE, digits = 6)
cat("\n=== 开花期含FS的9组单因素ANOVA ===\n")
print(fs_anova, row.names = FALSE, digits = 6)
cat("\n=== 开花期含FS的9组Tukey字母，均值由大到小 ===\n")
print(anthesis_letters, row.names = FALSE, digits = 6)
cat("\n=== 残差正态性、组间离散程度诊断，仅作辅助判断 ===\n")
print(diagnostics, row.names = FALSE, digits = 6)

# 全部结果同时保存在一个列表中，方便后续查看或绘图。
results <- list(
  Raw_Sheet1 = raw,
  Means_SD = summary_table,
  Three_way_ANOVA = threeway_anova,
  Stage_Tukey = tukey_by_stage,
  Stage_letters = stage_letters,
  Anthesis_ANOVA = fs_anova,
  Anthesis_Tukey = tukey_fs,
  Anthesis_letters = anthesis_letters,
  Diagnostics = diagnostics
)
# 查看全部两两比较（含均值差、Tukey同时置信区间和p值）：
# print(tukey_by_stage, row.names = FALSE)
# print(tukey_fs, row.names = FALSE)
# 绘图如包含FS，开花期应使用anthesis_letters，不混用8组字母。
# 诊断p不显著不能证明模型假设成立，应结合残差图判断，例如：
# plot(threeway_models[["Plant height"]], which = c(1, 2))

# 八、可选：运行代码时导出全部结果，不覆盖原始Excel ----------
if (export_excel) {
  library(writexl)
  output_file <- file.path(dirname(input_file),
                           "生长构型与生物量形成_五指标完整分析结果.xlsx")
  write_xlsx(results, path = output_file)
  message("全部结果已导出：", output_file)
}
