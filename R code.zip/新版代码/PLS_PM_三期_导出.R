## ============================================================
##  三期 PLS-PM 最终结果导出（DLI 版）
##  R 4.4.2 / plspm 0.4.9
##  输出：_当前DLI版_结果/20261022/
## ============================================================
suppressMessages({
  library(plspm); library(car); library(ggplot2)
})

F0  <- "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/数据表/处理后的PC scores_合并PCA.csv"
ROOT <- "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/随机森林/_当前DLI版_结果/20261022"
FIG  <- file.path(ROOT, "图")
dir.create(FIG, recursive = TRUE, showWarnings = FALSE)
B <- as.integer(Sys.getenv("PLSPM_B", "5000"))   # 正式 5000；调试可设 PLSPM_B=20

## ---------- 1. 读数据并统一列名 ----------
d0 <- read.csv(F0, check.names = FALSE, fileEncoding = "UTF-8", stringsAsFactors = FALSE)
ren <- c("Growth and biomass accumulation" = "GBA",
         "Leaf morphological variation"      = "LMV",
         "Carbon assimilation capacity"      = "CAC",
         "Light requirement and respiration" = "LRR",
         "PSII photochemical balance"        = "PPB",
         "Energy dissipation balance"        = "EDB",
         "N accumulation and root activity"  = "NARA",
         "C: N stoichiometric status"        = "CNSS",
         "Antioxidant defense and damage alleviation" = "ADDA",
         "CAT and proline response"          = "CPR",
         "Yield" = "Yld",
         "mineral nitrogen" = "MinN", "Organic N" = "OrgN", "CFU" = "CFU",
         "DLI" = "DLI", "Soil temperature" = "SoilT", "Soil water content" = "SWC")
nm <- names(d0); hit <- nm %in% names(ren); nm[hit] <- ren[nm[hit]]; names(d0) <- nm

## ---------- 2. 三期模型规格 ----------
E <- function(...) { m <- rbind(...); colnames(m) <- c("from","to"); m }

spec <- list(
  "Erecting stage" = list(
    ord = c("PV","FERT","PR","SA","PH","GR","Y"),
    blk = list(PV="DLI", FERT=c("MinN","OrgN","CFU"),
               PR=c("NARA","ADDA","CPR"), SA="LRR",
               PH=c("CAC","PPB"), GR="GBA", Y="Yld"),
    edges = E(c("PV","PR"), c("FERT","PR"), c("PV","SA"),
              c("PV","PH"), c("PR","PH"), c("SA","PH"),
              c("PR","GR"), c("PH","GR"),
              c("PV","Y"), c("FERT","Y"), c("GR","Y")),
    xy = data.frame(x=c(1,1,3,4.6,6,6,8), y=c(5.5,1,1.8,5.6,4.6,1.8,3.2),
                    row.names=c("PV","FERT","PR","SA","PH","GR","Y"))),
  "Jointing stage" = list(
    ord = c("PV","FERT","SHC","PR","SA","PH","GR","Y"),
    blk = list(PV="DLI", FERT=c("MinN","OrgN","CFU"),
               SHC=c("SoilT","SWC"), PR=c("NARA","ADDA"), SA="EDB",
               PH="CAC", GR="GBA", Y="Yld"),
    edges = E(c("PV","SHC"), c("PV","SA"), c("PV","PH"), c("PV","Y"),
              c("FERT","PR"), c("FERT","Y"),
              c("SHC","PR"), c("SHC","SA"),
              c("PR","PH"), c("PR","GR"),
              c("SA","PH"), c("PH","GR"), c("GR","Y")),
    xy = data.frame(x=c(1,1,3,3,4.6,6,6,8), y=c(5.5,1,6.8,1.8,5.6,4.6,1.8,3.2),
                    row.names=c("PV","FERT","SHC","PR","SA","PH","GR","Y"))),
  "Anthesis stage" = list(
    ord = c("PV","FERT","SHC","PR","SA","PH","GR","Y"),
    blk = list(PV="DLI", FERT=c("MinN","OrgN","CFU"),
               SHC=c("SoilT","SWC"), PR=c("NARA","ADDA","CPR"), SA="LRR",
               PH="CAC", GR="GBA", Y="Yld"),
    edges = E(c("PV","SHC"), c("PV","SA"), c("PV","PH"), c("PV","Y"),
              c("FERT","PR"), c("FERT","Y"),
              c("SHC","PR"), c("SHC","SA"),
              c("PR","PH"), c("PR","GR"),
              c("SA","PH"), c("PH","GR"), c("GR","Y")),
    xy = data.frame(x=c(1,1,3,3,4.6,6,6,8), y=c(5.5,1,6.8,1.8,5.6,4.6,1.8,3.2),
                    row.names=c("PV","FERT","SHC","PR","SA","PH","GR","Y")))
)

## ---------- 3. 工具函数 ----------
wr <- function(x, f) write.csv(x, file.path(ROOT, f), row.names = FALSE, na = "NA")
stars <- function(p) ifelse(is.na(p), "n.s.",
                    ifelse(p < 0.001, "***", ifelse(p < 0.01, "**",
                    ifelse(p < 0.05, "*", ifelse(p < 0.10, ".", "n.s.")))))

fit_stage <- function(s, dat) {
  ord <- s$ord; b <- s$blk[ord]
  modes <- setNames(ifelse(ord %in% c("FERT","SHC"), "B", "A"), ord)
  im <- matrix(0L, length(ord), length(ord), dimnames = list(ord, ord))
  for (i in seq_len(nrow(s$edges))) im[s$edges[i, "to"], s$edges[i, "from"]] <- 1L
  Dat <- do.call(cbind, lapply(ord, function(k) dat[, b[[k]], drop = FALSE]))
  colnames(Dat) <- unlist(b, use.names = FALSE)
  list(IM = im, BLK = b, MODES = modes, DAT = Dat,
       fit = plspm(Dat, im, b, modes = modes, scheme = "centroid",
                   scaled = TRUE, tol = 1e-06, maxiter = 100, boot.val = FALSE))
}

## ---------- 4. 逐期拟合 + bootstrap ----------
res_path <- list(); res_eff <- list(); res_eval <- list()
res_outer <- list(); res_glob <- list(); res_vif <- list(); plots <- list()

for (st in names(spec)) {
  s <- spec[[st]]; dat <- d0[d0$stage == st, ]
  f <- fit_stage(s, dat); fit <- f$fit; ord <- s$ord
  beta <- fit$path_coefs
  idx  <- which(f$IM == 1, arr.ind = TRUE)
  ec   <- data.frame(from = ord[idx[, 2]], to = ord[idx[, 1]], stringsAsFactors = FALSE)
  ec$beta <- beta[cbind(ec$to, ec$from)]

  ## ---- bootstrap：重抽观测行，重拟合 ----
  set.seed(20261022)
  n <- nrow(dat)
  BS <- matrix(NA_real_, B, nrow(ec))
  R2B <- matrix(NA_real_, B, length(ord), dimnames = list(NULL, ord))
  ok <- 0L
  for (bb in seq_len(B)) {
    ii <- sample.int(n, n, replace = TRUE)
    r <- tryCatch({
      fb <- fit_stage(s, dat[ii, ])
      list(p = fb$fit$path_coefs, sc = fb$fit$scores)
    }, error = function(e) NULL)
    if (is.null(r)) next
    ok <- ok + 1L
    BS[ok, ] <- r$p[cbind(ec$to, ec$from)]
    for (nd in ord) {
      pr <- ord[f$IM[nd, ] == 1]
      if (length(pr) == 0) next
      y <- r$sc[, nd]
      X <- if (length(pr) == 1) matrix(r$sc[, pr], ncol = 1) else r$sc[, pr]
      cf <- tryCatch(coef(lm(y ~ X)), error = function(e) NULL)
      if (!is.null(cf)) R2B[ok, nd] <- summary(lm(y ~ X))$r.squared
    }
  }
  BS <- BS[seq_len(ok), , drop = FALSE]; R2B <- R2B[seq_len(ok), , drop = FALSE]
  colnames(BS) <- paste0(ec$from, "->", ec$to)

  ci <- t(apply(BS, 2, quantile, c(.025, .975), na.rm = TRUE))
  se <- apply(BS, 2, sd, na.rm = TRUE)
  pv <- apply(BS, 2, function(v) {
    v <- v[is.finite(v)]
    if (!length(v)) return(NA_real_)
    min(1, 2 * min((sum(v <= 0) + 1) / (length(v) + 1),
                   (sum(v >= 0) + 1) / (length(v) + 1)))
  })
  flip <- apply(BS, 2, function(v) sum(sign(v) != sign(mean(v, na.rm = TRUE)), na.rm = TRUE))

  pt <- data.frame(stage = st, from = ec$from, to = ec$to,
                   beta = round(ec$beta, 4), boot_SE = round(se, 4),
                   CI95_lower = round(ci[, 1], 4), CI95_upper = round(ci[, 2], 4),
                   p_empirical = signif(pv, 3), n_flip = as.integer(flip),
                   B_valid = ok, stringsAsFactors = FALSE)
  pt$sig <- stars(pt$p_empirical)
  res_path[[st]] <- pt

  ## ---- 效应分解 ----
  ef <- fit$effects
  ef <- data.frame(stage = st,
                   from = sub(" -> .*", "", ef$relationships),
                   to   = sub(".* -> ", "", ef$relationships),
                   direct = round(ef$direct, 4), indirect = round(ef$indirect, 4),
                   total = round(ef$total, 4), stringsAsFactors = FALSE)
  res_eff[[st]] <- ef

  ## ---- 模型评价 ----
  is_ <- fit$inner_summary
  ud <- fit$unidim
  cons <- rownames(is_)
  pick <- function(col) as.numeric(ud[[col]][match(cons, rownames(ud))])
  ev <- data.frame(stage = st, construct = cons, type = is_$Type,
                   R2 = round(is_$R2, 4), AVE = round(is_$AVE, 4),
                   communality = round(is_$Block_Communality, 4),
                   redundancy = round(is_$Mean_Redundancy, 4),
                   cronbach_alpha = round(pick("C.alpha"), 4),
                   DG_rho = round(pick("DG.rho"), 4),
                   eig1 = round(pick("eig.1st"), 4),
                   eig2 = round(pick("eig.2nd"), 4),
                   stringsAsFactors = FALSE)
  ev$R2_boot_median <- round(apply(R2B, 2, median, na.rm = TRUE)[match(ev$construct, colnames(R2B))], 4)
  res_eval[[st]] <- ev

  ## ---- 外模型 ----
  om <- fit$outer_model
  res_outer[[st]] <- data.frame(stage = st, block = om$block, indicator = om$name,
                                mode = f$MODES[as.character(om$block)],
                                weight = round(om$weight, 4), loading = round(om$loading, 4),
                                communality = round(om$communality, 4),
                                stringsAsFactors = FALSE)

  ## ---- 总体 ----
  res_glob[[st]] <- data.frame(stage = st, n = nrow(dat), n_paths = nrow(ec),
                               GoF = round(fit$gof, 4),
                               mean_communality = round(mean(is_$Block_Communality), 4),
                               mean_R2 = round(mean(is_$R2[is_$R2 > 0]), 4),
                               B = ok, stringsAsFactors = FALSE)

  ## ---- VIF（内模型各内生节点的预测变量）----
  vf <- do.call(rbind, lapply(ord, function(nd) {
    pr <- ord[f$IM[nd, ] == 1]
    if (length(pr) < 2) return(NULL)
    dfv <- as.data.frame(fit$scores[, c(nd, pr), drop = FALSE])
    names(dfv) <- c("y", pr)
    m <- lm(reformulate(pr, "y"), data = dfv)
    v <- car::vif(m)
    data.frame(stage = st, node = nd, predictor = names(v), VIF = round(as.numeric(v), 3),
               stringsAsFactors = FALSE)
  }))
  res_vif[[st]] <- vf

  ## ---- 路径图 ----
  xy <- s$xy
  ed <- merge(ec, pt[, c("from","to","p_empirical","sig")], by = c("from","to"))
  ed$lab <- paste0(formatC(ed$beta, 2, format = "f"), ifelse(ed$sig == "n.s.", "", ed$sig))
  ed$x    <- xy[ed$from, "x"]; ed$y    <- xy[ed$from, "y"]
  ed$xend <- xy[ed$to, "x"];   ed$yend <- xy[ed$to, "y"]
  ed$dist <- sqrt((ed$xend - ed$x)^2 + (ed$yend - ed$y)^2)
  ## 直线段：标签放在中点沿法线偏移一点，保证压在线上又避开箭头
  ed$mx <- (ed$x + ed$xend) / 2 - (ed$yend - ed$y) / ed$dist * 0.16
  ed$my <- (ed$y + ed$yend) / 2 + (ed$xend - ed$x) / ed$dist * 0.16
  ed$sig01 <- !is.na(ed$p_empirical) & ed$p_empirical < 0.05
  ed$lt <- ifelse(ed$sig01, "solid", "22")
  ed$cl <- ifelse(ed$sig01, "grey20", "grey60")

  g <- ggplot() +
    geom_segment(data = ed, aes(x = x, y = y, xend = xend, yend = yend,
                 linetype = lt, colour = cl), linewidth = 0.42,
                 arrow = arrow(length = unit(0.15, "cm"), type = "closed")) +
    geom_label(data = xy, aes(x = x, y = y, label = rownames(xy)),
               size = 3.1, label.padding = unit(0.20, "lines"),
               fill = "grey93", colour = "black", linewidth = 0.30) +
    geom_label(data = ed, aes(x = mx, y = my, label = lab,
               fontface = ifelse(sig01, "bold", "plain")), size = 2.45,
               label.padding = unit(0.10, "lines"), fill = "white",
               colour = "black", linewidth = 0, alpha = 0.9) +
    scale_linetype_identity() + scale_colour_identity() +
    coord_cartesian(xlim = c(0.3, 8.7), ylim = c(0.3, 7.5), clip = "off") +
    labs(title = st,
         subtitle = paste0("GoF = ", round(fit$gof, 3), "; n = ", nrow(dat),
                           "; bootstrap B = ", ok, "; solid = p < 0.05")) +
    theme_void(base_size = 9) +
    theme(plot.title = element_text(hjust = .5, face = "bold", size = 10),
          plot.subtitle = element_text(hjust = .5, size = 7, colour = "grey35"),
          plot.margin = margin(10, 10, 10, 10))
  fn <- file.path(FIG, paste0("Fig_path_", sub(" stage", "", st)))
  ggsave(paste0(fn, ".pdf"), g, width = 7.4, height = 4.4, device = cairo_pdf)
  ggsave(paste0(fn, ".png"), g, width = 7.4, height = 4.4, dpi = 300)
  plots[[st]] <- g

  cat(sprintf("%-16s n=%d paths=%d GoF=%.4f  boot_ok=%d\n", st, nrow(dat), nrow(ec), fit$gof, ok))
}

## ---------- 5. 写出 ----------
wr(do.call(rbind, res_path),  "01_路径系数与bootstrap区间.csv")
wr(do.call(rbind, res_eff),   "02_效应分解_直接间接总.csv")
wr(do.call(rbind, res_eval),  "03_模型评价_R2_AVE_信度.csv")
wr(do.call(rbind, res_outer), "04_外模型载荷与权重.csv")
wr(do.call(rbind, res_glob),  "05_模型总体_GoF.csv")
wr(do.call(rbind, res_vif),   "06_VIF_内模型.csv")

## 星号版路径表（放正文表格用）
pt_all <- do.call(rbind, res_path)
pt_all$beta_sig <- paste0(formatC(pt_all$beta, 3, format = "f"), pt_all$sig)
wr(pt_all[, c("stage","from","to","beta_sig","CI95_lower","CI95_upper","p_empirical","n_flip")],
   "07_路径系数_星号版.csv")

cat("\n输出目录：", ROOT, "\n")
print(do.call(rbind, res_glob), row.names = FALSE)
