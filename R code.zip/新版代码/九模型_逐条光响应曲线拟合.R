# 图片中的九个公式合并为六类不同曲线，逐条拟合（单位沿用原始工作簿）
# 运行前正常加载 readxl、writexl；本脚本不自动安装 R 包。
# 直接在 RStudio 中运行整份脚本，结果写入 input_file 所在目录。

if (.Platform$OS.type == "windows" && !isTRUE(l10n_info()[["UTF-8"]])) {
  try(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.utf8"), silent = TRUE)
}

library(readxl)
library(writexl)

input_file <- "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/光响应/光合数据计算/四种曲线拟合原始.xlsx"
output_file <- file.path(dirname(input_file), "六类光响应模型_逐条曲线拟合结果_含AICc.xlsx")
source_sheet <- "画图整理"
model_ids <- c("RH_1_2", "RH_3", "Tanh_4_5", "NRH_6", "Exp_7_8", "Ye_9")
# 各模型拟合的曲线参数个数；AICc还需另计一个残差方差参数。
model_parameter_counts <- c(RH_1_2 = 3L, RH_3 = 3L, Tanh_4_5 = 3L,
                            NRH_6 = 4L, Exp_7_8 = 3L, Ye_9 = 4L)
model_equations <- c(RH_1_2 = "1, 2", RH_3 = "3", Tanh_4_5 = "4, 5",
                     NRH_6 = "6", Exp_7_8 = "7, 8", Ye_9 = "9（修订S5）")
min_points <- 8L
set.seed(20260927)

# 原表：每段为“生育期标题、Qin/样品表头、15个PPFD观测行”。
# 样品列是独立曲线。相同列名从左至右依次作为重复1、2、3。
# FS只有位置代码，没有施肥信息；保留 Position=FS、Fertilization=未标注。
raw <- readxl::read_excel(input_file, sheet = source_sheet,
                          col_names = FALSE,
                          col_types = "text", .name_repair = "minimal")
raw <- as.data.frame(raw, stringsAsFactors = FALSE)

as_num <- function(z) suppressWarnings(as.numeric(z))
# 正态独立同方差残差的最大似然AICc；RSS与其他拟合优度指标使用同一组观测。
calc_aicc <- function(rss, n, p) {
  k <- p + 1L  # p个曲线参数 + 1个残差方差参数
  if (!is.finite(rss) || rss <= 0 || !is.finite(n) || n <= k + 1L)
    return(NA_real_)
  aic <- n * (log(2 * pi) + 1 + log(rss / n)) + 2 * k
  aic + 2 * k * (k + 1) / (n - k - 1)
}
excel_col <- function(j) {
  s <- ""
  while (j > 0L) {
    s <- paste0(LETTERS[(j - 1L) %% 26L + 1L], s)
    j <- (j - 1L) %/% 26L
  }
  s
}

warning_rows <- list()
add_warning <- function(meta, model, code, detail) {
  warning_rows[[length(warning_rows) + 1L]] <<- data.frame(
    CurveID = meta$CurveID, Stage = meta$Stage,
    Position = meta$Position, Fertilization = meta$Fertilization,
    Replicate = meta$Replicate, Model = model,
    Warning = code, Detail = detail, stringsAsFactors = FALSE
  )
}

# ---------- 1. 逐列读取75条独立曲线 ----------
first_col <- trimws(ifelse(is.na(raw[[1]]), "", raw[[1]]))
header_rows <- which(first_col == "Qin")
if (length(header_rows) != 3L) {
  stop("预期在“画图整理”中找到3个 Qin 表头，实际找到 ", length(header_rows), " 个。")
}

curves <- list()
for (h in header_rows) {
  if (h == 1L) stop("Qin 表头前缺少生育期标题。")
  stage <- trimws(raw[[1]][h - 1L])
  if (is.na(stage) || !nzchar(stage)) stop("第 ", h, " 行前缺少生育期名称。")

  # 用下一段的标题位置界定本段，避免某个PPFD单元格缺失时截断后续样品点。
  following_headers <- header_rows[header_rows > h]
  last <- if (length(following_headers)) following_headers[1] - 2L else nrow(raw)
  data_rows <- seq.int(h + 1L, last)
  if (length(data_rows) < min_points) stop(stage, " 的 PPFD 观测行不足。")
  ppfd_all <- as_num(raw[[1]][data_rows])
  replicate_counter <- new.env(parent = emptyenv())

  for (j in seq.int(2L, ncol(raw))) {
    label <- trimws(raw[[j]][h])
    if (is.na(label) || !nzchar(label)) next

    m <- regmatches(label, regexec("^(CK|MF|OF|F)(BP|UP)([0-9]*)$", label))[[1]]
    if (length(m) == 4L) {
      fert <- m[2]
      pos <- m[3]
      suffix <- m[4]
      base_label <- paste0(fert, pos)
    } else if (label == "FS") {
      fert <- "未标注"
      pos <- "FS"
      suffix <- ""
      base_label <- "FS"
    } else {
      fert <- "未标注"
      pos <- "未标注"
      suffix <- ""
      base_label <- label
    }

    if (nzchar(suffix)) {
      rep_id <- as.integer(suffix)
    } else {
      current <- if (exists(base_label, envir = replicate_counter, inherits = FALSE)) {
        get(base_label, envir = replicate_counter)
      } else 0L
      rep_id <- current + 1L
    }
    assign(base_label, max(rep_id,
                           if (exists(base_label, envir = replicate_counter, inherits = FALSE))
                             get(base_label, envir = replicate_counter) else 0L),
           envir = replicate_counter)

    y_all <- as_num(raw[[j]][data_rows])
    keep <- is.finite(ppfd_all) & is.finite(y_all)
    col_letter <- excel_col(j)
    meta <- list(
      CurveID = paste(stage, label, paste0("rep", rep_id), col_letter, sep = "_"),
      Stage = stage, Position = pos, Fertilization = fert,
      Replicate = rep_id, RawHeader = label,
      SourceSheet = source_sheet, SourceColumn = col_letter,
      SourceCells = sprintf("%s%d:%s%d", col_letter, min(data_rows),
                            col_letter, max(data_rows)),
      n_total = length(data_rows), n_used = sum(keep), n_missing = sum(!keep)
    )
    if (label == "FS") {
      add_warning(meta, "全部", "metadata incomplete",
                  "FS仅为原始列名；施肥处理未在表中标注，按未标注保留。")
    } else if (length(m) != 4L) {
      add_warning(meta, "全部", "unrecognized header",
                  paste("原始列名未能解析位置/施肥：", label))
    }
    if (meta$n_missing > 0L) {
      add_warning(meta, "全部", "missing values",
                  sprintf("%d/%d个观测点的PPFD或Pn缺失/非数值；所有模型使用相同的%d个完整点。",
                          meta$n_missing, meta$n_total, meta$n_used))
    }
    curves[[length(curves) + 1L]] <- list(
      meta = meta, x = ppfd_all[keep], y = y_all[keep]
    )
  }
}
if (length(curves) != 75L) {
  warning("读取到 ", length(curves), " 条曲线；原始版本预期为75条，请检查曲线索引表。")
}

# ---------- 2. 九个公式合并为六类不同的可辨识曲线 ----------
# 公式1/2：I50=Pmax/alpha；公式4/5：Isat=Pmax/alpha。
# 公式7/8：两者都可写成C-B*exp(-kI)，且B-C=暗呼吸；
# 若公式8的参数为(P8,k,Icomp,R8)，则B=P8*exp(k*Icomp)、C=P8-R8，
# 用公式7的Pmax=B、alpha=k*B、Rd=B-C可给出完全相同的Pn(I)。
# 公式8中的Icomp与原式Rd不能各自从观测曲线唯一识别，因此只拟合等价的公式7。
predict_pn <- function(model, p, I) {
  if (model == "RH_1_2") return(p["alpha"] * I * p["Pmax"] /
                               (p["alpha"] * I + p["Pmax"]) - p["Rd"])
  if (model == "RH_3") return(p["alpha"] * I * p["Pmax"] /
                               sqrt((p["alpha"] * I)^2 + p["Pmax"]^2) - p["Rd"])
  if (model == "Tanh_4_5") return(p["Pmax"] * tanh(p["alpha"] * I / p["Pmax"]) - p["Rd"])
  if (model == "NRH_6") {
    aI <- p["alpha"] * I
    disc <- (aI + p["Pmax"])^2 - 4 * p["theta"] * aI * p["Pmax"]
    if (any(disc < -1e-9)) return(rep(NA_real_, length(I)))
    return((aI + p["Pmax"] - sqrt(pmax(disc, 0))) / (2 * p["theta"]) - p["Rd"])
  }
  if (model == "Exp_7_8") return(p["Pmax"] *
                                 (1 - exp(-p["alpha"] * I / p["Pmax"])) - p["Rd"])
  # 新图片S5：Pn(I)=alpha*I*(1-beta*I)/(1+gamma*I)-Rd。
  if (model == "Ye_9") return(p["alpha"] * I *
                               (1 - p["beta"] * I) / (1 + p["gamma"] * I) - p["Rd"])
  stop("未知模型：", model)
}

clamp <- function(z, lo, hi) pmin(pmax(z, lo), hi)

fit_setup <- function(model, x, y) {
  imax <- max(x)
  ymax <- max(y)
  y0 <- if (any(x == 0)) mean(y[x == 0]) else min(y)
  rd0 <- clamp(-y0, 0.05, max(8, 2.5 * abs(y0) + 1))
  low <- x <= min(150, 0.1 * imax)
  alpha0 <- if (sum(low) >= 3L) {
    unname(coef(lm(y[low] ~ x[low]))[2])
  } else 0.05
  if (!is.finite(alpha0)) alpha0 <- 0.05
  alpha0 <- clamp(alpha0, 0.008, 0.14)
  p0 <- max(2, ymax + rd0 + 2)
  p_hi <- max(15, 2.2 * max(ymax, 1) + rd0)
  rd_hi <- max(8, 2.5 * abs(y0) + 1)
  if (model %in% c("RH_1_2", "RH_3", "Tanh_4_5", "Exp_7_8")) {
    lo <- c(alpha = 0.0001, Pmax = 0.5, Rd = 0)
    hi <- c(alpha = 0.25, Pmax = p_hi, Rd = rd_hi)
    start <- c(alpha = alpha0, Pmax = p0, Rd = rd0)
  } else if (model == "NRH_6") {
    lo <- c(alpha = 0.0001, Pmax = 0.5, theta = 0.05, Rd = 0)
    hi <- c(alpha = 0.25, Pmax = p_hi, theta = 0.99, Rd = rd_hi)
    start <- c(alpha = alpha0, Pmax = p0, theta = 0.75, Rd = rd0)
  } else if (model == "Ye_9") {
    # beta不能预先限制为 >=1/(2*最大实测光强)：软件示例的有效解低于此值。
    # 是否出现超范围LSP，应在拟合后用解析式检查，而不是用beta硬下限排除。
    lo <- c(alpha = 0.0001, beta = 1e-8, gamma = 0.000001, Rd = 0)
    hi <- c(alpha = 0.25, beta = 0.98 / imax, gamma = 0.02,
            Rd = rd_hi)
    start <- c(alpha = alpha0, beta = 0.65 / imax,
               gamma = 0.001, Rd = rd0)
  } else stop("未知模型：", model)

  start <- setNames(clamp(start, lo + 1e-8 * (hi - lo),
                           hi - 1e-8 * (hi - lo)), names(start))
  list(lower = lo, upper = hi, start = start,
       pn_upper = max(15, 2.2 * max(ymax, 1)),
       rd_upper = rd_hi, imax = imax)
}

# ---------- 3. 参数推导；不可辨识或无有限解的参数记NA ----------
derive_physiology <- function(model, p) {
  Rd <- LCP <- LSP <- Pnmax <- AQY <- NA_real_
  if (model == "Ye_9") {
    # S5：AQY为I=0处导数alpha；Rd为Pn(0)的相反数。
    Rd <- unname(p["Rd"])
    AQY <- unname(p["alpha"])
    # S6、S7：直接使用用户提供的LSP及Pnmax解析式。
    if (p["beta"] > 0 && p["gamma"] > 0) {
      LSP <- unname((sqrt((p["beta"] + p["gamma"]) / p["beta"]) - 1) /
                      p["gamma"])
      Pnmax <- unname(p["alpha"] *
                        ((sqrt(p["beta"] + p["gamma"]) - sqrt(p["beta"])) /
                           p["gamma"])^2 - p["Rd"])
    }
    # Pn(I)=0得到 alpha*beta*I^2-(alpha-Rd*gamma)*I+Rd=0。
    # 较小非负根为LCP；此写法避免两近似相等的数相减造成数值误差。
    A <- unname(p["alpha"] - p["Rd"] * p["gamma"])
    disc <- A^2 - 4 * p["alpha"] * p["beta"] * p["Rd"]
    if (is.finite(disc) && disc >= 0 && A > 0) {
      LCP <- unname(2 * p["Rd"] / (A + sqrt(disc)))
    }
  } else {
    Rd <- unname(p["Rd"])
    Pnmax <- unname(p["Pmax"] - p["Rd"])
    if (model %in% c("RH_1_2", "RH_3", "Tanh_4_5", "NRH_6", "Exp_7_8"))
      AQY <- unname(p["alpha"])
    P <- p["Pmax"]
    d <- p["Rd"]
    if (P > d && d >= 0) {
      if (model == "RH_1_2") LCP <- d * P / (p["alpha"] * (P - d))
      if (model == "RH_3") LCP <- d * P / (p["alpha"] * sqrt(P^2 - d^2))
      if (model == "Tanh_4_5") LCP <- P * atanh(d / P) / p["alpha"]
      if (model == "NRH_6") LCP <- d * (P - p["theta"] * d) /
          (p["alpha"] * (P - d))
      if (model == "Exp_7_8") LCP <- -P * log1p(-d / P) / p["alpha"]
    }
    # 合并后的非Ye模型均为单调趋近渐近值，不存在有限LSP。
  }
  c(AQY = as.numeric(AQY), Rd = as.numeric(Rd),
    LCP = as.numeric(LCP), LSP = as.numeric(LSP),
    Pnmax = as.numeric(Pnmax))
}

plausibility <- function(model, phys, setup) {
  problems <- character()
  if (!is.finite(phys["AQY"]) || phys["AQY"] <= 0 || phys["AQY"] > 0.25)
    problems <- c(problems, "AQY不在(0, 0.25]范围内")
  if (!is.finite(phys["Rd"]) || phys["Rd"] < 0 ||
      phys["Rd"] > setup$rd_upper)
    problems <- c(problems, "Rd为负或异常偏大")
  if (!is.finite(phys["LCP"]) || phys["LCP"] < 0 ||
      phys["LCP"] > min(300, 0.25 * setup$imax))
    problems <- c(problems, "LCP无实数解或超出合理低光区")
  if (!is.finite(phys["Pnmax"]) || phys["Pnmax"] <= 0 ||
      phys["Pnmax"] > setup$pn_upper)
    problems <- c(problems, "Pnmax为负或显著高于实测范围")
  if (model == "Ye_9" &&
      (!is.finite(phys["LSP"]) || phys["LSP"] < phys["LCP"] ||
       phys["LSP"] > 1.1 * setup$imax))
    problems <- c(problems, "叶子飘模型LSP无实数解或明显超出实测PPFD范围")
  problems
}

# ---------- 4. 有界、多初值非线性最小二乘 ----------
# 使用R自带optim(L-BFGS-B)，固定随机种子。各模型拟合同一条曲线的同一组完整观测。
fit_one <- function(model, x, y, curve_index) {
  if (length(y) < min_points || length(unique(x)) < min_points) {
    return(list(status = "fit failed", detail = "完整观测点不足或PPFD水平过少",
                par = NULL, phys = rep(NA_real_, 5),
                R2 = NA_real_, RMSE = NA_real_, MAE = NA_real_, RSS = NA_real_))
  }
  setup <- fit_setup(model, x, y)
  lo <- setup$lower
  hi <- setup$upper
  base <- setup$start
  model_index <- match(model, model_ids)
  set.seed(20260927 + 100L * curve_index + model_index)
  starts <- list(base)
  for (k in seq_len(11L)) {
    # 在合理区间内扰动初值；不是对重复观测求平均。
    jitter <- exp(runif(length(base), log(0.55), log(1.45)))
    starts[[k + 1L]] <- setNames(
      clamp(base * jitter, lo + 0.01 * (hi - lo),
            hi - 0.01 * (hi - lo)), names(base))
  }

  objective <- function(p) {
    names(p) <- names(base)
    pred <- predict_pn(model, p, x)
    if (length(pred) != length(y) || any(!is.finite(pred))) return(1e15)
    rss <- sum((y - pred)^2)
    if (!is.finite(rss)) 1e15 else rss
  }

  candidates <- list()
  optimizer_messages <- character()
  for (start in starts) {
    fit <- tryCatch(
      stats::optim(par = start, fn = objective, method = "L-BFGS-B",
                   lower = lo, upper = hi,
                   control = list(maxit = 2000, factr = 1e7,
                                  parscale = pmax(abs(start),
                                                  0.15 * (hi - lo), 1e-6))),
      error = function(e) e
    )
    if (inherits(fit, "error")) {
      optimizer_messages <- c(optimizer_messages, conditionMessage(fit))
      next
    }
    if (fit$convergence != 0L || !is.finite(fit$value)) {
      optimizer_messages <- c(optimizer_messages,
                              paste0("optim code=", fit$convergence))
      next
    }
    p <- setNames(as.numeric(fit$par), names(base))
    phys <- derive_physiology(model, p)
    problems <- plausibility(model, phys, setup)
    candidates[[length(candidates) + 1L]] <- list(
      par = p, rss = fit$value, phys = phys,
      problems = problems
    )
  }

  if (length(candidates) == 0L) {
    detail <- if (length(optimizer_messages))
      paste(unique(optimizer_messages), collapse = "; ") else "所有初值均未收敛"
    return(list(status = "fit failed", detail = detail, par = NULL,
                phys = rep(NA_real_, 5), R2 = NA_real_, RMSE = NA_real_,
                MAE = NA_real_, RSS = NA_real_))
  }

  good <- which(vapply(candidates, function(z) length(z$problems) == 0L, logical(1)))
  pool <- if (length(good)) good else seq_along(candidates)
  winner <- pool[which.min(vapply(candidates[pool], `[[`, numeric(1), "rss"))]
  best <- candidates[[winner]]
  pred <- predict_pn(model, best$par, x)
  residual <- y - pred
  rss <- sum(residual^2)
  n <- length(y)
  tss <- sum((y - mean(y))^2)
  rmse <- sqrt(rss / n)
  mae <- sum(abs(residual)) / n
  r2 <- if (tss > 0) 1 - rss / tss else NA_real_
  status <- if (length(best$problems)) "biologically implausible" else "ok"
  detail <- if (length(best$problems)) paste(best$problems, collapse = "; ") else ""

  edge <- abs(best$par - lo) <= 0.002 * (hi - lo) |
          abs(best$par - hi) <= 0.002 * (hi - lo)
  if (any(edge)) {
    edge_msg <- paste0("参数接近约束边界：", paste(names(best$par)[edge], collapse = ", "))
    detail <- paste(c(detail, edge_msg)[nzchar(c(detail, edge_msg))], collapse = "; ")
  }
  list(status = status, detail = detail, par = best$par,
       phys = best$phys, R2 = r2, RMSE = rmse, MAE = mae, RSS = rss)
}

# ---------- 5. 全部曲线×全部模型，保留失败行 ----------
metric_rows <- list()
ye_rows <- list()
ye_point_rows <- list()
all_fits <- list()
curve_index_rows <- list()
for (ci in seq_along(curves)) {
  cur <- curves[[ci]]
  m <- cur$meta
  curve_index_rows[[ci]] <- data.frame(
    CurveID = m$CurveID, Stage = m$Stage, Position = m$Position,
    Fertilization = m$Fertilization, Replicate = m$Replicate,
    RawHeader = m$RawHeader, SourceSheet = m$SourceSheet,
    SourceColumn = m$SourceColumn, SourceCells = m$SourceCells,
    n_total = m$n_total, n_used = m$n_used, n_missing = m$n_missing,
    stringsAsFactors = FALSE
  )

  for (model in model_ids) {
    result <- fit_one(model, cur$x, cur$y, ci)
    aicc <- calc_aicc(result$RSS, m$n_used,
                      unname(model_parameter_counts[model]))
    all_fits[[paste(m$CurveID, model, sep = "__")]] <- result
    metric_rows[[length(metric_rows) + 1L]] <- data.frame(
      CurveID = m$CurveID, Stage = m$Stage, Position = m$Position,
      Fertilization = m$Fertilization, Replicate = m$Replicate,
      Model = model, Original_formulas = unname(model_equations[model]),
      n_used = m$n_used,
      R2 = result$R2, RMSE = result$RMSE,
      MAE = result$MAE, RSS = result$RSS, AICc = aicc,
      FitStatus = result$status, Selection = "",
      stringsAsFactors = FALSE
    )
    if (result$status != "ok" || nzchar(result$detail)) {
      add_warning(m, model,
                  if (result$status == "ok") "parameter boundary" else result$status,
                  if (nzchar(result$detail)) result$detail else "参数诊断需复核")
    }
    if (model == "Ye_9") {
      ph <- if (result$status == "ok") result$phys else
        setNames(rep(NA_real_, 5), c("AQY", "Rd", "LCP", "LSP", "Pnmax"))
      p_ye <- if (result$status == "ok") result$par else
        setNames(rep(NA_real_, 4), c("alpha", "beta", "gamma", "Rd"))
      ye_rows[[ci]] <- data.frame(
        CurveID = m$CurveID, Stage = m$Stage, Position = m$Position,
        Fertilization = m$Fertilization, Replicate = m$Replicate,
        alpha_fit = unname(p_ye["alpha"]), beta_fit = unname(p_ye["beta"]),
        gamma_fit = unname(p_ye["gamma"]),
        AQY = ph["AQY"], Rd = ph["Rd"], LCP = ph["LCP"],
        LSP = ph["LSP"], Pnmax = ph["Pnmax"],
        R2 = result$R2, RMSE = result$RMSE,
        MAE = result$MAE, RSS = result$RSS, AICc = aicc,
        FitStatus = result$status, stringsAsFactors = FALSE
      )
      pred_ye <- if (!is.null(result$par))
        predict_pn("Ye_9", result$par, cur$x) else rep(NA_real_, length(cur$x))
      ye_point_rows[[ci]] <- data.frame(
        CurveID = m$CurveID, Stage = m$Stage, Position = m$Position,
        Fertilization = m$Fertilization, Replicate = m$Replicate,
        SourceColumn = m$SourceColumn, PointIndex = seq_along(cur$x),
        PPFD = cur$x, Pn_observed = cur$y, Pn_Ye_fitted = pred_ye,
        Residual = cur$y - pred_ye, FitStatus = result$status,
        stringsAsFactors = FALSE
      )
    }
  }
  if (ci %% 10L == 0L || ci == length(curves))
    message(sprintf("已拟合 %d/%d 条曲线", ci, length(curves)))
}
model_metrics <- do.call(rbind, metric_rows)
ye_parameters <- do.call(rbind, ye_rows)
ye_curve_points <- do.call(rbind, ye_point_rows)
curve_index <- do.call(rbind, curve_index_rows)
rownames(model_metrics) <- rownames(ye_parameters) <-
  rownames(ye_curve_points) <- rownames(curve_index) <- NULL

# ---------- 6. 综合比较模型精度 ----------
# 同一条曲线的n固定：R2、RMSE、RSS与RSS严格单调对应；
# 因此同时检查四指标方向，以RSS和MAE两个非冗余误差维度排序。
# “明显优于Ye”预设为：R2更高，RMSE至少低3%，MAE至少低3%，RSS至少低5%。
# 只有候选拟合状态为ok，才可以成为Best model。
best_rows <- list()
for (ci in seq_along(curves)) {
  m <- curves[[ci]]$meta
  z <- model_metrics[model_metrics$CurveID == m$CurveID, , drop = FALSE]
  ye <- z[z$Model == "Ye_9", , drop = FALSE]
  valid <- z[z$FitStatus == "ok" & is.finite(z$R2) &
               is.finite(z$RMSE) & is.finite(z$MAE) & is.finite(z$RSS), , drop = FALSE]
  ye_ok <- nrow(ye) == 1L && ye$FitStatus == "ok" &&
    all(is.finite(unlist(ye[, c("R2", "RMSE", "MAE", "RSS")], use.names = FALSE)))

  if (nrow(valid) == 0L) {
    selected <- NULL
    decision <- "所有模型均fit failed / biologically implausible"
  } else if (ye_ok) {
    candidate <- valid[valid$Model != "Ye_9" &
                         valid$R2 > ye$R2 &
                         valid$RMSE <= 0.97 * ye$RMSE &
                         valid$MAE <= 0.97 * ye$MAE &
                         valid$RSS <= 0.95 * ye$RSS, , drop = FALSE]
    if (nrow(candidate) == 0L) {
      selected <- ye
      decision <- "Ye保留：无其他模型同时达到四指标改进门槛"
    } else {
      score <- 0.5 * log(pmax(candidate$RSS, 1e-12) /
                           pmax(min(candidate$RSS), 1e-12)) +
               0.5 * log(pmax(candidate$MAE, 1e-12) /
                           pmax(min(candidate$MAE), 1e-12))
      selected <- candidate[order(score, candidate$RSS, candidate$MAE,
                                  match(candidate$Model, model_ids))[1], , drop = FALSE]
      decision <- "其他模型明显优于Ye"
    }
  } else {
    score <- 0.5 * log(pmax(valid$RSS, 1e-12) /
                         pmax(min(valid$RSS), 1e-12)) +
             0.5 * log(pmax(valid$MAE, 1e-12) /
                         pmax(min(valid$MAE), 1e-12))
    selected <- valid[order(score, valid$RSS, valid$MAE,
                            match(valid$Model, model_ids))[1], , drop = FALSE]
    decision <- "Ye拟合失败或生理参数不合理；选择有效模型"
  }

  if (is.null(selected)) {
    best_name <- NA_character_
    best_stats <- setNames(rep(NA_real_, 5), c("R2", "RMSE", "MAE", "RSS", "AICc"))
    extra <- setNames(rep(NA_real_, 5), c("AQY", "Rd", "LCP", "LSP", "Pnmax"))
    best_status <- "fit failed"
  } else {
    best_name <- selected$Model
    best_stats <- unlist(selected[, c("R2", "RMSE", "MAE", "RSS", "AICc")], use.names = TRUE)
    best_status <- selected$FitStatus
    model_metrics$Selection[model_metrics$CurveID == m$CurveID &
                              model_metrics$Model == best_name] <- "Best model"
    if (best_name == "Ye_9") {
      # Ye完整生理参数已经逐条保存在Ye_parameters；此处不重复。
      extra <- setNames(rep(NA_real_, 5), c("AQY", "Rd", "LCP", "LSP", "Pnmax"))
    } else {
      extra <- all_fits[[paste(m$CurveID, best_name, sep = "__")]]$phys
    }
  }

  best_rows[[ci]] <- data.frame(
    CurveID = m$CurveID, Stage = m$Stage, Position = m$Position,
    Fertilization = m$Fertilization, Replicate = m$Replicate,
    Ye_model = "Ye_9", Ye_R2 = ye$R2, Ye_RMSE = ye$RMSE,
    Ye_MAE = ye$MAE, Ye_RSS = ye$RSS, Ye_AICc = ye$AICc,
    Ye_FitStatus = ye$FitStatus,
    Best_model = best_name,
    Best_original_formulas = if (is.na(best_name)) NA_character_ else
      unname(model_equations[best_name]),
    Best_R2 = as.numeric(best_stats["R2"]),
    Best_RMSE = as.numeric(best_stats["RMSE"]),
    Best_MAE = as.numeric(best_stats["MAE"]),
    Best_RSS = as.numeric(best_stats["RSS"]),
    Best_AICc = as.numeric(best_stats["AICc"]),
    Best_AQY = extra["AQY"], Best_Rd = extra["Rd"],
    Best_LCP = extra["LCP"], Best_LSP = extra["LSP"],
    Best_Pnmax = extra["Pnmax"],
    Best_FitStatus = best_status, Decision = decision,
    stringsAsFactors = FALSE
  )
}
best_model <- do.call(rbind, best_rows)
rownames(best_model) <- NULL

# ---------- 7. 按生育期×位置×施肥，汇总Ye参数的均值和SD ----------
group_key <- unique(ye_parameters[, c("Stage", "Position", "Fertilization")])
summary_rows <- list()
parameter_names <- c("AQY", "Rd", "LCP", "LSP", "Pnmax")
for (gi in seq_len(nrow(group_key))) {
  key <- group_key[gi, , drop = FALSE]
  sub <- ye_parameters[ye_parameters$Stage == key$Stage &
                         ye_parameters$Position == key$Position &
                         ye_parameters$Fertilization == key$Fertilization,
                       , drop = FALSE]
  good <- sub[sub$FitStatus == "ok", , drop = FALSE]
  one <- data.frame(
    Stage = key$Stage, Position = key$Position,
    Fertilization = key$Fertilization,
    n_curves = nrow(sub), n_ye_valid = nrow(good),
    stringsAsFactors = FALSE
  )
  for (param in parameter_names) {
    values <- good[[param]]
    values <- values[is.finite(values)]
    one[[paste0(param, "_mean")]] <- if (length(values)) mean(values) else NA_real_
    one[[paste0(param, "_SD")]] <- if (length(values) >= 2L) stats::sd(values) else NA_real_
  }
  summary_rows[[gi]] <- one
}
ye_summary <- do.call(rbind, summary_rows)
rownames(ye_summary) <- NULL

fit_warnings <- if (length(warning_rows)) do.call(rbind, warning_rows) else
  data.frame(CurveID = character(), Stage = character(), Position = character(),
             Fertilization = character(), Replicate = integer(), Model = character(),
             Warning = character(), Detail = character(), stringsAsFactors = FALSE)
rownames(fit_warnings) <- NULL

method_notes <- data.frame(
  Item = c(
    "数据源", "独立曲线", "PPFD范围", "拟合方法", "Ye参数约束", "重复公式合并", "模型8可辨识性",
    "AQY定义", "Rd定义", "LCP定义", "LSP定义", "Pnmax定义",
    "比较指标", "AICc计算", "AICc参数量", "AICc用途", "明显优于Ye门槛",
    "FS标记", "失败处理"
  ),
  Detail = c(
    "四种曲线拟合原始.xlsx / 画图整理；起身期、拔节期、开花期。",
    "每个样品列单独拟合；同名列按从左至右编号，不先对重复取平均。",
    "取每条曲线的原始PPFD/Pn完整观测；所有模型使用同一组完整点。",
    "R内置optim的L-BFGS-B有界最小二乘；每个模型12组确定性初值。",
    "Ye的beta下限为1e-8，不使用1/(2*最大PPFD)的错误硬下限；拟合后检查LSP是否落在实测范围附近。",
    "原公式1/2、4/5、7/8分别为完全相同的曲线族；九个原公式合并为六类，仅拟合和比较六类，Original_formulas保留对应编号。",
    "图片公式(8)原有4个符号参数仅3个组合可辨识；合并使用等价的公式(7)参数化，不虚构公式(8)的Icomp和Rd。",
    "曲线在I=0处的导数；修订Ye模型AQY=alpha。",
    "Rd=-Pn(0)；修订Ye模型直接拟合Rd。",
    "低光下Pn(I)=0的较小非负根；修订Ye模型由二次方程求解，判别式为负时记NA。",
    "修订Ye模型使用图片S6式LSP=(sqrt((beta+gamma)/beta)-1)/gamma；其他模型无有限极大点，记NA。",
    "修订Ye模型使用图片S7式Pnmax=alpha*((sqrt(beta+gamma)-sqrt(beta))/gamma)^2-Rd；其他模型取净光合渐近上限。",
    "RSS=sum((y-yhat)^2); RMSE=sqrt(RSS/n); MAE=mean(abs(y-yhat)); R2=1-RSS/TSS。",
    "基于正态独立同方差残差的最大似然：AIC=n*[log(2*pi)+1+log(RSS/n)]+2K；AICc=AIC+2K(K+1)/(n-K-1)。",
    "K=曲线拟合参数个数+1个残差方差参数；RH_1_2、RH_3、Tanh_4_5、Exp_7_8的K=4，NRH_6、Ye_9的K=5。RSS<=0、拟合失败或n<=K+1时AICc记NA。",
    "AICc写入逐曲线模型指标和Ye/Best结果；现有Best model仍按R2、RMSE、MAE、RSS判定，AICc不参与改变选择。",
    "其他模型需R2升高、RMSE下降至少3%、MAE下降至少3%、RSS下降至少5%，且参数通过生理合理性检查。",
    "原始表只有FS列名，没有施肥标签；Position=FS、Fertilization=未标注。",
    "所有曲线和六类唯一模型组合保留；不收敛/生理不合理/缺失值写入Fit_warnings。"
  ), stringsAsFactors = FALSE
)

# ---------- 8. 由R直接导出最终Excel ----------
writexl::write_xlsx(
  x = list(
    Ye_parameters = ye_parameters,
    Ye_curve_points = ye_curve_points,
    Model_metrics = model_metrics,
    Best_model = best_model,
    Ye_group_summary = ye_summary,
    Fit_warnings = fit_warnings,
    Curve_index = curve_index,
    Method_notes = method_notes
  ),
  path = output_file
)

stopifnot(
  nrow(ye_parameters) == length(curves),
  nrow(ye_curve_points) == sum(curve_index$n_used),
  nrow(model_metrics) == length(curves) * length(model_ids),
  nrow(best_model) == length(curves),
  file.exists(output_file)
)
message("完成：", length(curves), "条独立曲线 × 6类唯一模型；结果文件：", output_file)
