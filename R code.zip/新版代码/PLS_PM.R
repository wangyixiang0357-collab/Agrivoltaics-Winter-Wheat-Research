## ============================================================
##  单期 PLS-PM 完整示例 —— 拔节期（Jointing, n = 48）
##  R 4.4.2 / plspm 0.4.9
##  可直接 Rscript 运行；改 STAGE 与 spec 即可套到起身/开花期
## ============================================================
suppressMessages(library(plspm))

## ---- 1. 数据：10 个模块 PC 得分 + 施肥三成分 + DLI + 土壤 ----
F0 <- "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/数据表/处理后的PC scores_合并PCA.csv"
d0 <- read.csv(F0, check.names = FALSE, fileEncoding = "UTF-8", stringsAsFactors = FALSE)

## 原表列名带空格，先改成短名，避免 blocks 里写长串
ren <- c("Growth and biomass accumulation"      = "GBA",
         "Leaf morphological variation"         = "LMV",
         "Carbon assimilation capacity"         = "CAC",
         "Light requirement and respiration"    = "LRR",
         "PSII photochemical balance"           = "PPB",
         "Energy dissipation balance"           = "EDB",
         "N accumulation and root activity"     = "NARA",
         "C: N stoichiometric status"           = "CNSS",
         "Antioxidant defense and damage alleviation" = "ADDA",
         "CAT and proline response"             = "CPR",
         "Yield" = "Yld",
         "mineral nitrogen" = "MinN", "Organic N" = "OrgN", "CFU" = "CFU",
         "DLI" = "DLI", "Soil temperature" = "SoilT", "Soil water content" = "SWC")
nm <- names(d0); hit <- nm %in% names(ren); nm[hit] <- ren[nm[hit]]; names(d0) <- nm

dat <- d0[d0$stage == "Jointing stage", ]          # ← 换期只改这一行
rownames(dat) <- NULL

## ---- 2. 模型设定 ----
## 8 个潜变量；PV 用 DLI（替代板位编码），FERT 与 SHC 为形成型（Mode B）
ORD   <- c("PV","FERT","SHC","PR","SA","PH","GR","Y")
BLK   <- list(PV   = "DLI",
              FERT = c("MinN","OrgN","CFU"),         # 形成型：三个投入量不可互换
              SHC  = c("SoilT","SWC"),               # 形成型：两个独立物理量
              PR   = c("NARA","ADDA"),
              SA   = "EDB",
              PH   = "CAC",
              GR   = "GBA",
              Y    = "Yld")
MODES <- c(PV="A", FERT="B", SHC="B", PR="A", SA="A", PH="A", GR="A", Y="A")

## 路径矩阵：Im[去向, 来源] = 1（plspm 约定：行=被解释，列=解释）
Im <- matrix(0L, 8, 8, dimnames = list(ORD, ORD))
Im["SHC","PV"]   <- 1                      # DLI → 土壤水热
Im["PR","FERT"]  <- 1; Im["PR","SHC"] <- 1 # 施肥 + 土壤 → 生理调节
Im["SA","PV"]    <- 1; Im["SA","SHC"] <- 1 # 光 + 土壤 → 遮蔽适应
Im["PH","PV"]    <- 1; Im["PH","PR"]  <- 1; Im["PH","SA"] <- 1
Im["GR","PR"]    <- 1; Im["GR","PH"]  <- 1
Im["Y","PV"]     <- 1; Im["Y","FERT"] <- 1; Im["Y","GR"]  <- 1

## 组装数据：按 ORD 顺序把各 block 的指标列拼起来（列序必须与 BLK 一致）
Dat <- do.call(cbind, lapply(ORD, function(k) dat[, BLK[[k]], drop = FALSE]))
colnames(Dat) <- unlist(BLK, use.names = FALSE)

## ---- 3. 拟合 ----
fit <- plspm(Dat, Im, BLK, modes = MODES,
             scheme = "centroid",   # 内权重方案
             scaled = TRUE,         # 指标标准化 → 路径系数即标准化 β
             tol = 1e-06, maxiter = 100,
             boot.val = FALSE)      # plspm 自带的 bootstrap 不保存矩阵，下面自己做

cat("GoF =", round(fit$gof, 4), "\n")
print(round(fit$path_coefs, 3))

## ---- 4. Bootstrap（B = 5000，按观测行重抽）----
B <- as.integer(Sys.getenv("PLSPM_B", "5000"))   # 正式 5000；试跑可设 PLSPM_B=50
set.seed(20261022)
idx <- which(Im == 1, arr.ind = TRUE)
ec  <- data.frame(from = ORD[idx[, 2]], to = ORD[idx[, 1]], stringsAsFactors = FALSE)
ec$beta <- fit$path_coefs[cbind(ec$to, ec$from)]

BS <- matrix(NA_real_, B, nrow(ec)); ok <- 0L
for (b in seq_len(B)) {
  ii <- sample.int(nrow(dat), nrow(dat), replace = TRUE)
  r <- tryCatch({
    D <- do.call(cbind, lapply(ORD, function(k) dat[ii, BLK[[k]], drop = FALSE]))
    colnames(D) <- unlist(BLK, use.names = FALSE)
    plspm(D, Im, BLK, modes = MODES, scheme = "centroid", scaled = TRUE,
          tol = 1e-06, maxiter = 100, boot.val = FALSE)$path_coefs
  }, error = function(e) NULL)
  if (is.null(r)) next
  ok <- ok + 1L
  BS[ok, ] <- r[cbind(ec$to, ec$from)]
}
BS <- BS[seq_len(ok), , drop = FALSE]

## 经验双侧 p：2·min{P(β*≤0), P(β*≥0)}，加 (b+1)/(B+1) 修正
p_emp <- apply(BS, 2, function(v) {
  v <- v[is.finite(v)]
  min(1, 2 * min((sum(v <= 0) + 1) / (length(v) + 1),
                 (sum(v >= 0) + 1) / (length(v) + 1)))
})
ci <- t(apply(BS, 2, quantile, c(.025, .975), na.rm = TRUE))
sta <- function(p) ifelse(p < .001, "***", ifelse(p < .01, "**",
                     ifelse(p < .05, "*", ifelse(p < .10, ".", "n.s."))))

res <- data.frame(path = paste0(ec$from, " → ", ec$to),
                  beta = round(ec$beta, 3),
                  boot_SE = round(apply(BS, 2, sd, na.rm = TRUE), 3),
                  CI_low = round(ci[, 1], 3), CI_high = round(ci[, 2], 3),
                  p = signif(p_emp, 3),
                  n_flip = apply(BS, 2, function(v) sum(sign(v) != sign(mean(v, na.rm = TRUE)), na.rm = TRUE)))
res$sig <- sta(res$p)
print(res, row.names = FALSE)

## ---- 5. 评价指标与效应分解 ----
print(fit$inner_summary)                       # R2 / AVE / 共同度 / 冗余度
print(fit$unidim)                              # Cronbach α / DG ρ / 特征值
print(head(fit$effects, 15))                   # 直接 / 间接 / 总效应

## ---- 6. 导出（可选）----
OUT <- "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/随机森林/_当前DLI版_结果/_单期示例_拔节期"
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
write.csv(res, file.path(OUT, "路径系数_bootstrap.csv"), row.names = FALSE)
write.csv(fit$inner_summary, file.path(OUT, "模型评价.csv"))
write.csv(fit$effects, file.path(OUT, "效应分解.csv"), row.names = FALSE)
