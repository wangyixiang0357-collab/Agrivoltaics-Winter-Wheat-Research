# ============================================================
# DLI 日时间序列独立绘图
#
# 数据：每日 UP、BP、FS 三个位置的 DLI。
# 图形：原始日尺度观测的折线与散点，不进行平滑或抽样。
# 输出：SVG、PDF、600 dpi TIFF 和 PNG。
# ============================================================

# 首次运行时，如缺少 R 包，请先运行：
# install.packages(c("ggplot2", "dplyr", "tidyr", "svglite", "ragg"))

required_packages <- c(
  "ggplot2", "dplyr", "tidyr", "svglite", "ragg"
)

missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  stop(
    "缺少以下 R 包：", paste(missing_packages, collapse = ", "),
    "\n请先运行：install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "),
    "))"
  )
}

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
})

# ---------- 1. 文件路径 ----------
user_profile <- Sys.getenv("USERPROFILE", unset = "")
if (!nzchar(user_profile)) {
  user_profile <- path.expand("~")
}

data_candidates <- c(
  file.path(
    user_profile,
    "Desktop", "项目区气象数据", "空气温湿度.csv"
  ),
  file.path(
    path.expand("~"),
    "Desktop", "项目区气象数据", "空气温湿度.csv"
  ),
  file.path(getwd(), "空气温湿度.csv")
)

existing_data_files <- data_candidates[file.exists(data_candidates)]
if (length(existing_data_files) == 0) {
  stop(
    "找不到数据文件“空气温湿度.csv”。已搜索：\n",
    paste(
      normalizePath(
        data_candidates,
        winslash = "/",
        mustWork = FALSE
      ),
      collapse = "\n"
    )
  )
}
data_file <- existing_data_files[[1]]

output_dir <- file.path(dirname(data_file), "微环境图片")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

output_prefix <- file.path(output_dir, "DLI_独立时间序列")

# ---------- 2. 读取两行表头的 CSV ----------
dat <- read.csv(
  data_file,
  skip = 2,
  header = FALSE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  na.strings = c("", "NA", "NaN")
)

if (ncol(dat) != 11) {
  stop(
    "CSV 应包含 11 列：日期、3 列温度、3 列湿度、",
    "3 列 DLI 和 1 列降雨。当前列数为：", ncol(dat)
  )
}

names(dat) <- c(
  "Date",
  "Temp_BP", "Temp_UP", "Temp_FS",
  "RH_BP", "RH_UP", "RH_FS",
  "DLI_BP", "DLI_UP", "DLI_FS",
  "Rainfall"
)

dat <- dat %>%
  transmute(
    Date = as.Date(Date, format = "%Y/%m/%d"),
    DLI_UP = suppressWarnings(as.numeric(DLI_UP)),
    DLI_BP = suppressWarnings(as.numeric(DLI_BP)),
    DLI_FS = suppressWarnings(as.numeric(DLI_FS))
  ) %>%
  arrange(Date)

if (anyNA(dat$Date)) {
  stop("部分日期无法按 YYYY/MM/DD 格式识别，请检查 CSV。")
}

if (anyDuplicated(dat$Date)) {
  stop("日期存在重复记录，请先确认是否需要按日求均值。")
}

# ---------- 3. 整理 DLI 长数据 ----------
micro_colors <- c(
  "Under-panel" = "#4477AA",
  "Inter-panel" = "#6FA8DC",
  "Open-field control" = "#F0E442"
)
micro_levels <- names(micro_colors)

dli_long_all <- dat %>%
  pivot_longer(
    cols = c(DLI_UP, DLI_BP, DLI_FS),
    names_to = "Position_code",
    values_to = "DLI"
  ) %>%
  mutate(
    Microenvironment = recode(
      Position_code,
      "DLI_UP" = "Under-panel",
      "DLI_BP" = "Inter-panel",
      "DLI_FS" = "Open-field control"
    ),
    Microenvironment = factor(
      Microenvironment,
      levels = micro_levels
    )
  )

missing_dli_rows <- sum(!is.finite(dli_long_all$DLI))

# 仅删除源数据中原本缺失或非有限的 DLI，不删除任何有效观测。
dli_long <- dli_long_all %>%
  filter(is.finite(DLI))

if (nrow(dli_long) == 0) {
  stop("DLI 列中没有可用于绘图的有效数值。")
}

# ---------- 4. 坐标范围和样式 ----------
dli_limits <- c(0, 50)
dli_breaks <- seq(0, 50, by = 10)

if (
  any(dli_long$DLI < dli_limits[1]) ||
  any(dli_long$DLI > dli_limits[2])
) {
  stop("DLI 数值超出 dli_limits，请调整坐标范围后重新运行。")
}

time_line_width <- 0.52
time_point_size <- 1.20

theme_reference <- theme_classic(
  base_size = 12,
  base_family = "Arial"
) +
  theme(
    panel.border = element_rect(
      colour = "black",
      fill = NA,
      linewidth = 0.75
    ),
    axis.line = element_blank(),
    axis.ticks = element_line(
      colour = "black",
      linewidth = 0.65
    ),
    axis.ticks.length = grid::unit(-0.07, "cm"),
    axis.title = element_text(
      colour = "black",
      face = "bold",
      size = 13
    ),
    axis.text = element_text(
      colour = "black",
      face = "bold",
      size = 10
    ),
    axis.text.x = element_text(
      size = 8,
      angle = 45,
      hjust = 1,
      margin = margin(t = 7)
    ),
    axis.text.y = element_text(margin = margin(r = 7)),
    legend.title = element_blank(),
    legend.text = element_text(
      colour = "black",
      face = "bold",
      size = 9
    ),
    legend.key = element_blank(),
    legend.background = element_rect(
      fill = "white",
      colour = "black",
      linewidth = 0.35
    ),
    legend.box = "vertical",
    legend.direction = "vertical",
    legend.key.height = grid::unit(0.35, "cm"),
    legend.spacing.y = grid::unit(0.03, "cm"),
    legend.margin = margin(3, 4, 3, 4),
    plot.margin = margin(8, 10, 8, 8)
  )

# 图例位于绘图区内部右上角，并兼容不同 ggplot2 版本。
theme_legend_inside <- function(
  position = c(0.98, 0.98),
  justification = c(1, 1)
) {
  if (utils::packageVersion("ggplot2") >= "3.5.0") {
    theme(
      legend.position = "inside",
      legend.position.inside = position,
      legend.justification = justification
    )
  } else {
    theme(
      legend.position = position,
      legend.justification = justification
    )
  }
}

# ---------- 5. 绘制 DLI ----------
p_dli <- ggplot(
  dli_long,
  aes(
    x = Date,
    y = DLI,
    colour = Microenvironment,
    group = Microenvironment
  )
) +
  geom_line(
    linewidth = time_line_width,
    na.rm = TRUE
  ) +
  geom_point(
    size = time_point_size,
    stroke = 0,
    na.rm = TRUE
  ) +
  scale_colour_manual(
    values = micro_colors,
    breaks = micro_levels,
    drop = FALSE
  ) +
  scale_x_date(
    date_breaks = "15 days",
    date_labels = "%y/%m/%d",
    expand = expansion(mult = c(0.01, 0.01))
  ) +
  scale_y_continuous(
    limits = dli_limits,
    breaks = dli_breaks,
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    x = "Date",
    y = expression("DLI (mol m"^-2 * " d"^-1 * ")")
  ) +
  guides(
    colour = guide_legend(
      ncol = 1,
      byrow = TRUE,
      override.aes = list(
        linewidth = 1.2,
        size = 2.2
      )
    )
  ) +
  theme_reference +
  theme_legend_inside()

# ---------- 6. 独立导出 ----------
save_dli_plot <- function(
  plot_object,
  filename_prefix,
  width_mm = 125,
  height_mm = 95,
  dpi = 600
) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  svglite::svglite(
    file = paste0(filename_prefix, ".svg"),
    width = width_in,
    height = height_in,
    bg = "white"
  )
  print(plot_object)
  grDevices::dev.off()

  grDevices::cairo_pdf(
    filename = paste0(filename_prefix, ".pdf"),
    width = width_in,
    height = height_in,
    family = "Arial",
    bg = "white",
    onefile = TRUE
  )
  print(plot_object)
  grDevices::dev.off()

  ragg::agg_tiff(
    filename = paste0(filename_prefix, ".tiff"),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    compression = "lzw",
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()

  ragg::agg_png(
    filename = paste0(filename_prefix, ".png"),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()
}

save_dli_plot(
  plot_object = p_dli,
  filename_prefix = output_prefix
)

message("DLI 绘图完成。")
message("有效 DLI 观测数：", nrow(dli_long))
message("因缺失或非有限值排除的 DLI 记录数：", missing_dli_rows)
message("输出文件前缀：", output_prefix)

# 在 RStudio 中显示：
p_dli
