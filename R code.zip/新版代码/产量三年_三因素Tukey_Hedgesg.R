# ============================================================================
# 2024、2025、2026：位置 × 施肥 × 年份、年度九处理 Tukey 和 Hedges' g
# 数据：产量三年均有；地上部生物量和籽粒氮积累量只有 2026 年有数据。
# Year 是固定效应。独立样方常规模型不按 Excel 行号构造跨年配对或随机区组。
# 不同样方是否来自跨年重复利用的同一个施肥大区，工作簿不能确认；若存在
# 这样的聚类/重复，须依据真实大区 ID 和试验设计改用合适的混合/分层模型。
#
# FS 保留为 Position='FS', Fertilization='FS' 的实际独立组合；但每年仅有
# FS × FS，FS 与其他位置、施肥水平存在结构性空单元。包含 FS 的完整
# Position × Fertilization × Year 模型秩亏，无法估计全部常规 Type III 项。
# 所以输出：
# A) UP/BP × CK/F/OF/MF × Year 的真实三因素 Type III（仅产量有三年）；
# B) 包括 FS 的九个实际 Treatment × Year Type III 组合模型（仅产量）；
# C) 每个指标、每一年分别对九个实际处理做 Tukey-Kramer、均值±SD、字母；
# D) 每个可分析的指标×年份计算九个指定 Hedges' g 对照。
# 在 C/D 中，2024、2025 只有产量；缺失指标和缺失年份写入可用性表。
# 效应量的 g 点估计与非中心 t 的 95% CI 使用对照两组合并 SD；区间逐项、
# 未进行多重校正。p_Tukey 来自该年份九处理全部 36 项比较的模型误差方差；
# 因方法不同，未校正 g 区间与 p_Tukey 是否显著可能不同。另保留两组未
# 校正 Student t 的 p 值作为参考，显著性标记采用 p_Tukey。
#
# Excel 的 2024/25 Yield 缓存公式为 E × 4；2026 为 G × 1.1364。原始工作簿
# 未记录各年的单位与面积换算依据。本脚本默认原值可比，不自动修改数据；
# 三年效应应在核实量纲、面积换算和处理持续性后解释。
# ============================================================================

# 首次缺少 readxl 时运行：install.packages("readxl")
INPUT_FILE <- paste0(
  "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/",
  "小麦光合生理/产量与生物量双因素混合模型_三指标结果/产量与养分积累量.xlsx"
)
OUTPUT_DIR <- file.path(dirname(INPUT_FILE), "三年三因素_Tukey_Hedgesg_结果")
OVERWRITE <- FALSE
YEARS <- c("2024", "2025", "2026")
YEAR_YIELD_MULTIPLIER <- c(`2024` = 1, `2025` = 1, `2026` = 1)
# 如查证单位确需换算，再显式修改上面系数；默认 1 表示保留 Excel 数值。
TREATMENTS <- c("CK_UP", "CK_BP", "F_UP", "F_BP", "OF_UP", "OF_BP",
                "MF_UP", "MF_BP", "FS")
IDS <- sprintf("T%02d", seq_along(TREATMENTS))
METRICS <- c("Yield", "Biomass", "N")

read_data <- function() {
  if (!requireNamespace("readxl", quietly = TRUE))
    stop("缺少 readxl，请运行 install.packages('readxl')。")
  if (!file.exists(INPUT_FILE)) stop("找不到 Excel 文件：", INPUT_FILE)
  raw <- as.data.frame(readxl::read_excel(INPUT_FILE, sheet = "Sheet1", skip = 1,
    col_names = FALSE, col_types = "text", .name_repair = "minimal"), check.names = FALSE)
  if (ncol(raw) != 11L) stop("Sheet1 列数与预期不同，请核对 Excel。")
  names(raw) <- c("SampleLabel", "Year", "Fertilization", "Position", "Unlabelled_E",
                  "Biomass", "GrainBiomass", "N", "P", "K", "Yield")
  clean <- function(x) {
    x <- trimws(as.character(x)); x[is.na(x) | x == ""] <- NA_character_; x
  }
  raw$Year <- clean(raw$Year)
  raw$Fertilization <- toupper(clean(raw$Fertilization))
  raw$Position <- toupper(clean(raw$Position))
  dat <- raw
  # B 列年份全表顺序填充；每遇到施肥名，重新开始一个处理组，
  # 位置只在该处理组内填充。FS 的位置由实际合并单元格含义显式设置。
  current_y <- current_f <- current_p <- NA_character_
  for (i in seq_len(nrow(raw))) {
    if (!is.na(raw$Year[i])) current_y <- raw$Year[i]
    if (!is.na(raw$Fertilization[i])) {
      current_f <- raw$Fertilization[i]; current_p <- NA_character_
    }
    if (!is.na(raw$Position[i])) current_p <- raw$Position[i]
    if (identical(current_f, "FS")) current_p <- "FS"
    dat$Year[i] <- current_y
    dat$Fertilization[i] <- current_f
    dat$Position[i] <- current_p
  }
  if (anyNA(dat[c("Year", "Fertilization", "Position")])) stop("年份或处理填写不完整。")
  if (any(!dat$Year %in% YEARS) ||
      any(!dat$Fertilization %in% c("CK", "F", "OF", "MF", "FS")) ||
      any(!dat$Position %in% c("UP", "BP", "FS"))) stop("出现未知年份、位置或施肥编码。")
  if (any((dat$Fertilization == "FS") != (dat$Position == "FS")))
    stop("FS 位置与 FS 施肥编码不一致。")
  for (nm in METRICS) {
    input <- clean(raw[[nm]])
    value <- suppressWarnings(as.numeric(input))
    if (any(!is.na(input) & (is.na(value) | !is.finite(value))))
      stop(nm, " 存在非数字或无穷值，请检查 Excel 公式缓存。")
    if (any(value < 0, na.rm = TRUE)) stop(nm, " 存在负值，请检查单位或数据。")
    dat[[nm]] <- value
  }
  if (!identical(sort(names(YEAR_YIELD_MULTIPLIER)), sort(YEARS)) ||
      any(!is.finite(YEAR_YIELD_MULTIPLIER)) || any(YEAR_YIELD_MULTIPLIER <= 0))
    stop("YEAR_YIELD_MULTIPLIER 必须为三年分别指定正数。")
  dat$Yield <- dat$Yield * unname(YEAR_YIELD_MULTIPLIER[dat$Year])
  dat$ExcelRow <- seq_len(nrow(dat)) + 1L
  dat$Treatment <- ifelse(dat$Fertilization == "FS", "FS",
    paste(dat$Fertilization, dat$Position, sep = "_"))
  if (any(!dat$Treatment %in% TREATMENTS)) stop("存在非预期位置 × 施肥组合。")
  dat$TreatmentID <- factor(IDS[match(dat$Treatment, TREATMENTS)], levels = IDS)
  dat$Treatment <- factor(dat$Treatment, levels = TREATMENTS)
  dat$Position <- factor(dat$Position, levels = c("UP", "BP", "FS"))
  dat$Fertilization <- factor(dat$Fertilization, levels = c("CK", "F", "OF", "MF", "FS"))
  dat$Year <- factor(dat$Year, levels = YEARS)
  dat
}

sig_code <- function(p) ifelse(is.na(p), NA_character_, ifelse(p < .001, "***",
  ifelse(p < .01, "**", ifelse(p < .05, "*", "ns"))))

# Type III SS：对 sum contrasts 的满秩完整模型，删除某个效应的模型矩阵列，
# 其他各项（包括所有交互项）仍保留；与 car::Anova(model, type=3) 的定义一致。
type3_lm <- function(model) {
  X <- stats::model.matrix(model)
  y <- stats::model.response(stats::model.frame(model))
  if (model$rank != ncol(X)) stop("模型秩亏，无法计算全部常规 Type III 检验。")
  assign <- attr(X, "assign")
  labels <- attr(stats::terms(model), "term.labels")
  sse <- sum(stats::residuals(model)^2)
  dfe <- stats::df.residual(model)
  if (dfe <= 0 || !is.finite(sse) || sse <= 0) stop("残差自由度/方差不足。")
  rows <- lapply(seq_along(labels), function(k) {
    red <- stats::lm.fit(X[, assign != k, drop = FALSE], y)
    df <- model$rank - red$rank
    if (df <= 0) stop("不可估计的项：", labels[k])
    ss <- max(0, sum(red$residuals^2) - sse)
    f <- (ss / df) / (sse / dfe)
    data.frame(Effect = labels[k], Sum_Sq = ss, NumDF = df, Mean_Sq = ss / df,
      DenDF = dfe, F_value = f, p_value = stats::pf(f, df, dfe, lower.tail = FALSE))
  })
  answer <- do.call(rbind, rows)
  answer$Significance <- sig_code(answer$p_value)
  answer
}

# 用 Tukey 两两校正 p 值直接构造 compact-letter display（insert-absorb）。
# 使用全部 36 个两两比较；逐次拆分显著差异的集合，删除被包含的集合。
# 最后按最高均值优先分配 a，并逐对验证：显著差异无共同字母，反之有共同字母。
letters_from_tukey <- function(pmat, means, alpha = .05) {
  ids <- names(means)
  if (length(ids) != 9L || !all(ids %in% rownames(pmat)) ||
      any(!is.finite(pmat)) || any(pmat < 0 | pmat > 1)) stop("Tukey p 矩阵无效。")
  pmat <- pmat[ids, ids, drop = FALSE]
  n <- length(ids)
  sets <- list(rep(TRUE, n))
  absorb <- function(sets) {
    key <- vapply(sets, function(s) paste(as.integer(s), collapse = ""), character(1))
    sets <- sets[!duplicated(key)]
    keep <- rep(TRUE, length(sets))
    if (length(sets) > 1L) for (i in seq_along(sets)) for (j in seq_along(sets)) {
      if (i != j && all(!sets[[i]] | sets[[j]])) { keep[i] <- FALSE; break }
    }
    sets[keep]
  }
  for (i in seq_len(n - 1L)) for (j in (i + 1L):n) {
    if (pmat[i, j] < alpha) {
      next_sets <- list()
      for (s in sets) {
        if (s[i] && s[j]) {
          si <- s; sj <- s; si[i] <- FALSE; sj[j] <- FALSE
          next_sets <- c(next_sets, list(si, sj))
        } else next_sets <- c(next_sets, list(s))
      }
      sets <- absorb(next_sets)
    }
  }
  descending <- order(means, decreasing = TRUE)
  sets <- sets[order(vapply(sets, function(s) min(match(which(s), descending)), integer(1)))]
  if (length(sets) > length(letters)) stop("字母集合超过 26，请使用扩展标签。")
  mat <- do.call(cbind, sets)
  rownames(mat) <- ids; colnames(mat) <- letters[seq_len(ncol(mat))]
  for (i in seq_len(n - 1L)) for (j in (i + 1L):n) {
    shared <- any(mat[i, ] & mat[j, ])
    if (shared != (pmat[i, j] >= alpha)) stop("显著性字母与 Tukey 比较不一致。")
  }
  out <- apply(mat, 1, function(s) paste(colnames(mat)[s], collapse = ""))
  if (!grepl("a", out[descending[1]])) stop("最高均值未获得 a。")
  out
}

# 独立两组 g：J 为精确 Gamma 校正；95% CI 通过非中心 t 反演。
# CDF 以正态/卡方积分计算，避免极大 g、低自由度时的 pt(ncp) 精度警告。
hedges_g <- function(x, reference, confidence = .95) {
  if (min(length(x), length(reference)) < 2L || any(!is.finite(c(x, reference))))
    stop("每组至少需要两个有限值。")
  nx <- length(x); nr <- length(reference); df <- nx + nr - 2L
  sp <- sqrt(((nx - 1) * stats::var(x) + (nr - 1) * stats::var(reference)) / df)
  if (!is.finite(sp) || sp <= 0) stop("两组 pooled SD 为零，不能计算 g。")
  J <- exp(lgamma(df / 2) - .5 * log(df / 2) - lgamma((df - 1) / 2))
  se_factor <- sqrt(1 / nx + 1 / nr)
  difference <- mean(x) - mean(reference)
  statistic <- difference / (sp * se_factor)
  # 使用非中心 t 的反射对称性，在负半轴求根，避免上尾积分精度不稳定。
  eval_statistic <- -abs(statistic)
  cdf <- function(ncp) {
    result <- stats::integrate(function(v)
      stats::pnorm(eval_statistic * sqrt(v / df) - ncp) * stats::dchisq(v, df),
      0, Inf, subdivisions = 1000L, rel.tol = 1e-10, abs.tol = 1e-12)
    if (!identical(result$message, "OK")) stop("Hedges g 的 CI 积分未收敛。")
    result$value
  }
  root <- function(p) {
    fn <- function(ncp) cdf(ncp) - p
    span <- max(8, abs(statistic) + 8)
    for (i in seq_len(30L)) {
      if (fn(-span) >= 0 && fn(span) <= 0)
        return(stats::uniroot(fn, c(-span, span), tol = 1e-10)$root)
      span <- span * 2
    }
    stop("Hedges g 的非中心 t 区间求根失败。")
  }
  alpha <- 1 - confidence
  ci <- J * se_factor * c(root(1 - alpha / 2), root(alpha / 2))
  if (statistic > 0) ci <- -rev(ci)
  data.frame(n_x = nx, n_reference = nr, Mean_x = mean(x), SD_x = stats::sd(x),
    Mean_reference = mean(reference), SD_reference = stats::sd(reference),
    Difference_x_minus_reference = difference, Pooled_SD = sp, J = J,
    Hedges_g = J * difference / sp, CI95_low_pointwise = ci[1],
    CI95_high_pointwise = ci[2], p_unadjusted_two_group = 2 * stats::pt(-abs(statistic), df))
}

analyse_year <- function(dat, metric, year) {
  d <- dat[as.character(dat$Year) == year & is.finite(dat[[metric]]), , drop = FALSE]
  d$Value <- d[[metric]]
  d$TreatmentID <- factor(as.character(d$TreatmentID), levels = IDS)
  counts <- table(d$TreatmentID)
  if (any(counts < 2L)) stop("同一指标×年份的九个处理均需至少两个有效值。")
  model <- stats::aov(Value ~ TreatmentID, data = d)
  tuk <- stats::TukeyHSD(model, "TreatmentID", conf.level = .95)$TreatmentID
  pairs <- do.call(rbind, strsplit(rownames(tuk), "-", fixed = TRUE))
  result_pairs <- data.frame(Indicator = metric, Year = as.integer(year),
    LeftID = pairs[, 1], RightID = pairs[, 2],
    Left = TREATMENTS[match(pairs[, 1], IDS)], Right = TREATMENTS[match(pairs[, 2], IDS)],
    Difference = tuk[, "diff"], CI95_low_Tukey = tuk[, "lwr"],
    CI95_high_Tukey = tuk[, "upr"], p_Tukey = tuk[, "p adj"], row.names = NULL)
  result_pairs$Significance <- sig_code(result_pairs$p_Tukey)
  pmat <- matrix(1, 9, 9, dimnames = list(IDS, IDS))
  for (i in seq_len(nrow(result_pairs))) {
    a <- result_pairs$LeftID[i]; b <- result_pairs$RightID[i]
    pmat[a, b] <- pmat[b, a] <- result_pairs$p_Tukey[i]
  }
  means <- tapply(d$Value, d$TreatmentID, mean)
  letter <- letters_from_tukey(pmat, means)
  summary <- do.call(rbind, lapply(IDS, function(id) {
    z <- d[d$TreatmentID == id, , drop = FALSE]
    data.frame(Indicator = metric, Year = as.integer(year), Treatment = as.character(z$Treatment[1]),
      Position = as.character(z$Position[1]), Fertilization = as.character(z$Fertilization[1]),
      n = nrow(z), Mean = mean(z$Value), SD = stats::sd(z$Value),
      Letter = unname(letter[id]), row.names = NULL)
  }))
  summary$Mean_SD_Letter <- with(summary, sprintf("%.2f ± %.2f%s", Mean, SD, Letter))
  plan <- data.frame(PV_position = c(rep("UP", 3), rep("BP", 3), rep("FS", 3)),
    Comparison = c("OF vs F", "MF vs F", "CK vs F", "OF vs F", "MF vs F", "CK vs F",
                   "BPOF vs FS", "BPMF vs FS", "BPF vs FS"),
    Left = c("OF_UP", "MF_UP", "CK_UP", "OF_BP", "MF_BP", "CK_BP", "OF_BP", "MF_BP", "F_BP"),
    Reference = c(rep("F_UP", 3), rep("F_BP", 3), rep("FS", 3)))
  effects <- do.call(rbind, lapply(seq_len(nrow(plan)), function(i) {
    x <- d$Value[as.character(d$Treatment) == plan$Left[i]]
    ref <- d$Value[as.character(d$Treatment) == plan$Reference[i]]
    g <- hedges_g(x, ref)
    j <- which((result_pairs$Left == plan$Left[i] & result_pairs$Right == plan$Reference[i]) |
               (result_pairs$Right == plan$Left[i] & result_pairs$Left == plan$Reference[i]))
    if (length(j) != 1L) stop("未找到唯一的 Tukey 对照。")
    g$p_Tukey <- result_pairs$p_Tukey[j]
    g$Significance_Tukey <- sig_code(g$p_Tukey)
    g$Hedges_g_95CI <- sprintf("%.2f [%.2f, %.2f]", g$Hedges_g,
      g$CI95_low_pointwise, g$CI95_high_pointwise)
    # Cohen 式阈值只是一种描述性分类，不代表作物科学中的实际重要性。
    g$Effect_size_conventional <- as.character(cut(abs(g$Hedges_g),
      c(-Inf, .2, .5, .8, Inf), right = FALSE,
      labels = c("Negligible", "Small", "Medium", "Large")))
    cbind(Indicator = metric, Year = as.integer(year), plan[i, , drop = FALSE], g)
  }))
  d$Abs_deviation <- abs(d$Value - ave(d$Value, d$TreatmentID, FUN = stats::median))
  bf <- stats::anova(stats::lm(Abs_deviation ~ TreatmentID, data = d))
  resid <- stats::residuals(model)
  diag <- data.frame(Indicator = metric, Year = as.integer(year), N = nrow(d),
    Residual_Df = stats::df.residual(model), Residual_SD = stats::sigma(model),
    Shapiro_p = stats::shapiro.test(resid)$p.value,
    Brown_Forsythe_p = bf[["Pr(>F)"]][1],
    Max_abs_studentized_residual = max(abs(stats::rstudent(model))),
    Max_Cooks_distance = max(stats::cooks.distance(model)))
  list(summary = summary, tukey = result_pairs, hedges = effects, diagnostics = diag,
       model = model)
}

run_all <- function() {
  d <- read_data()
  # FS 仍保留为单独的位置和施肥水平；展示完整设计的可估计性。
  cells <- as.data.frame(xtabs(~ Year + Position + Fertilization, data = d),
    responseName = "N")
  names(cells)[4] <- "N"
  XF <- stats::model.matrix(~ Position * Fertilization * Year, data = d,
    contrasts.arg = list(Position = "contr.sum", Fertilization = "contr.sum", Year = "contr.sum"))
  design <- data.frame(Year_levels = nlevels(d$Year), Position_levels = nlevels(d$Position),
    Fertilization_levels = nlevels(d$Fertilization), Theoretical_cells = nrow(cells),
    Empty_cells = sum(cells$N == 0), Design_columns = ncol(XF), Matrix_rank = qr(XF)$rank,
    Full_factorial_typeIII_estimable = qr(XF)$rank == ncol(XF))
  # 主模型只包含完整的 2×4×3 因子；三指标中只产量有三年数据。
  factorial_all <- d[as.character(d$Position) %in% c("UP", "BP"), , drop = FALSE]
  anova3 <- list(); combined <- list(); availability <- list()
  summary <- list(); pairs <- list(); effects <- list(); diag <- list(); skips <- list()
  for (metric in METRICS) {
    complete <- is.finite(d[[metric]])
    m <- d[complete, , drop = FALSE]
    per_cell <- xtabs(~ Year + Treatment, data = m, drop.unused.levels = FALSE)
    available <- data.frame(Indicator = metric, Year = as.integer(YEARS),
      n_valid = rowSums(per_cell), n_missing = as.integer(tapply(!complete, d$Year, sum)[YEARS]),
      Min_cell_n = apply(per_cell, 1, min), Max_cell_n = apply(per_cell, 1, max),
      Nine_treatments_analyzable = apply(per_cell, 1, function(v) all(v >= 2L)))
    availability[[metric]] <- available
    f <- factorial_all[is.finite(factorial_all[[metric]]), , drop = FALSE]
    f$Position <- droplevels(f$Position); f$Fertilization <- droplevels(f$Fertilization)
    f$Year <- droplevels(f$Year); f$Value <- f[[metric]]
    m$Year <- droplevels(m$Year); m$TreatmentID <- droplevels(m$TreatmentID); m$Value <- m[[metric]]
    if (nlevels(f$Year) == 3L && nlevels(f$Position) == 2L && nlevels(f$Fertilization) == 4L &&
        all(xtabs(~ Position + Fertilization + Year, data = f) >= 2L)) {
      fit <- stats::lm(Value ~ Position * Fertilization * Year, data = f,
        contrasts = list(Position = "contr.sum", Fertilization = "contr.sum", Year = "contr.sum"))
      anova3[[metric]] <- cbind(Indicator = metric, N = nrow(f), type3_lm(fit))
    } else skips[[paste0(metric, "_three_factor")]] <- data.frame(Indicator = metric,
      Analysis = "Position×Fertilization×Year", Reason = "三个年份或完整 UP/BP×四施肥单元数据不足")
    if (nlevels(m$Year) == 3L && nlevels(m$TreatmentID) == 9L &&
        all(xtabs(~ TreatmentID + Year, data = m) >= 2L)) {
      fit <- stats::lm(Value ~ TreatmentID * Year, data = m,
        contrasts = list(TreatmentID = "contr.sum", Year = "contr.sum"))
      combined[[metric]] <- cbind(Indicator = metric, N = nrow(m), type3_lm(fit))
    } else skips[[paste0(metric, "_nine_treatment_year")]] <- data.frame(Indicator = metric,
      Analysis = "Treatment×Year (含FS)", Reason = "三个年份或九处理单元数据不足")
    for (year in YEARS) {
      key <- paste(metric, year, sep = "_")
      if (!available$Nine_treatments_analyzable[available$Year == as.integer(year)]) {
        skips[[key]] <- data.frame(Indicator = metric, Analysis = paste0(year, " 年九处理比较"),
          Reason = "九处理存在缺失或少于两个有效观测")
        next
      }
      r <- analyse_year(d, metric, year)
      summary[[key]] <- r$summary; pairs[[key]] <- r$tukey
      effects[[key]] <- r$hedges; diag[[key]] <- r$diagnostics
    }
  }
  bind <- function(x) if (length(x)) do.call(rbind, x) else data.frame(Status = "无可估计结果")
  out <- list("01_各年处理均值SD_Tukey字母.csv" = bind(summary),
    "02_三因素TypeIII_UPBP四施肥.csv" = bind(anova3),
    "03_九处理与年份TypeIII_含FS.csv" = bind(combined),
    "04_每年九处理_Tukey全部比较.csv" = bind(pairs),
    "05_每年Hedgesg_九个指定对照.csv" = bind(effects),
    "06_每年模型诊断.csv" = bind(diag),
    "07_指标年份数据可用性.csv" = bind(availability),
    "08_结构性空单元检查.csv" = cells,
    "09_完整模型秩检查.csv" = design,
    "10_未执行分析及原因.csv" = bind(skips),
    "11_输入数据及年份换算记录.csv" = d)
  dir.create(OUTPUT_DIR, recursive = TRUE, showWarnings = FALSE)
  paths <- file.path(OUTPUT_DIR, c(names(out), "12_方法与版本.txt"))
  if (!OVERWRITE && any(file.exists(paths)))
    stop("输出文件已存在；需要替换时设置 OVERWRITE <- TRUE，或更换 OUTPUT_DIR。")
  for (name in names(out)) utils::write.csv(out[[name]], file.path(OUTPUT_DIR, name),
    row.names = FALSE, fileEncoding = "UTF-8", na = "")
  notes <- c("Year treated as fixed; plot independence is assumed and must match the true field design.",
    "Full Position x Fertilization x Year with FS is rank deficient due to structural empty cells.",
    "Estimable Type III factorial: UP/BP x CK/F/OF/MF x Year; FS excluded.",
    "All nine observed management combinations including FS: Treatment x Year Type III.",
    "Year-specific Tukey-Kramer: each outcome-year family includes all 36 pairwise comparisons.",
    "Hedges g = treatment minus reference, pair-specific pooled SD and exact small-sample J.",
    "g pointwise 95% CI is unadjusted; p_Tukey is based on nine-group residual variance and multiplicity adjustment.",
    "Year-specific treatment groups sharing a letter are not shown to be different; this does not prove equivalence.",
    "Workbook yield formulas: 2024/25 E*4, 2026 G*1.1364; units and area conversion remain unverified.",
    paste("Yield year multipliers:", paste(names(YEAR_YIELD_MULTIPLIER), YEAR_YIELD_MULTIPLIER, collapse = "; ")),
    paste("Input:", INPUT_FILE), paste("Input MD5:", unname(tools::md5sum(INPUT_FILE))),
    utils::capture.output(utils::sessionInfo()))
  writeLines(enc2utf8(notes), file.path(OUTPUT_DIR, "12_方法与版本.txt"), useBytes = TRUE)
  warning("跨年产量计算公式不同；请核实三年单位及面积换算一致，再解释年份和年份交互作用。")
  message("检验结果已保存：", OUTPUT_DIR)
  invisible(list(data = d, tables = out, design = design))
}

# 为核验函数提供只读测试开关；正常在 RStudio 从头运行时会执行分析。
if (!identical(Sys.getenv("EASYPLOT_FUNCTIONS_ONLY"), "1")) analysis_results <- run_all()
