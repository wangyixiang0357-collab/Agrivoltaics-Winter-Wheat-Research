# =============================================================
# 小麦：每个 Stage × Position × Fertilization 组合 6 个重复
# 每一行保留为一个观测，不把 6 行取均值，不扩增数据。
# 流程：读取 → 检查 → 8 个核心处理估计参数 → 核心与 FS 同尺度转换
# 本脚本停在 PCA 之前，不拟合 PCA，不计算 PC 得分。
#
# 当前工作簿：144 行核心样本 + 6 行开花期 FS；31 个数值指标。
# FS 不参与阶段均值、合并阶段内 SD 或 PCA 载荷的估计。
# FS 使用开花期核心样本均值及三期核心样本共同 SD 进行转换。
# 注意：Replicate 是组内行序编号，不等于真实 PlotID，不能用于跨期配对。
# 各指标应来自同一采样单位；独立小区/子样本身份需要由实验记录确认。
# =============================================================

# 0. 配置 ------------------------------------------------------
input_file <- paste0(
  "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/",
  "小麦光合生理/附件单指标图/完整指标第三版.xlsx"
)
sheet_name <- "Sheet1"
expected_replicates <- 6L
FS_stage <- "Anthesis stage"

stage_levels <- c("Erecting stage", "Jointing stage", "Anthesis stage")
stage_codes <- c("Erecting stage" = "E", "Jointing stage" = "J",
                 "Anthesis stage" = "A")

# 依照这份工作簿 D:AH 的实际顺序命名，便于处理空格和特殊字符。
all_vars <- c(
  "PlantHeight", "LeafAreaIndex", "SpecificLeafArea",
  "AbovegroundBiomass", "RootBiomass", "AbovegroundN",
  "RootNConcentration", "RootN", "AbovegroundCConcentration",
  "RootCConcentration", "AbovegroundCN", "RootCN", "POD", "SOD",
  "Rubisco", "CAT", "SolubleSugar", "MDA", "Proline", "SolubleProtein",
  "Chla", "Chlb", "ChlTotal", "ChlaChlb", "RootActivity", "REC",
  "FvFm", "PhiPSII", "qL", "NPQ", "YNO"
)

# 本版保留全部 31 个指标。如已明确选定指标，只在这里修改。
vars <- all_vars
# 例如，若决定仅保留叶绿素 a、b 而去掉总量及比值：
# vars <- setdiff(all_vars, c("ChlTotal", "ChlaChlb"))
# 或指定指标：vars <- c("PlantHeight", "AbovegroundBiomass", "PhiPSII", "qL", "NPQ")

project_dir <- dirname(dirname(dirname(input_file)))
out_dir <- file.path(
  project_dir, "output", "PCA前处理_每处理6重复_20261005",
  "结果_FS补充映射"
)

# 使用项目已有 readxl。不会自动安装任何包。
local_library <- file.path(project_dir, ".Rlib")
if (dir.exists(local_library)) .libPaths(c(local_library, .libPaths()))
if (!requireNamespace("readxl", quietly = TRUE)) {
  stop("缺少 readxl。请先在 R 控制台运行 install.packages('readxl')，再运行本脚本。")
}
stopifnot(file.exists(input_file), length(vars) >= 2L,
          !anyDuplicated(vars), all(vars %in% all_vars))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# 保存 CSV，数值不提前四舍五入。
write_csv <- function(x, filename) {
  old_options <- options(digits = 17)
  on.exit(options(old_options), add = TRUE)
  write.csv(x, file.path(out_dir, filename), row.names = FALSE,
            fileEncoding = "UTF-8", na = "NA")
}

# 1. 读取并核对表头 --------------------------------------------
# 全部按文本读取，然后严格转为数值，避免非数值单元格被静默转成 NA。
# readxl 读取 Excel 公式已保存的计算值；不在 R 中重新计算 Excel 公式。
raw_excel <- as.data.frame(
  readxl::read_excel(input_file, sheet = sheet_name, col_types = "text",
                    .name_repair = "minimal"),
  check.names = FALSE, stringsAsFactors = FALSE
)
original_names <- trimws(names(raw_excel))

# 以下是已核对的原始表头。源文件保持不变。
expected_headers <- c(
  "Stage", "Fertilization", "Location", "Plant height", "Leaf area index",
  "Specific leaf area", "Aboveground biomass", "Root biomass", "AbovegroundN",
  "root N(g/kg)", "RootN", "Aboveground C(g/kg)", "root C(g/kg)",
  "AbovegroundC: N", "RootC: N", "POD (U/g FW)", "SOD (U/g)",
  "Rubisco activity（nmol NADH/min/g/FW）", "CAT (nmol/min/g FW)",
  "Soluble sugar", "MDA(nmol/g FW)", "PRO(μmol/g FW)", "Soluble protein",
  "chla(mg/g FW）", "chlb(mg/g FW）", "chla+b(mg/g FW）", "chla/chlb",
  "Root activity (μg g-1 h-1)", "REC (%)", "Fv/Fm", "ΦPSII", "qL", "NPQ", "Y(NO)"
)
if (!identical(original_names, expected_headers)) {
  stop("工作表的列数、列名或顺序与已核对版本不同，请核对列名映射后再运行。")
}

new_names <- c("Stage", "Fertilization", "Position", all_vars)
variable_dictionary <- data.frame(
  ExcelColumnNumber = seq_along(new_names),
  OriginalName = original_names,
  RName = new_names,
  SelectedForPCA = new_names %in% vars,
  stringsAsFactors = FALSE
)
write_csv(variable_dictionary, "01_列名对照.csv")
names(raw_excel) <- new_names

# 清理字符前后的空格，不改变任何原始数值的单位。
for (v in new_names) raw_excel[[v]] <- trimws(raw_excel[[v]])
for (v in c("Stage", "Position", "Fertilization")) {
  if (anyNA(raw_excel[[v]]) || any(raw_excel[[v]] == "")) {
    stop(paste("分组信息缺失：", v))
  }
}
if (any(!raw_excel$Stage %in% stage_levels)) stop("出现未定义的生育期。")

# 严格数值转换；零是有效数值，空值不替换为零。
missing_tokens <- c("", "NA", "N/A", "NaN", "NULL")
numeric_data <- raw_excel
for (v in all_vars) {
  text_values <- raw_excel[[v]]
  is_missing <- is.na(text_values) | text_values %in% missing_tokens
  text_values[is_missing] <- NA_character_
  numeric_values <- suppressWarnings(as.numeric(text_values))
  bad <- !is_missing & !is.finite(numeric_values)
  if (any(bad)) {
    bad_rows <- which(bad) + 1L
    stop(sprintf("%s 存在非数值或无穷值，Excel 行号：%s",
                 v, paste(bad_rows, collapse = ", ")))
  }
  numeric_data[[v]] <- numeric_values
}

# 2. 为每一行标记重复，核对 6 个重复 -----------------------------
# ave 按组合分组，但保留原表顺序；每组独立编号 1:6。
group_key <- paste(numeric_data$Stage, numeric_data$Position,
                   numeric_data$Fertilization, sep = "_")
Replicate <- as.integer(ave(seq_len(nrow(numeric_data)), group_key,
                            FUN = seq_along))
is_FS <- numeric_data$Position == "FS" | numeric_data$Fertilization == "FS"
if (any(is_FS & !(numeric_data$Position == "FS" &
                  numeric_data$Fertilization == "FS" &
                  numeric_data$Stage == FS_stage))) {
  stop("FS 必须同时标记 Position=FS、Fertilization=FS，且仅出现在开花期。")
}
metadata_all <- data.frame(
  SampleID = paste(unname(stage_codes[numeric_data$Stage]),
                   numeric_data$Position, numeric_data$Fertilization,
                   sprintf("R%02d", Replicate), sep = "_"),
  ExcelRow = seq_len(nrow(numeric_data)) + 1L,
  Stage = numeric_data$Stage,
  Position = numeric_data$Position,
  Fertilization = numeric_data$Fertilization,
  Replicate = Replicate,
  AnalysisRole = ifelse(is_FS, "Supplementary", "Core"),
  stringsAsFactors = FALSE
)
stopifnot(!anyDuplicated(metadata_all$SampleID))
clean_all <- cbind(metadata_all, numeric_data[, all_vars, drop = FALSE])

# 保留全部 150 行，但明确区分用于参数估计的 Core 和待映射的 Supplementary。
dat <- clean_all
rownames(dat) <- rownames(metadata_all) <- metadata_all$SampleID
is_core <- metadata_all$AnalysisRole == "Core"
metadata_core <- metadata_all[is_core, , drop = FALSE]
metadata_FS <- metadata_all[!is_core, , drop = FALSE]

counts_observed <- aggregate(
  list(n = rep(1L, nrow(dat))),
  by = dat[, c("Stage", "Position", "Fertilization")], FUN = sum
)
# 同时检查计划中整个组合是否缺失，而不只检查已有组合。
planned_groups <- expand.grid(
  Stage = stage_levels, Position = c("UP", "BP"),
  Fertilization = c("F", "OF", "MF", "CK"),
  stringsAsFactors = FALSE
)
planned_groups <- rbind(
  planned_groups,
  data.frame(Stage = FS_stage, Position = "FS", Fertilization = "FS")
)
counts <- merge(planned_groups, counts_observed,
                by = c("Stage", "Position", "Fertilization"), all = TRUE)
counts$n[is.na(counts$n)] <- 0L
planned_key <- with(planned_groups, paste(Stage, Position, Fertilization))
counts$Planned <- with(counts, paste(Stage, Position, Fertilization)) %in% planned_key
counts$ExactlySix <- counts$n == expected_replicates & counts$Planned
counts$AnalysisRole <- ifelse(counts$Position == "FS", "Supplementary", "Core")
write_csv(counts, "02_重复数检查.csv")
if (!all(counts$ExactlySix)) {
  stop("有组合缺失、重复数不等于 6 或出现计划外组合，详见 02_重复数检查.csv。")
}
write_csv(dat, "03_数值化原始数据.csv")

# 3. 质量检查：缺失与异常值 -------------------------------------
X_all <- as.matrix(dat[, vars, drop = FALSE])
storage.mode(X_all) <- "double"
rownames(X_all) <- metadata_all$SampleID
X_core <- X_all[is_core, , drop = FALSE]
X_FS <- X_all[!is_core, , drop = FALSE]
st_core <- factor(metadata_core$Stage, levels = stage_levels)
stage_indices_core <- split(seq_len(nrow(X_core)), st_core, drop = TRUE)
stage_indices_all <- split(seq_len(nrow(X_all)),
                           factor(metadata_all$Stage, levels = stage_levels), drop = TRUE)

quality_summary <- data.frame(
  Variable = vars,
  n_missing_core = colSums(is.na(X_core)),
  n_missing_FS = colSums(is.na(X_FS)),
  Min = apply(X_all, 2, function(x) if (all(is.na(x))) NA_real_ else min(x, na.rm = TRUE)),
  Median = apply(X_all, 2, function(x) if (all(is.na(x))) NA_real_ else median(x, na.rm = TRUE)),
  Max = apply(X_all, 2, function(x) if (all(is.na(x))) NA_real_ else max(x, na.rm = TRUE)),
  row.names = NULL
)
write_csv(quality_summary, "04_数值与缺失检查.csv")
if (anyNA(X_all)) {
  stop("所选 PCA 指标存在缺失值。本脚本停止处理，不填补或删除重复；请先核对原始数据。")
}
stopifnot(all(is.finite(X_all)))

# 阶段内 1.5×IQR 界限也由核心样本确定，用于核查核心和 FS；不自动删除。
# FS 偏离核心分布可以是实际处理差异，核查标记不等于测量错误。
outlier_flags <- cbind(
  metadata_all[FALSE, , drop = FALSE],
  Variable = character(), Value = numeric(), Lower = numeric(), Upper = numeric()
)
for (s in names(stage_indices_all)) {
  idx <- stage_indices_all[[s]]
  idx_ref <- idx[is_core[idx]]
  for (v in vars) {
    values <- X_all[idx, v]
    q <- quantile(X_all[idx_ref, v], c(0.25, 0.75), names = FALSE)
    lower <- q[1] - 1.5 * diff(q)
    upper <- q[2] + 1.5 * diff(q)
    flagged <- idx[values < lower | values > upper]
    if (length(flagged)) {
      outlier_flags <- rbind(outlier_flags, cbind(
        metadata_all[flagged, , drop = FALSE],
        Variable = v, Value = X_all[flagged, v], Lower = lower, Upper = upper
      ))
    }
  }
}
write_csv(outlier_flags, "05_异常值待核查.csv")
duplicated_values <- duplicated(X_all) | duplicated(X_all, fromLast = TRUE)
if (any(duplicated_values)) {
  message("有不同行的全部所选数值完全一致，请检查复制记录；本脚本保留这些行。")
}

# 4. 只用 Core 估计参数，将同一套参数应用于全部观测 ----------------
# 函数保留原行序；FS 数值不会进入阶段均值或合并 SD 的计算。
stage_adjusted_transform <- function(X, stage, is_core, stage_levels) {
  if (!is.matrix(X) || !is.numeric(X) || ncol(X) < 2L ||
      is.null(colnames(X)) || anyDuplicated(colnames(X)) ||
      !all(is.finite(X)) || length(stage) != nrow(X) ||
      !is.logical(is_core) || length(is_core) != nrow(X) ||
      anyNA(is_core) || !any(is_core)) {
    stop("标准化函数的输入矩阵、Stage 或 Core 标记无效。")
  }
  stage <- factor(as.character(stage), levels = stage_levels)
  if (anyNA(stage)) stop("标准化函数出现未知或缺失 Stage。")
  idx_ref <- split(which(is_core), stage[is_core], drop = FALSE)
  if (any(lengths(idx_ref) < 2L)) {
    stop("各参考生育期至少需要 2 个核心样本；FS 不能补足核心样本量。")
  }

  # 均值：每个 Stage 内的 8 个核心处理，48 行；不减处理组合均值。
  mu_ref <- t(vapply(
    idx_ref, function(idx) colMeans(X[idx, , drop = FALSE]),
    numeric(ncol(X))
  ))
  colnames(mu_ref) <- colnames(X)
  R_all <- X - mu_ref[as.character(stage), colnames(X), drop = FALSE]

  # SD：仅合并核心样本的阶段内残差；N_core=144、K=3、df=141。
  N_core <- sum(is_core)
  K <- length(idx_ref)
  residual_df <- N_core - K
  sd_ref <- sqrt(colSums(R_all[is_core, , drop = FALSE]^2) / residual_df)
  invalid_sd <- !is.finite(sd_ref) | sd_ref <= 0
  if (any(invalid_sd)) {
    stop(paste("以下指标没有核心样本阶段内变异，请从 vars 中明确移除：",
               paste(names(sd_ref)[invalid_sd], collapse = ", ")))
  }

  # FS 减去开花期核心均值，再除以三期核心样本共同 SD。
  # FS 不自行中心化，不自行求 SD，也不使用其原始值直接投影。
  Z_all <- sweep(R_all, 2, sd_ref, FUN = "/")
  list(stage_means_matrix = mu_ref, pooled_within_sd = sd_ref,
       residuals_all = R_all, Z_all = Z_all,
       Z_core = Z_all[is_core, , drop = FALSE],
       Z_FS = Z_all[!is_core, , drop = FALSE],
       N_core = N_core, K = K, residual_df = residual_df)
}

transformed <- stage_adjusted_transform(
  X_all, metadata_all$Stage, is_core, stage_levels
)
stage_means_matrix <- transformed$stage_means_matrix
pooled_within_sd <- transformed$pooled_within_sd
R_all <- transformed$residuals_all
R_core <- R_all[is_core, , drop = FALSE]
R_FS <- R_all[!is_core, , drop = FALSE]
Z_all <- transformed$Z_all
Z_core <- transformed$Z_core
Z_FS <- transformed$Z_FS
N <- transformed$N_core
K <- transformed$K
residual_df <- transformed$residual_df

# Z 和 metadata 的兼容名称指向核心样本，确保后续 prcomp(Z) 不含 FS。
Z <- Z_core
metadata <- metadata_core
X <- X_core
R <- R_core

# 5. 保存核心参数及核心/FS 标准化矩阵 -----------------------------
stage_means <- data.frame(
  Stage = rownames(stage_means_matrix), n_core = lengths(stage_indices_core),
  stage_means_matrix, check.names = FALSE, row.names = NULL
)
scale_parameters <- data.frame(
  Variable = vars, PooledWithinSD = unname(pooled_within_sd),
  N_core = N, K = K, ResidualDF = residual_df
)
write_csv(stage_means, "06_核心处理各生育期指标均值.csv")
write_csv(scale_parameters, "07_核心处理共同阶段内标准差.csv")
write_csv(cbind(metadata_all, as.data.frame(R_all)), "08_核心及FS相对核心均值的残差.csv")
write_csv(cbind(metadata_all, as.data.frame(Z_all)), "09_PCA前标准化数据_含FS映射.csv")
write_csv(cbind(metadata_core, as.data.frame(Z_core)), "12_核心处理标准化数据.csv")
write_csv(cbind(metadata_FS, as.data.frame(Z_FS)), "13_FS标准化映射.csv")

# 6. 自检：核心指标 ~ Stage 的残差、SD，以及 FS 的模型参考值 -------
Z_stage_means <- t(vapply(
  stage_indices_core, function(idx) colMeans(Z_core[idx, , drop = FALSE]),
  numeric(length(vars))
))
lm_residual_error <- lm_sd_error <- fs_mapping_error <- numeric(length(vars))
for (j in seq_along(vars)) {
  fit <- stats::lm(X_core[, j] ~ st_core)
  sd_lm <- sqrt(stats::deviance(fit) / stats::df.residual(fit))
  lm_residual_error[j] <- max(abs(stats::residuals(fit) - R_core[, j])) / pooled_within_sd[j]
  lm_sd_error[j] <- abs(sd_lm / pooled_within_sd[j] - 1)
  fs_stage_mean_lm <- stats::predict(
    fit, newdata = data.frame(st_core = factor(metadata_FS$Stage, levels = stage_levels))
  )
  fs_mapping_error[j] <- max(abs((X_FS[, j] - fs_stage_mean_lm) / sd_lm - Z_FS[, j]))
}
validation <- data.frame(
  Variable = vars,
  MaxAbsCoreStageMean = apply(abs(Z_stage_means), 2, max),
  CoreOverallMean = colMeans(Z_core),
  CorePooledWithinSD_Z = sqrt(colSums(Z_core^2) / residual_df),
  CoreOrdinarySD_Z = apply(Z_core, 2, sd),
  ExpectedCoreOrdinarySD_Z = sqrt(residual_df / (N - 1L)),
  LMResidualScaledMaxError = lm_residual_error,
  LMSDRelativeError = lm_sd_error,
  FSMappingLMMaxError = fs_mapping_error,
  FSMeanZ = colMeans(Z_FS),
  row.names = NULL
)
write_csv(validation, "10_核心标准化及FS映射自检.csv")
stopifnot(
  all(is.finite(Z_all)),
  all(validation$MaxAbsCoreStageMean < 1e-10),
  all(abs(validation$CoreOverallMean) < 1e-10),
  all(abs(validation$CorePooledWithinSD_Z - 1) < 1e-10),
  all(abs(validation$CoreOrdinarySD_Z - validation$ExpectedCoreOrdinarySD_Z) < 1e-10),
  all(validation$LMResidualScaledMaxError < 1e-10),
  all(validation$LMSDRelativeError < 1e-10),
  all(validation$FSMappingLMMaxError < 1e-10),
  identical(rownames(Z_core), metadata_core$SampleID),
  identical(rownames(Z_FS), metadata_FS$SampleID),
  identical(rownames(Z_all), metadata_all$SampleID),
  identical(colnames(Z_core), colnames(Z_FS))
)

# 只有核心样本满足阶段均值≈0、合并阶段内 SD≈1。
# FS 的均值、SD，以及合并全部 150 行的均值、SD 不要求满足这些条件。
# 不再对 Z_core、Z_FS 或 Z_all 使用 scale()，不默认取对数或翻转指标方向。

# 7. 相关性和数值秩也只基于核心样本，供正式 PCA 前选指标 ---------
correlation <- stats::cor(Z_core)
pairs <- which(upper.tri(correlation) & abs(correlation) >= 0.95, arr.ind = TRUE)
high_correlations <- data.frame(
  Variable1 = colnames(Z_core)[pairs[, 1]],
  Variable2 = colnames(Z_core)[pairs[, 2]],
  r = correlation[pairs]
)
write_csv(high_correlations, "11_核心处理高相关指标对.csv")

singular_values <- svd(Z_core, nu = 0, nv = 0)$d
rank_tolerance <- max(dim(Z_core)) * max(singular_values) * .Machine$double.eps
matrix_rank <- sum(singular_values > rank_tolerance)
if (matrix_rank < ncol(Z_core)) {
  message(sprintf("Z_core 的数值秩为 %d，指标数为 %d，存在冗余；请结合指标定义决定是否筛选。",
                  matrix_rank, ncol(Z_core)))
}
if (all(c("Chla", "Chlb", "ChlTotal") %in% vars)) {
  chl_sum_error <- max(abs(X_core[, "ChlTotal"] - X_core[, "Chla"] - X_core[, "Chlb"]))
  message(sprintf("叶绿素总量与 a+b 的最大绝对差：%.3g。三个指标同时纳入会重复表示信息。",
                  chl_sum_error))
}

# 8. 保存 PCA 输入对象 ------------------------------------------
# 核心和 FS 分开存储；Z_all 仅供一起查看，不能用于拟合这套核心 PCA。
pca_input <- list(
  Z = Z_core, metadata = metadata_core,
  Z_core = Z_core, metadata_core = metadata_core,
  Z_FS = Z_FS, metadata_FS = metadata_FS,
  Z_all = Z_all, metadata_all = metadata_all,
  selected_raw = X_core, selected_raw_FS = X_FS, selected_raw_all = X_all,
  residuals = R_core, residuals_FS = R_FS, residuals_all = R_all,
  stage_means = stage_means,
  pooled_within_sd = pooled_within_sd,
  variable_dictionary = variable_dictionary,
  group_counts = counts,
  validation = validation,
  quality_summary = quality_summary,
  outlier_flags = outlier_flags,
  duplicated_value_rows = metadata_all[duplicated_values, , drop = FALSE],
  high_correlations = high_correlations,
  matrix_rank = matrix_rank,
  config = list(input_file = input_file, sheet = sheet_name, vars = vars,
                FS_role = "supplementary", FS_stage = FS_stage,
                parameter_reference = "8个核心处理，不含FS",
                missing_policy = "停止，不填补、不删除",
                N = N, N_core = N, N_FS = nrow(Z_FS), N_all = nrow(Z_all),
                K = K, residual_df = residual_df,
                replicate_definition = "组内原始行序编号，非真实小区标识"),
  input_md5 = unname(tools::md5sum(input_file)),
  session_info = utils::sessionInfo()
)
saveRDS(pca_input, file.path(out_dir, "PCA_input.rds"))
writeLines(c(
  sprintf("输入：%s；工作表：%s", input_file, sheet_name),
  sprintf("核心 %d 行；FS %d 行；合计保留 %d 行。", N, nrow(Z_FS), nrow(Z_all)),
  sprintf("Z_core：%d×%d；Z_FS：%d×%d；K=%d；N_core-K=%d；核心数值秩=%d。",
          N, ncol(Z_core), nrow(Z_FS), ncol(Z_FS), K, residual_df, matrix_rank),
  "每个计划组合均为 6 行。每一行单独保留。",
  "均值和共同阶段内 SD 只由 8 个核心处理确定。",
  "FS 使用开花期核心均值及三期核心样本共同 SD 转换。",
  "FS 均值无需为零；合计 150 行均值无需为零。",
  "异常值只标记；未自动删除记录、填补缺失、取对数或剔除高相关指标。",
  "未执行 PCA。后续仅以 Z_core 拟合，再用 predict(pca, newdata=Z_FS) 投影。",
  "Replicate 不代表跨期小区配对。原 Excel 文件未修改。",
  "参考：https://readxl.tidyverse.org/reference/read_excel.html",
  "参考：https://stat.ethz.ch/R-manual/R-devel/library/stats/html/prcomp.html",
  capture.output(utils::sessionInfo())
), file.path(out_dir, "运行记录.txt"), useBytes = TRUE)

print(table(metadata_all$Stage, metadata_all$AnalysisRole))
cat(sprintf("\n前处理完成：Z_core=%d×%d，Z_FS=%d×%d；N_core-K=%d。\n",
            N, ncol(Z_core), nrow(Z_FS), ncol(Z_FS), residual_df))
cat("输出目录：", out_dir, "\n")
cat("PCA 输入对象已保存为 PCA_input.rds。\n")

# 到这里结束。以后正式进行 PCA 时才运行下面三行：
# obj <- readRDS(file.path(out_dir, "PCA_input.rds"))
# pca <- stats::prcomp(obj$Z_core, center = FALSE, scale. = FALSE)
# scores_FS <- stats::predict(pca, newdata = obj$Z_FS)
# 若按模块 PCA，则两矩阵选取同一模块列，并保持相同列名和顺序。
# 不默认对 PC 分数再次按 Stage 标准化。
# 如另有明确目的要做 PC 分数标准化，Stage 均值及 SD 也只由核心分数估计，
# FS 仍使用开花期核心分数的参数；FS 不能参与参数估计。
