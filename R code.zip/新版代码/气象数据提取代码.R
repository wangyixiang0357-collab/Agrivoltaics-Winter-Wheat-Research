library(readxl)
library(dplyr)
library(lubridate)
library(stringr)
library(hms)
library(tidyr)
library(writexl)
library(tibble)

# =========================================================
# 气象数据一次性提取
# 输出内容：
# 1. 光照/辐射日汇总 + 白天原始数据
#    光照数据固定提取 L 列（总辐射）与 M 列（光合辐射）
# 2. 土壤温度/土壤水分分层日汇总
# 3. 空气温度/降雨量日汇总
# =========================================================

rm(list = ls())

# =========================
# 1. 选择文件并读取
# =========================
infile <- file.choose()
raw <- read_excel(infile, sheet = 1, col_names = FALSE)

# =========================
# 2. 通用辅助函数
# =========================
find_header_row <- function(x, max_scan = 80) {
  key_pattern <- paste(
    c(
      "记录时间", "时间",
      "总辐射", "光合辐射", "光照",
      "土壤温度", "土壤水分",
      "空气温度", "雨量"
    ),
    collapse = "|"
  )

  for (r in 1:min(max_scan, nrow(x))) {
    vals <- as.character(unlist(x[r, ], use.names = FALSE))
    if (any(str_detect(vals, key_pattern), na.rm = TRUE)) return(r)
  }

  NA_integer_
}

clean_header_names <- function(nm) {
  nm <- as.character(nm)
  nm[is.na(nm)] <- ""
  nm <- trimws(nm)
  bad <- nm == ""
  nm[bad] <- paste0("V", which(bad))
  make.unique(nm, sep = ".")
}

parse_rate <- function(v) {
  x <- parse_date_time(
    as.character(v),
    orders = c("ymd HMS", "ymd HM", "Ymd HMS", "Ymd HM"),
    tz = "Asia/Shanghai",
    quiet = TRUE
  )
  mean(!is.na(x))
}

detect_time_col <- function(dat, header_vals) {
  time_idx <- which(str_detect(header_vals, "记录时间|时间$"))[1]

  if (!is.na(time_idx)) {
    return(names(dat)[time_idx])
  }

  rates <- sapply(dat, parse_rate)
  time_idx <- which.max(rates)

  if (length(time_idx) == 0 || is.na(rates[time_idx]) || rates[time_idx] < 0.5) {
    top5 <- sort(rates, decreasing = TRUE)[1:min(5, length(rates))]
    stop(
      "Cannot reliably detect timestamp column.\nTop candidates:\n",
      paste(names(top5), round(top5, 3), sep = " = ", collapse = "\n")
    )
  }

  names(dat)[time_idx]
}

add_timestamp <- function(dat, time_col) {
  dat %>%
    mutate(
      timestamp_raw = .data[[time_col]],
      timestamp = parse_date_time(
        as.character(timestamp_raw),
        orders = c("ymd HMS", "ymd HM", "Ymd HMS", "Ymd HM"),
        tz = "Asia/Shanghai",
        quiet = TRUE
      ),
      date = as.Date(timestamp)
    ) %>%
    filter(!is.na(timestamp))
}

estimate_dt_seconds <- function(dat_ts) {
  dt_seconds <- dat_ts %>%
    arrange(timestamp) %>%
    mutate(dt = as.numeric(difftime(timestamp, lag(timestamp), units = "secs"))) %>%
    summarise(dt_med = median(dt, na.rm = TRUE)) %>%
    pull(dt_med)

  if (is.na(dt_seconds) || dt_seconds <= 0) dt_seconds <- 1800
  dt_seconds
}

safe_max <- function(x) {
  if (all(is.na(x))) NA_real_ else max(x, na.rm = TRUE)
}

safe_min <- function(x) {
  if (all(is.na(x))) NA_real_ else min(x, na.rm = TRUE)
}

safe_mean <- function(x) {
  if (all(is.na(x))) NA_real_ else mean(x, na.rm = TRUE)
}

# =========================
# 3. 表头识别与基础数据
# =========================
header_row <- find_header_row(raw)
if (is.na(header_row)) {
  stop("Cannot detect header row. Please inspect the first rows of the file.")
}

header_vals <- as.character(unlist(raw[header_row, ], use.names = FALSE))
col_names <- clean_header_names(header_vals)

dat <- raw[(header_row + 1):nrow(raw), ]
names(dat) <- col_names

time_col <- detect_time_col(dat, header_vals)
dat_ts <- add_timestamp(dat, time_col)

if (nrow(dat_ts) < 2) {
  stop("Too few valid timestamps after parsing. Check timestamp format.")
}

dt_seconds <- estimate_dt_seconds(dat_ts)
dt_hours <- dt_seconds / 3600

# =========================
# 4. 光照/辐射数据提取
# =========================
extract_solar <- function(dat_ts, dt_seconds) {
  if (ncol(dat_ts) < 13) {
    warning("Solar extraction skipped: fewer than 13 columns. L and M columns are required.")
    return(NULL)
  }

  solar_dat <- dat_ts %>%
    transmute(
      timestamp,
      date,
      tod = hms::as_hms(timestamp),
      total_radiation = as.numeric(.data[[names(dat_ts)[12]]]), # L列：总辐射
      par_radiation = as.numeric(.data[[names(dat_ts)[13]]])    # M列：光合辐射
    ) %>%
    filter(
      tod >= hms::as_hms("06:00:00"),
      tod < hms::as_hms("18:00:00")
    )

  daily_summary <- solar_dat %>%
    group_by(date) %>%
    summarise(
      n_records_daytime = n(),
      total_radiation_day_max = safe_max(total_radiation),
      total_radiation_day_mean = safe_mean(total_radiation),
      par_radiation_day_max = safe_max(par_radiation),
      par_radiation_day_mean = safe_mean(par_radiation),
      total_radiation_MJ_m2_d = sum(total_radiation, na.rm = TRUE) * dt_seconds / 1e6,
      DLI_mol_m2_d = sum(par_radiation, na.rm = TRUE) * dt_seconds / 1e6,
      .groups = "drop"
    ) %>%
    arrange(date)

  list(
    Solar_Daily_Summary = daily_summary,
    Solar_Daytime_Data = solar_dat %>%
      select(timestamp, date, total_radiation, par_radiation) %>%
      arrange(timestamp)
  )
}

# =========================
# 5. 土壤温度/水分数据提取
# =========================
extract_soil <- function(dat_ts, dt_hours) {
  temp_cols <- names(dat_ts)[str_detect(names(dat_ts), "^土壤温度\\d*\\(")]
  moist_cols <- names(dat_ts)[str_detect(names(dat_ts), "^土壤水分\\d*\\(")]

  if (length(temp_cols) == 0 || length(moist_cols) == 0) {
    warning("Soil extraction skipped: cannot find soil temperature or soil moisture columns.")
    return(NULL)
  }

  temp_cols <- temp_cols[1:min(2, length(temp_cols))]
  moist_cols <- moist_cols[1:min(2, length(moist_cols))]

  extract_layer_num <- function(x) {
    m <- str_match(x, "(\\d+)\\(")[, 2]
    ifelse(is.na(m), "1", m)
  }

  temp_map <- tibble(
    temp_col = temp_cols,
    layer = paste0("layer", extract_layer_num(temp_cols))
  )

  moist_map <- tibble(
    moist_col = moist_cols,
    layer = paste0("layer", extract_layer_num(moist_cols))
  )

  temp_long <- dat_ts %>%
    select(timestamp, date, all_of(temp_cols)) %>%
    pivot_longer(cols = all_of(temp_cols), names_to = "temp_col", values_to = "soil_temp_c") %>%
    mutate(soil_temp_c = as.numeric(soil_temp_c)) %>%
    left_join(temp_map, by = "temp_col") %>%
    select(timestamp, date, layer, soil_temp_c)

  moist_long <- dat_ts %>%
    select(timestamp, date, all_of(moist_cols)) %>%
    pivot_longer(cols = all_of(moist_cols), names_to = "moist_col", values_to = "soil_moist_pct") %>%
    mutate(soil_moist_pct = as.numeric(soil_moist_pct)) %>%
    left_join(moist_map, by = "moist_col") %>%
    select(timestamp, date, layer, soil_moist_pct)

  long2 <- temp_long %>%
    left_join(moist_long, by = c("timestamp", "date", "layer"))

  daily_out <- long2 %>%
    group_by(date, layer) %>%
    summarise(
      temp_max_c = safe_max(soil_temp_c),
      temp_min_c = safe_min(soil_temp_c),
      temp_mean_c = safe_mean(soil_temp_c),
      accum_soil_temp_degday = sum(soil_temp_c, na.rm = TRUE) * dt_hours / 24,
      moist_mean_pct = safe_mean(soil_moist_pct),
      .groups = "drop"
    ) %>%
    arrange(date, layer)

  list(Soil_Daily_Summary = daily_out)
}

# =========================
# 6. 空气温度/降雨量数据提取
# =========================
extract_air_rain <- function(dat_ts) {
  temp_col <- names(dat_ts)[str_detect(names(dat_ts), "空气温度")][1]
  rain_today_col <- names(dat_ts)[str_detect(names(dat_ts), "当前雨量|今日雨量")][1]
  rain_yday_col <- names(dat_ts)[str_detect(names(dat_ts), "日雨量|昨日雨量")][1]

  if (is.na(temp_col)) {
    warning("Air temperature extraction skipped: cannot find 空气温度 column.")
    return(NULL)
  }

  if (is.na(rain_today_col) && is.na(rain_yday_col)) {
    warning("Precipitation extraction skipped: cannot find 当前雨量/今日雨量 or 日雨量/昨日雨量.")
  }

  air_dat <- dat_ts %>%
    transmute(
      timestamp,
      date,
      air_temp_c = as.numeric(.data[[temp_col]]),
      rain_today_mm = if (!is.na(rain_today_col)) as.numeric(.data[[rain_today_col]]) else NA_real_,
      rain_yday_mm = if (!is.na(rain_yday_col)) as.numeric(.data[[rain_yday_col]]) else NA_real_
    )

  temp_daily <- air_dat %>%
    group_by(date) %>%
    summarise(
      temp_mean_c = safe_mean(air_temp_c),
      temp_max_c = safe_max(air_temp_c),
      temp_min_c = safe_min(air_temp_c),
      .groups = "drop"
    )

  if (!is.na(rain_today_col)) {
    rain_daily <- air_dat %>%
      group_by(date) %>%
      summarise(precip_mm = safe_max(rain_today_mm), .groups = "drop")
  } else if (!is.na(rain_yday_col)) {
    rain_daily <- air_dat %>%
      group_by(date) %>%
      summarise(precip_mm = safe_max(rain_yday_mm), .groups = "drop") %>%
      mutate(date = date - 1)
  } else {
    rain_daily <- tibble(date = unique(air_dat$date), precip_mm = NA_real_)
  }

  daily_out <- temp_daily %>%
    left_join(rain_daily, by = "date") %>%
    arrange(date)

  list(Air_Temp_Precip_Daily = daily_out)
}

# =========================
# 7. 执行提取并导出
# =========================
solar_out <- extract_solar(dat_ts, dt_seconds)
soil_out <- extract_soil(dat_ts, dt_hours)
air_rain_out <- extract_air_rain(dat_ts)

metadata <- tibble(
  item = c("input_file", "header_row", "time_col", "dt_seconds", "dt_hours", "solar_columns"),
  value = c(
    infile,
    as.character(header_row),
    time_col,
    as.character(dt_seconds),
    as.character(dt_hours),
    "L column = total_radiation; M column = par_radiation"
  )
)

output_sheets <- c(
  list(Metadata = metadata),
  solar_out,
  soil_out,
  air_rain_out
)

output_sheets <- output_sheets[!vapply(output_sheets, is.null, logical(1))]

outfile <- file.path(dirname(infile), "meteorological_daily_extraction_all.xlsx")

write_xlsx(output_sheets, path = outfile)

message(
  "Done. Output written to: ", outfile,
  "\nDetected header_row = ", header_row,
  "\nTimestamp column = ", time_col,
  "\ndt_seconds = ", dt_seconds,
  "\nSolar columns: L = total_radiation, M = par_radiation"
)
