# ============================================================
# 农光互补微环境时间序列绘图
# 1. 温度 + 降雨：一张图，双纵轴，降雨为柱状图
# 2. 空气相对湿度：单独一张图
# 3. DLI：单独一张图
# 不进行图片拼接，不进行平滑或抽样。
# ============================================================

# 首次运行时安装所需包：
# install.packages(c("ggplot2", "dplyr", "tidyr", "svglite", "ragg"))

library(ggplot2)
library(dplyr)
library(tidyr)

# ---------- 1. 文件路径 ----------
data_file <- "C:/Users/Yixiang Wang/Desktop/项目区气象数据/空气温湿度.csv"
output_dir <- file.path(dirname(data_file), "微环境图片")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

# ---------- 2. 颜色与类别 ----------
# UP = 光伏板下；BP = 光伏板间；FS = 无光伏板对照。
micro_colors <- c(
  "Under-panel" = "#4477AA",
  "Inter-panel" = "#6FA8DC",
  "Open-field control" = "#F0E442"
)

micro_levels <- names(micro_colors)
rain_color <- "#A9BBC6"

# 时间序列线和点的统一尺寸。
time_line_width <- 0.52
time_point_size <- 1.20

# ---------- 3. 读取两行表头的 CSV ----------
dat <- read.csv(
  data_file,
  skip = 2,
  header = FALSE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  na.strings = c("", "NA")
)

if (ncol(dat) != 11) {
  stop("CSV 应包含11列：日期、3列温度、3列湿度、3列DLI和1列降雨。")
}

names(dat) <- c(
  "Date",
  "Temp_BP", "Temp_UP", "Temp_FS",
  "RH_BP", "RH_UP", "RH_FS",
  "DLI_BP", "DLI_UP", "DLI_FS",
  "Rainfall"
)

dat <- dat %>%
  mutate(
    Date = as.Date(Date, format = "%Y/%m/%d"),
    across(-Date, ~ suppressWarnings(as.numeric(.x)))
  ) %>%
  arrange(Date)

if (anyNA(dat$Date)) {
  stop("部分日期无法按 YYYY/MM/DD 格式识别，请检查 CSV。")
}

if (anyDuplicated(dat$Date)) {
  stop("日期存在重复记录，请先确认是否需要按日求均值。")
}

# ---------- 4. 转成长数据 ----------
temperature_long <- dat %>%
  select(Date, Temp_UP, Temp_BP, Temp_FS) %>%
  pivot_longer(
    cols = -Date,
    names_to = "Position_code",
    values_to = "Temperature"
  ) %>%
  mutate(
    Microenvironment = recode(
      Position_code,
      "Temp_UP" = "Under-panel",
      "Temp_BP" = "Inter-panel",
      "Temp_FS" = "Open-field control"
    ),
    Microenvironment = factor(
      Microenvironment,
      levels = micro_levels
    )
  )

humidity_long <- dat %>%
  select(Date, RH_UP, RH_BP, RH_FS) %>%
  pivot_longer(
    cols = -Date,
    names_to = "Position_code",
    values_to = "Relative_humidity"
  ) %>%
  mutate(
    Microenvironment = recode(
      Position_code,
      "RH_UP" = "Under-panel",
      "RH_BP" = "Inter-panel",
      "RH_FS" = "Open-field control"
    ),
    Microenvironment = factor(
      Microenvironment,
      levels = micro_levels
    )
  )

dli_long <- dat %>%
  select(Date, DLI_UP, DLI_BP, DLI_FS) %>%
  pivot_longer(
    cols = -Date,
    names_to = "Position_code",
    values_to = "DLI"
  ) %>%
  mutate(
    Microenvironment = recode(
      Position_code,
      "DLI_UP" = "Under-panel",
      "DLI_BP" = "Inter-panel",
      "DLI_FS" = "Open-field control"
    ),
    Microenvironment = factor(
      Microenvironment,
      levels = micro_levels
    )
  ) %>%
  # 仅删除源数据中本来就缺失的 DLI，不删除任何有效观测。
  filter(is.finite(DLI))

# ---------- 5. 手动坐标范围 ----------
# 温度与降雨双纵轴使用线性换算；可在这里手动调整范围。
temp_limits <- c(-6, 32)
temp_breaks <- c(-5, 0, 10, 20, 30)

rain_limits <- c(0, 50)
rain_breaks <- seq(0, 50, by = 10)

rh_limits <- c(10, 100)
rh_breaks <- seq(20, 100, by = 20)

dli_limits <- c(0, 50)
dli_breaks <- seq(0, 50, by = 10)

if (
  any(dat$Rainfall < rain_limits[1], na.rm = TRUE) ||
  any(dat$Rainfall > rain_limits[2], na.rm = TRUE)
) {
  stop("降雨量超出 rain_limits，请增大 rain_limits 后重新运行。")
}

# 将降雨量线性映射到温度主坐标。
rain_scale <- diff(temp_limits) / diff(rain_limits)
rain_to_primary <- function(x) {
  temp_limits[1] + (x - rain_limits[1]) * rain_scale
}
primary_to_rain <- function(x) {
  rain_limits[1] + (x - temp_limits[1]) / rain_scale
}

rain_dat <- dat %>%
  transmute(
    Date,
    Rainfall,
    xmin = Date - 0.45,
    xmax = Date + 0.45,
    ymin = temp_limits[1],
    ymax = rain_to_primary(Rainfall)
  )

# ---------- 6. 参考图风格 ----------
theme_reference <- theme_classic(
  base_size = 12,
  base_family = "Arial"
) +
  theme(
    panel.border = element_rect(
      colour = "black",
      fill = NA,
      linewidth = 0.75
    ),
    axis.line = element_blank(),
    axis.ticks = element_line(
      colour = "black",
      linewidth = 0.65
    ),
    axis.ticks.length = grid::unit(-0.07, "cm"),
    axis.title = element_text(
      colour = "black",
      face = "bold",
      size = 13
    ),
    axis.text = element_text(
      colour = "black",
      face = "bold",
      size = 10
    ),
    axis.text.x = element_text(
      size = 8,
      angle = 45,
      hjust = 1,
      margin = margin(t = 7)
    ),
    axis.text.y = element_text(
      margin = margin(r = 7)
    ),
    legend.title = element_blank(),
    legend.text = element_text(
      colour = "black",
      face = "bold",
      size = 9
    ),
    legend.key = element_blank(),
    legend.background = element_rect(
      fill = "white",
      colour = "black",
      linewidth = 0.35
    ),
    legend.box = "vertical",
    legend.direction = "vertical",
    legend.key.height = grid::unit(0.35, "cm"),
    legend.spacing.y = grid::unit(0.03, "cm"),
    legend.margin = margin(3, 4, 3, 4),
    plot.margin = margin(8, 10, 8, 8)
  )

# 图例统一放在绘图区内部右上角。
# 使用版本判断，同时兼容 ggplot2 3.5.0 之前和之后的写法。
air_legend_position <- c(0.98, 0.98)
air_legend_justification <- c(1, 1)

theme_legend_inside <- function(position, justification) {
  if (utils::packageVersion("ggplot2") >= "3.5.0") {
    theme(
      legend.position = "inside",
      legend.position.inside = position,
      legend.justification = justification
    )
  } else {
    theme(
      legend.position = position,
      legend.justification = justification
    )
  }
}

common_date_scale <- scale_x_date(
  date_breaks = "15 days",
  date_labels = "%y/%m/%d",
  expand = expansion(mult = c(0.01, 0.01))
)

# ---------- 7. 温度 + 降雨双纵轴图 ----------
# 用户所说“双X轴”在此按温度/降雨不同单位理解为“双Y轴”：
# 左轴为温度，右轴为降雨；横轴均为日期。
p_temperature_rain <- ggplot() +
  geom_rect(
    data = rain_dat,
    aes(
      xmin = xmin,
      xmax = xmax,
      ymin = ymin,
      ymax = ymax,
      fill = "Rainfall"
    ),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 0.55
  ) +
  geom_line(
    data = temperature_long,
    aes(
      x = Date,
      y = Temperature,
      colour = Microenvironment,
      group = Microenvironment
    ),
    linewidth = time_line_width,
    na.rm = TRUE
  ) +
  geom_point(
    data = temperature_long,
    aes(
      x = Date,
      y = Temperature,
      colour = Microenvironment
    ),
    size = time_point_size,
    stroke = 0,
    na.rm = TRUE
  ) +
  scale_colour_manual(
    values = micro_colors,
    breaks = micro_levels,
    drop = FALSE
  ) +
  scale_fill_manual(
    values = c("Rainfall" = rain_color),
    breaks = "Rainfall"
  ) +
  common_date_scale +
  scale_y_continuous(
    name = expression("Air temperature (" * degree * "C)"),
    limits = temp_limits,
    breaks = temp_breaks,
    expand = expansion(mult = c(0, 0)),
    sec.axis = sec_axis(
      trans = ~ primary_to_rain(.),
      name = "Rainfall (mm)",
      breaks = rain_breaks
    )
  ) +
  guides(
    colour = guide_legend(
      order = 1,
      ncol = 1,
      byrow = TRUE,
      override.aes = list(linewidth = 1.2, size = 2.2)
    ),
    fill = guide_legend(
      order = 2,
      ncol = 1,
      byrow = TRUE,
      override.aes = list(alpha = 0.55)
    )
  ) +
  labs(x = "Date") +
  theme_reference +
  theme(
    axis.title.y.right = element_text(
      colour = "#617985",
      face = "bold"
    ),
    axis.text.y.right = element_text(
      colour = "#617985",
      face = "bold"
    )
  ) +
  theme_legend_inside(
    position = air_legend_position,
    justification = air_legend_justification
  )

# ---------- 8. 空气湿度单图 ----------
p_humidity <- ggplot(
  humidity_long,
  aes(
    x = Date,
    y = Relative_humidity,
    colour = Microenvironment,
    group = Microenvironment
  )
) +
  geom_line(
    linewidth = time_line_width,
    na.rm = TRUE
  ) +
  geom_point(
    size = time_point_size,
    stroke = 0,
    na.rm = TRUE
  ) +
  scale_colour_manual(
    values = micro_colors,
    breaks = micro_levels,
    drop = FALSE
  ) +
  common_date_scale +
  scale_y_continuous(
    limits = rh_limits,
    breaks = rh_breaks,
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    x = "Date",
    y = "Relative humidity (%)"
  ) +
  guides(
    colour = guide_legend(
      ncol = 1,
      byrow = TRUE,
      override.aes = list(linewidth = 1.2, size = 2.2)
    )
  ) +
  theme_reference +
  theme_legend_inside(
    position = air_legend_position,
    justification = air_legend_justification
  )

# ---------- 9. DLI 单图 ----------
p_dli <- ggplot(
  dli_long,
  aes(
    x = Date,
    y = DLI,
    colour = Microenvironment,
    group = Microenvironment
  )
) +
  geom_line(
    linewidth = time_line_width,
    na.rm = TRUE
  ) +
  geom_point(
    size = time_point_size,
    stroke = 0,
    na.rm = TRUE
  ) +
  scale_colour_manual(
    values = micro_colors,
    breaks = micro_levels,
    drop = FALSE
  ) +
  scale_x_date(
    date_breaks = "15 days",
    date_labels = "%y/%m/%d",
    expand = expansion(mult = c(0.01, 0.01))
  ) +
  scale_y_continuous(
    limits = dli_limits,
    breaks = dli_breaks,
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    x = "Date",
    y = expression("DLI (mol m"^-2 * " d"^-1 * ")")
  ) +
  guides(
    colour = guide_legend(
      ncol = 1,
      byrow = TRUE,
      override.aes = list(linewidth = 1.2, size = 2.2)
    )
  ) +
  theme_reference +
  theme_legend_inside(
    position = air_legend_position,
    justification = air_legend_justification
  )

# ---------- 10. 分别导出，不拼接 ----------
save_single_plot <- function(
  plot_object,
  filename,
  width_mm = 125,
  height_mm = 95,
  dpi = 600
) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4

  svglite::svglite(
    file = file.path(output_dir, paste0(filename, ".svg")),
    width = width_in,
    height = height_in,
    bg = "white"
  )
  print(plot_object)
  grDevices::dev.off()

  grDevices::cairo_pdf(
    filename = file.path(output_dir, paste0(filename, ".pdf")),
    width = width_in,
    height = height_in,
    family = "Arial",
    bg = "white",
    onefile = TRUE
  )
  print(plot_object)
  grDevices::dev.off()

  ragg::agg_tiff(
    filename = file.path(output_dir, paste0(filename, ".tiff")),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    compression = "lzw",
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()

  ragg::agg_png(
    filename = file.path(output_dir, paste0(filename, ".png")),
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()
}

save_single_plot(
  p_temperature_rain,
  "01_空气温度与降雨量"
)

save_single_plot(
  p_humidity,
  "02_空气相对湿度"
)

save_single_plot(
  p_dli,
  "03_DLI"
)

# 在 RStudio 中分别查看：
p_temperature_rain
p_humidity
p_dli
