# ============================================================
# 土壤温度与土壤含水量：
# 分阶段三因素混合线性模型、Tukey HSD 与 circlize 环形柱状图
#
# 数据层级：
# - 每行代表一个日期的日均值；
# - 每个日期包含 CK/F/MF/OF × UP/BP，以及单独的 FS 处理；
# - 日期作为随机截距，处理同一天不同处理组合之间的相关性。
#
# 生育期：
# - S1：2026-03-15 至 2026-04-08
# - S2：2026-04-09 至 2026-04-30
# - S3：2026-05-01 以后
#
# 推断统计：
# 1. 完整三因素模型：
#    Fertilization × Stage × Position + (1 | Date)
#    仅使用 CK/F/MF/OF × UP/BP。
#    FS 没有 UP/BP 两个位置水平，强行纳入会产生结构性缺失和秩亏，
#    因此 FS 不进入三因素模型。
# 2. 处理组合模型：
#    PlotGroup × Stage + (1 | Date)
#    包含 CKUP、CKBP、FUP、FBP、MFUP、MFBP、OFUP、OFBP、FS，
#    用于每个生育期内的 Tukey 多重比较及绘图字母。
# 3. 第 III 类平方和，Satterthwaite 自由度。
# 4. 所有事后比较均使用 Tukey 校正。
#
# 图形：
# - 柱：日尺度数据的均值；
# - 误差线：SE = SD / sqrt(n_dates)；
# - 空心柱：UP；实心柱：BP；FS 为黄色实心柱；
# - 空心点：原始日尺度数据；
# - 字母：混合模型估计边际均值的 Tukey 分组，
#         按均值从高到低排序，最高值优先标记为 a；
# - 施肥组间间隔 = 柱宽的 25%；
# - 同一施肥组内 UP/BP 间隔 = 柱宽的 5%。
# ============================================================

required_packages <- c(
  "dplyr", "tidyr", "stringr", "tibble",
  "lme4", "lmerTest", "emmeans", "multcomp", "multcompView",
  "circlize", "writexl", "svglite", "ragg"
)

missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  stop(
    "缺少以下 R 包：", paste(missing_packages, collapse = ", "),
    "\n请先运行：install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "),
    "))"
  )
}

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(tibble)
  library(lme4)
  library(lmerTest)
  library(emmeans)
  library(circlize)
})

# 第 III 类平方和需要和对比。
options(contrasts = c("contr.sum", "contr.poly"))
emmeans::emm_options(lmer.df = "satterthwaite")

# =========================
# 1. 路径与参数
# =========================
user_profile <- Sys.getenv("USERPROFILE", unset = "")
if (!nzchar(user_profile)) {
  user_profile <- path.expand("~")
}

data_candidates <- c(
  file.path(
    user_profile,
    "Desktop", "项目区气象数据", "土壤温湿度.csv"
  ),
  file.path(
    path.expand("~"),
    "Desktop", "项目区气象数据", "土壤温湿度.csv"
  ),
  file.path(getwd(), "土壤温湿度.csv")
)

existing_data_files <- data_candidates[file.exists(data_candidates)]
if (length(existing_data_files) == 0) {
  stop(
    "找不到数据文件“土壤温湿度.csv”。已搜索：\n",
    paste(
      normalizePath(
        data_candidates,
        winslash = "/",
        mustWork = FALSE
      ),
      collapse = "\n"
    )
  )
}
data_file <- existing_data_files[[1]]

project_dir <- file.path(
  user_profile,
  "Desktop", "光伏农业小麦相关", "2025-2026生长季"
)

output_dir <- file.path(
  project_dir,
  "图", "土壤温湿度_分阶段三因素混合模型_circlize"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

result_file <- file.path(
  output_dir,
  "土壤温湿度_分阶段三因素混合模型_Tukey结果.xlsx"
)

model_file <- file.path(
  output_dir,
  "土壤温湿度_混合模型对象.rds"
)

stage_levels <- c(
  "15 Mar–8 Apr",
  "9–30 Apr",
  ">30 Apr"
)

stage_labels <- c(
  "15 Mar–8 Apr" = "15 Mar–8 Apr",
  "9–30 Apr" = "9–30 Apr",
  ">30 Apr" = ">30 Apr"
)

fert_levels <- c("CK", "F", "MF", "OF", "FS")
factorial_fert_levels <- c("CK", "F", "MF", "OF")
position_levels <- c("UP", "BP")

plot_group_levels <- c(
  "CKUP", "CKBP",
  "FUP", "FBP",
  "MFUP", "MFBP",
  "OFUP", "OFBP",
  "FS"
)

fert_colors <- c(
  CK = "#8C8C8C",
  F  = "#0072B2",
  MF = "#009E73",
  OF = "#E66101",
  FS = "#F0E442"
)

stage_colors <- c(
  "15 Mar–8 Apr" = "#E8D8F6",
  "9–30 Apr" = "#DDECFB",
  ">30 Apr" = "#FFF0C2"
)

metric_codes <- c("SoilTemp", "SoilWater")
metric_labels <- c(
  SoilTemp = "Soil temperature (°C)",
  SoilWater = "Soil water content (%)"
)

# 固定径向刻度与断轴区间。
# lower_display_fraction 控制 0 到断轴下端在径向轴上所占的比例；
# gap_fraction 控制两条断轴线之间的空白宽度。
axis_break_specs <- list(
  SoilTemp = list(
    ticks = c(0, 10, 15, 20, 25, 30),
    axis_max = 30,
    break_lower = 1,
    break_upper = 8,
    lower_display_fraction = 0.055,
    gap_fraction = 0.025
  ),
  SoilWater = list(
    ticks = c(0, 8, 11, 14, 17),
    axis_max = 17,
    break_lower = 1,
    break_upper = 6,
    lower_display_fraction = 0.055,
    gap_fraction = 0.025
  )
)

# 是否显示每个日期的原始值空心点。
show_raw_points <- TRUE

# 柱体与间距：组内 5%，组间 25%。
bar_width <- 0.10
within_group_gap_pct <- 0.05
between_group_gap_pct <- 0.25
within_group_gap <- bar_width * within_group_gap_pct
between_group_gap <- bar_width * between_group_gap_pct
sector_padding <- 0.17

# 环形布局。
stage_ring_height <- 0.065
stage_ring_gap <- stage_ring_height * 0.20
main_track_height <- 0.56
sector_gap_degree <- 7

# 原始点与标注。
point_cex <- 0.42
point_jitter_width <- bar_width * 0.27
letter_cex <- 0.95
letter_offset_normalized <- 0.040

# 输出尺寸。
figure_width_in <- 10
figure_height_in <- 10
figure_dpi <- 600

# =========================
# 2. 读取两行表头 CSV
# =========================
raw_data <- read.csv(
  data_file,
  skip = 2,
  header = FALSE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  na.strings = c("", "NA", "NaN"),
  fileEncoding = "UTF-8-BOM"
)

if (ncol(raw_data) != 19) {
  stop(
    "土壤温湿度.csv 应包含 19 列：日期、9列土壤温度和9列土壤含水量。",
    "当前列数为：", ncol(raw_data)
  )
}

names(raw_data) <- c(
  "Date",
  paste0("SoilTemp_", c(
    "CKUP", "CKBP", "FUP", "FBP", "OFUP",
    "OFBP", "MFUP", "MFBP", "FS"
  )),
  paste0("SoilWater_", c(
    "CKUP", "CKBP", "FUP", "FBP", "OFUP",
    "OFBP", "MFUP", "MFBP", "FS"
  ))
)

to_numeric_value <- function(x) {
  suppressWarnings(
    as.numeric(
      str_replace_all(
        str_trim(as.character(x)),
        "%", ""
      )
    )
  )
}

raw_data <- raw_data %>%
  mutate(
    Date = as.Date(Date, format = "%Y/%m/%d"),
    across(-Date, to_numeric_value)
  ) %>%
  arrange(Date)

if (anyNA(raw_data$Date)) {
  stop("存在无法按 YYYY/MM/DD 解析的日期。")
}

if (anyDuplicated(raw_data$Date)) {
  duplicated_dates <- unique(
    raw_data$Date[duplicated(raw_data$Date)]
  )
  stop(
    "日期存在重复记录：",
    paste(duplicated_dates, collapse = ", ")
  )
}

analysis_start <- as.Date("2026-03-15")
stage1_end <- as.Date("2026-04-08")
stage2_end <- as.Date("2026-04-30")

date_exclusion_audit <- tibble(
  Source_rows = nrow(raw_data),
  Rows_before_2026_03_15 = sum(raw_data$Date < analysis_start),
  Rows_used = sum(raw_data$Date >= analysis_start),
  First_date_used = min(
    raw_data$Date[raw_data$Date >= analysis_start],
    na.rm = TRUE
  ),
  Last_date_used = max(
    raw_data$Date[raw_data$Date >= analysis_start],
    na.rm = TRUE
  )
)

if (date_exclusion_audit$Rows_before_2026_03_15 > 0) {
  warning(
    "按照生育期定义，已排除 2026-03-15 之前的 ",
    date_exclusion_audit$Rows_before_2026_03_15,
    " 行数据。",
    call. = FALSE
  )
}

raw_data <- raw_data %>%
  filter(Date >= analysis_start)

# =========================
# 3. 转成长数据并划分生育期
# =========================
long_all <- raw_data %>%
  pivot_longer(
    cols = -Date,
    names_to = c("Metric_code", "PlotGroup"),
    names_pattern = paste0(
      "^(SoilTemp|SoilWater)_(",
      paste(plot_group_levels, collapse = "|"),
      ")$"
    ),
    values_to = "Value"
  ) %>%
  mutate(
    Stage = case_when(
      Date <= stage1_end ~ "15 Mar–8 Apr",
      Date <= stage2_end ~ "9–30 Apr",
      TRUE ~ ">30 Apr"
    ),
    Fertilization = case_when(
      PlotGroup == "FS" ~ "FS",
      str_detect(PlotGroup, "^CK") ~ "CK",
      str_detect(PlotGroup, "^MF") ~ "MF",
      str_detect(PlotGroup, "^OF") ~ "OF",
      str_detect(PlotGroup, "^F") ~ "F",
      TRUE ~ NA_character_
    ),
    Position = case_when(
      PlotGroup == "FS" ~ "FS",
      str_detect(PlotGroup, "UP$") ~ "UP",
      str_detect(PlotGroup, "BP$") ~ "BP",
      TRUE ~ NA_character_
    ),
    Metric = factor(
      unname(metric_labels[Metric_code]),
      levels = unname(metric_labels[metric_codes])
    ),
    Metric_code = factor(Metric_code, levels = metric_codes),
    Stage = factor(Stage, levels = stage_levels),
    Fertilization = factor(
      Fertilization,
      levels = fert_levels
    ),
    Position = factor(
      Position,
      levels = c("UP", "BP", "FS")
    ),
    PlotGroup = factor(
      PlotGroup,
      levels = plot_group_levels
    ),
    Date_ID = factor(Date)
  ) %>%
  arrange(Metric_code, Stage, Date, PlotGroup)

missing_audit <- long_all %>%
  group_by(Metric_code, Stage, PlotGroup) %>%
  summarise(
    Total_rows = n(),
    Missing_rows = sum(!is.finite(Value)),
    Valid_rows = sum(is.finite(Value)),
    .groups = "drop"
  )

analysis_data <- long_all %>%
  filter(is.finite(Value))

stage_date_counts <- analysis_data %>%
  distinct(Stage, Date) %>%
  count(Stage, name = "Number_of_dates") %>%
  tidyr::complete(
    Stage = factor(stage_levels, levels = stage_levels),
    fill = list(Number_of_dates = 0L)
  ) %>%
  arrange(Stage)

cell_counts <- analysis_data %>%
  count(Metric_code, Stage, PlotGroup, name = "n") %>%
  tidyr::complete(
    Metric_code = factor(metric_codes, levels = metric_codes),
    Stage = factor(stage_levels, levels = stage_levels),
    PlotGroup = factor(
      plot_group_levels,
      levels = plot_group_levels
    ),
    fill = list(n = 0L)
  )

if (any(cell_counts$n < 2)) {
  insufficient_cells <- cell_counts %>%
    filter(n < 2) %>%
    transmute(
      Cell = paste(
        Metric_code, Stage, PlotGroup,
        sep = " | "
      )
    ) %>%
    pull(Cell)

  stop(
    "以下指标 × 生育期 × 处理组合少于2个有效日期，",
    "无法计算 SE 或 Tukey 比较：\n",
    paste(insufficient_cells, collapse = "\n")
  )
}

# =========================
# 4. 描述统计：均值、SD、SE
# =========================
descriptive_summary <- analysis_data %>%
  group_by(
    Metric_code, Metric, Stage,
    Fertilization, Position, PlotGroup
  ) %>%
  summarise(
    n_dates = n_distinct(Date),
    n_values = n(),
    Mean = mean(Value),
    SD = sd(Value),
    SE = SD / sqrt(n_dates),
    .groups = "drop"
  ) %>%
  mutate(
    Mean_SE = sprintf("%.2f ± %.2f", Mean, SE)
  ) %>%
  arrange(Metric_code, Stage, PlotGroup)

# =========================
# 5. 混合模型、第 III 类平方和与 Tukey
# =========================
significance_code <- function(p) {
  case_when(
    is.na(p) ~ "",
    p < 0.001 ~ "***",
    p < 0.01 ~ "**",
    p < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

as_tibble_with_metric <- function(object, metric_code) {
  as.data.frame(object) %>%
    as_tibble() %>%
    mutate(Metric_code = metric_code, .before = 1)
}

analyse_one_metric <- function(metric_code, data_long) {
  dat_metric <- data_long %>%
    filter(Metric_code == metric_code) %>%
    mutate(
      Stage = factor(Stage, levels = stage_levels),
      Fertilization = factor(
        Fertilization,
        levels = fert_levels
      ),
      Position = factor(
        Position,
        levels = c("UP", "BP", "FS")
      ),
      PlotGroup = factor(
        PlotGroup,
        levels = plot_group_levels
      ),
      Date_ID = factor(Date_ID)
    ) %>%
    droplevels()

  # FS 只有一个位置水平，因此不进入完整三因素模型。
  factorial_dat <- dat_metric %>%
    filter(
      Fertilization %in% factorial_fert_levels,
      Position %in% position_levels
    ) %>%
    mutate(
      Fertilization = factor(
        Fertilization,
        levels = factorial_fert_levels
      ),
      Position = factor(
        Position,
        levels = position_levels
      ),
      Stage = factor(Stage, levels = stage_levels),
      Date_ID = factor(Date_ID)
    ) %>%
    droplevels()

  three_factor_model <- lmerTest::lmer(
    Value ~ Fertilization * Stage * Position +
      (1 | Date_ID),
    data = factorial_dat,
    REML = TRUE,
    na.action = na.exclude,
    control = lme4::lmerControl(
      optimizer = "bobyqa",
      optCtrl = list(maxfun = 200000)
    )
  )

  type3_raw <- as.data.frame(
    anova(
      three_factor_model,
      type = 3,
      ddf = "Satterthwaite"
    )
  )
  type3_raw$Term <- rownames(type3_raw)
  rownames(type3_raw) <- NULL

  type3_table <- tibble(
    Metric_code = metric_code,
    Term = type3_raw$Term,
    Type_III_Sum_Sq = type3_raw[["Sum Sq"]],
    Mean_Sq = type3_raw[["Mean Sq"]],
    NumDF = type3_raw[["NumDF"]],
    DenDF = type3_raw[["DenDF"]],
    F_value = type3_raw[["F value"]],
    p_value = type3_raw[["Pr(>F)"]]
  ) %>%
    mutate(
      Significance = significance_code(p_value)
    )

  fixed_coefficients <- as.data.frame(
    coef(summary(three_factor_model))
  )
  fixed_coefficients$Coefficient <- rownames(
    fixed_coefficients
  )
  rownames(fixed_coefficients) <- NULL
  fixed_coefficients <- as_tibble(
    fixed_coefficients
  ) %>%
    mutate(Metric_code = metric_code, .before = 1)

  # 施肥处理：在每个生育期 × 位置内比较。
  emm_fert_by_stage_position <- emmeans::emmeans(
    three_factor_model,
    specs = ~ Fertilization | Stage * Position
  )
  tukey_fert_by_stage_position <- emmeans::contrast(
    emm_fert_by_stage_position,
    method = "pairwise",
    adjust = "tukey"
  ) %>%
    as_tibble_with_metric(metric_code)

  cld_fert_by_stage_position <- multcomp::cld(
    emm_fert_by_stage_position,
    adjust = "tukey",
    Letters = letters,
    sort = TRUE,
    reversed = TRUE
  ) %>%
    as.data.frame() %>%
    as_tibble() %>%
    mutate(
      Metric_code = metric_code,
      Tukey_group = str_squish(.group),
      .before = 1
    ) %>%
    select(-.group)

  # 光伏板位置：在每个生育期 × 施肥处理内比较。
  emm_position_by_stage_fert <- emmeans::emmeans(
    three_factor_model,
    specs = ~ Position | Stage * Fertilization
  )
  tukey_position_by_stage_fert <- emmeans::contrast(
    emm_position_by_stage_fert,
    method = "pairwise",
    adjust = "tukey"
  ) %>%
    as_tibble_with_metric(metric_code)

  # 生育期：在每个施肥处理 × 位置内比较。
  emm_stage_by_fert_position <- emmeans::emmeans(
    three_factor_model,
    specs = ~ Stage | Fertilization * Position
  )
  tukey_stage_by_fert_position <- emmeans::contrast(
    emm_stage_by_fert_position,
    method = "pairwise",
    adjust = "tukey"
  ) %>%
    as_tibble_with_metric(metric_code)

  # 完整三因素处理均值与统一 Tukey 比较。
  emm_complete_treatments <- emmeans::emmeans(
    three_factor_model,
    specs = ~ Fertilization * Stage * Position
  )
  complete_emmeans <- emm_complete_treatments %>%
    as_tibble_with_metric(metric_code)

  tukey_complete_treatments <- emmeans::contrast(
    emm_complete_treatments,
    method = "pairwise",
    adjust = "tukey"
  ) %>%
    as_tibble_with_metric(metric_code)

  # 包含 FS 的处理组合模型，用于图中每个生育期内9个处理的比较。
  treatment_model <- lmerTest::lmer(
    Value ~ PlotGroup * Stage + (1 | Date_ID),
    data = dat_metric,
    REML = TRUE,
    na.action = na.exclude,
    control = lme4::lmerControl(
      optimizer = "bobyqa",
      optCtrl = list(maxfun = 200000)
    )
  )

  emm_group_by_stage <- emmeans::emmeans(
    treatment_model,
    specs = ~ PlotGroup | Stage
  )

  tukey_group_by_stage <- emmeans::contrast(
    emm_group_by_stage,
    method = "pairwise",
    adjust = "tukey"
  ) %>%
    as_tibble_with_metric(metric_code)

  cld_group_by_stage <- multcomp::cld(
    emm_group_by_stage,
    adjust = "tukey",
    Letters = letters,
    sort = TRUE,
    reversed = TRUE
  ) %>%
    as.data.frame() %>%
    as_tibble() %>%
    mutate(
      Metric_code = metric_code,
      Tukey_group = str_squish(.group),
      .before = 1
    ) %>%
    select(-.group)

  # 全部 27 个 Stage × PlotGroup 处理均值的统一比较。
  emm_all_group_stage <- emmeans::emmeans(
    treatment_model,
    specs = ~ PlotGroup * Stage
  )

  all_group_stage_emmeans <- emm_all_group_stage %>%
    as_tibble_with_metric(metric_code)

  tukey_all_group_stage <- emmeans::contrast(
    emm_all_group_stage,
    method = "pairwise",
    adjust = "tukey"
  ) %>%
    as_tibble_with_metric(metric_code)

  cld_all_group_stage <- multcomp::cld(
    emm_all_group_stage,
    adjust = "tukey",
    Letters = letters,
    sort = TRUE,
    reversed = TRUE
  ) %>%
    as.data.frame() %>%
    as_tibble() %>%
    mutate(
      Metric_code = metric_code,
      Tukey_group = str_squish(.group),
      .before = 1
    ) %>%
    select(-.group)

  variance_components <- as.data.frame(
    lme4::VarCorr(three_factor_model)
  )
  date_variance <- variance_components %>%
    filter(grp == "Date_ID") %>%
    pull(vcov)

  if (length(date_variance) == 0) {
    date_variance <- NA_real_
  }

  residual_test <- shapiro.test(
    residuals(three_factor_model)
  )

  model_diagnostics <- tibble(
    Metric_code = metric_code,
    Model = "Three-factor mixed model",
    n_observations = stats::nobs(three_factor_model),
    n_dates = n_distinct(factorial_dat$Date),
    n_fertilization = n_distinct(
      factorial_dat$Fertilization
    ),
    n_positions = n_distinct(factorial_dat$Position),
    n_stages = n_distinct(factorial_dat$Stage),
    Date_random_intercept_variance = date_variance[[1]],
    Residual_variance = sigma(three_factor_model)^2,
    Singular_fit = lme4::isSingular(
      three_factor_model,
      tol = 1e-4
    ),
    REML_logLik = as.numeric(logLik(three_factor_model)),
    Shapiro_W = unname(residual_test$statistic),
    Shapiro_p = residual_test$p.value
  )

  list(
    three_factor_model = three_factor_model,
    treatment_model = treatment_model,
    type3 = type3_table,
    coefficients = fixed_coefficients,
    diagnostics = model_diagnostics,
    complete_emmeans = complete_emmeans,
    tukey_complete = tukey_complete_treatments,
    tukey_fert_by_stage_position =
      tukey_fert_by_stage_position,
    cld_fert_by_stage_position =
      cld_fert_by_stage_position,
    tukey_position_by_stage_fert =
      tukey_position_by_stage_fert,
    tukey_stage_by_fert_position =
      tukey_stage_by_fert_position,
    group_stage_emmeans =
      as_tibble_with_metric(
        emm_group_by_stage,
        metric_code
      ),
    tukey_group_by_stage = tukey_group_by_stage,
    cld_group_by_stage = cld_group_by_stage,
    all_group_stage_emmeans = all_group_stage_emmeans,
    tukey_all_group_stage = tukey_all_group_stage,
    cld_all_group_stage = cld_all_group_stage
  )
}

analysis_results <- setNames(
  lapply(
    metric_codes,
    analyse_one_metric,
    data_long = analysis_data
  ),
  metric_codes
)

bind_component <- function(component_name) {
  bind_rows(
    lapply(
      analysis_results,
      function(result) result[[component_name]]
    )
  )
}

type3_fixed_effects <- bind_component("type3")
fixed_coefficients <- bind_component("coefficients")
model_diagnostics <- bind_component("diagnostics")
complete_emmeans <- bind_component("complete_emmeans")
tukey_complete <- bind_component("tukey_complete")
tukey_fert_by_stage_position <- bind_component(
  "tukey_fert_by_stage_position"
)
cld_fert_by_stage_position <- bind_component(
  "cld_fert_by_stage_position"
)
tukey_position_by_stage_fert <- bind_component(
  "tukey_position_by_stage_fert"
)
tukey_stage_by_fert_position <- bind_component(
  "tukey_stage_by_fert_position"
)
group_stage_emmeans <- bind_component(
  "group_stage_emmeans"
)
tukey_group_by_stage <- bind_component(
  "tukey_group_by_stage"
)
cld_group_by_stage <- bind_component(
  "cld_group_by_stage"
)
all_group_stage_emmeans <- bind_component(
  "all_group_stage_emmeans"
)
tukey_all_group_stage <- bind_component(
  "tukey_all_group_stage"
)
cld_all_group_stage <- bind_component(
  "cld_all_group_stage"
)

model_objects <- lapply(
  analysis_results,
  function(result) {
    list(
      three_factor_model = result$three_factor_model,
      treatment_model = result$treatment_model
    )
  }
)
saveRDS(model_objects, model_file)

# =========================
# 6. 环形柱状图横坐标布局
# =========================
layout_list <- list()
sector_xlim <- matrix(
  NA_real_,
  nrow = length(stage_levels),
  ncol = 2,
  dimnames = list(stage_levels, c("xmin", "xmax"))
)

for (stage_name in stage_levels) {
  x_cursor <- sector_padding
  stage_layout_parts <- list()

  for (fert_name in fert_levels) {
    if (fert_name == "FS") {
      stage_layout_parts[[fert_name]] <- tibble(
        Stage = factor(stage_name, levels = stage_levels),
        Fertilization = factor(
          "FS",
          levels = fert_levels
        ),
        Position = factor(
          "FS",
          levels = c("UP", "BP", "FS")
        ),
        PlotGroup = factor(
          "FS",
          levels = plot_group_levels
        ),
        xleft = x_cursor,
        xright = x_cursor + bar_width,
        xcenter = x_cursor + bar_width / 2
      )
      x_cursor <- x_cursor + bar_width +
        between_group_gap
    } else {
      up_group <- paste0(fert_name, "UP")
      bp_group <- paste0(fert_name, "BP")
      xleft_up <- x_cursor
      xleft_bp <- xleft_up + bar_width +
        within_group_gap

      stage_layout_parts[[fert_name]] <- tibble(
        Stage = factor(stage_name, levels = stage_levels),
        Fertilization = factor(
          fert_name,
          levels = fert_levels
        ),
        Position = factor(
          c("UP", "BP"),
          levels = c("UP", "BP", "FS")
        ),
        PlotGroup = factor(
          c(up_group, bp_group),
          levels = plot_group_levels
        ),
        xleft = c(xleft_up, xleft_bp),
        xright = c(
          xleft_up + bar_width,
          xleft_bp + bar_width
        ),
        xcenter = c(
          xleft_up + bar_width / 2,
          xleft_bp + bar_width / 2
        )
      )

      x_cursor <- xleft_bp + bar_width +
        between_group_gap
    }
  }

  stage_layout <- bind_rows(stage_layout_parts)
  layout_list[[stage_name]] <- stage_layout
  sector_xlim[stage_name, ] <- c(
    0,
    max(stage_layout$xright) + sector_padding
  )
}

bar_layout <- bind_rows(layout_list)

# =========================
# 7. 绘图辅助函数
# =========================
format_tick <- function(x, axis_max) {
  if (axis_max < 1) {
    sprintf("%.2f", x)
  } else if (axis_max < 10) {
    sprintf("%.1f", x)
  } else {
    sprintf("%.0f", x)
  }
}

# 将原始数值映射到带断轴的 0–1 径向坐标。
# 位于断轴区间内的值默认返回 NA；这类原始点不在图中显示，
# 但仍完整参与均值、SE和混合模型计算。
map_broken_y <- function(
  value,
  break_spec,
  inside_break = c("NA", "lower", "upper")
) {
  inside_break <- match.arg(inside_break)

  lower_value <- break_spec$break_lower
  upper_value <- break_spec$break_upper
  axis_max <- break_spec$axis_max
  lower_end <- break_spec$lower_display_fraction
  upper_start <- lower_end + break_spec$gap_fraction

  output <- rep(NA_real_, length(value))
  finite_value <- is.finite(value)
  lower_segment <- finite_value & value <= lower_value
  upper_segment <- finite_value & value >= upper_value
  omitted_segment <- finite_value &
    value > lower_value &
    value < upper_value

  output[lower_segment] <- pmax(
    value[lower_segment],
    0
  ) / lower_value * lower_end

  output[upper_segment] <- upper_start +
    (
      value[upper_segment] - upper_value
    ) / (
      axis_max - upper_value
    ) * (
      1 - upper_start
    )

  if (inside_break == "lower") {
    output[omitted_segment] <- lower_end
  } else if (inside_break == "upper") {
    output[omitted_segment] <- upper_start
  }

  output
}

break_warning_registry <- new.env(parent = emptyenv())

make_center_statistics <- function(metric_code) {
  metric_type3 <- type3_fixed_effects %>%
    filter(
      Metric_code == metric_code,
      Term != "(Intercept)"
    ) %>%
    mutate(
      Short_term = recode(
        Term,
        "Fertilization" = "F",
        "Stage" = "S",
        "Position" = "P",
        "Fertilization:Stage" = "F×S",
        "Fertilization:Position" = "F×P",
        "Stage:Position" = "S×P",
        "Fertilization:Stage:Position" = "F×S×P",
        .default = Term
      ),
      Stat_label = paste0(
        Short_term, ": ",
        sprintf("%.2f", F_value),
        Significance
      )
    )

  main_effect_line <- metric_type3 %>%
    filter(!str_detect(Term, ":")) %>%
    pull(Stat_label) %>%
    paste(collapse = "   ")

  two_way_line <- metric_type3 %>%
    filter(str_count(Term, ":") == 1) %>%
    pull(Stat_label) %>%
    paste(collapse = "   ")

  three_way_line <- metric_type3 %>%
    filter(str_count(Term, ":") == 2) %>%
    pull(Stat_label) %>%
    paste(collapse = "   ")

  paste(
    main_effect_line,
    two_way_line,
    three_way_line,
    sep = "\n"
  )
}

prepare_metric_plot_data <- function(metric_code) {
  summary_metric <- descriptive_summary %>%
    filter(Metric_code == metric_code) %>%
    left_join(
      cld_group_by_stage %>%
        filter(Metric_code == metric_code) %>%
        select(Stage, PlotGroup, Tukey_group),
      by = c("Stage", "PlotGroup")
    ) %>%
    left_join(
      bar_layout %>%
        select(
          Stage, PlotGroup,
          xleft, xright, xcenter
        ),
      by = c("Stage", "PlotGroup")
    ) %>%
    mutate(
      Fill_color = case_when(
        Position == "UP" ~ "white",
        TRUE ~ unname(
          fert_colors[as.character(Fertilization)]
        )
      ),
      Border_color = unname(
        fert_colors[as.character(Fertilization)]
      ),
      Within_group_gap_pct =
        within_group_gap_pct * 100,
      Between_group_gap_pct =
        between_group_gap_pct * 100
    )

  raw_metric <- analysis_data %>%
    filter(Metric_code == metric_code) %>%
    left_join(
      bar_layout %>%
        select(Stage, PlotGroup, xcenter),
      by = c("Stage", "PlotGroup")
    ) %>%
    mutate(
      Point_color = unname(
        fert_colors[as.character(Fertilization)]
      )
    ) %>%
    group_by(Stage, PlotGroup) %>%
    arrange(Date, .by_group = TRUE) %>%
    mutate(
      Point_x = if (n() == 1) {
        xcenter
      } else {
        xcenter + seq(
          -point_jitter_width,
          point_jitter_width,
          length.out = n()
        )
      }
    ) %>%
    ungroup()

  break_spec <- axis_break_specs[[metric_code]]
  axis_ticks <- break_spec$ticks
  axis_max <- break_spec$axis_max

  data_max <- max(
    summary_metric$Mean + summary_metric$SE,
    raw_metric$Value,
    na.rm = TRUE
  )

  if (data_max > axis_max) {
    stop(
      metric_code,
      " 的数据或误差线超过固定 Y 轴上限：",
      axis_max
    )
  }

  raw_values_in_break <- sum(
    raw_metric$Value > break_spec$break_lower &
      raw_metric$Value < break_spec$break_upper,
    na.rm = TRUE
  )

  if (
    raw_values_in_break > 0 &&
    !exists(
      metric_code,
      envir = break_warning_registry,
      inherits = FALSE
    )
  ) {
    warning(
      metric_code, " 有 ", raw_values_in_break,
      " 个原始日尺度值位于断轴区间 ",
      break_spec$break_lower, "–",
      break_spec$break_upper,
      " 内；这些点保留在统计分析中，但不在断轴图中显示。",
      call. = FALSE
    )
    assign(
      metric_code,
      TRUE,
      envir = break_warning_registry
    )
  }

  grid_breaks <- axis_ticks[
    axis_ticks > 0 & axis_ticks < axis_max
  ]

  list(
    summary = summary_metric,
    raw = raw_metric,
    axis_ticks = axis_ticks,
    axis_max = axis_max,
    grid_breaks = grid_breaks,
    break_spec = break_spec,
    raw_values_in_break = raw_values_in_break
  )
}

draw_radial_metric <- function(metric_code) {
  prepared <- prepare_metric_plot_data(metric_code)
  plot_summary <- prepared$summary
  plot_raw <- prepared$raw
  axis_ticks <- prepared$axis_ticks
  axis_max <- prepared$axis_max
  grid_breaks <- prepared$grid_breaks
  break_spec <- prepared$break_spec
  center_stats <- make_center_statistics(metric_code)

  font_family <- if (capabilities("cairo")) "Arial" else "sans"

  par(
    family = font_family,
    font = 2,
    mar = c(1, 1, 1, 1)
  )

  circlize::circos.clear()
  circlize::circos.par(
    start.degree = 90,
    gap.degree = sector_gap_degree,
    track.margin = c(stage_ring_gap, 0.01),
    cell.padding = c(0, 0, 0, 0),
    points.overflow.warning = FALSE
  )

  circlize::circos.initialize(
    factors = stage_levels,
    xlim = sector_xlim
  )

  # 外侧生育期色带。
  circlize::circos.trackPlotRegion(
    factors = stage_levels,
    ylim = c(0, 1),
    track.height = stage_ring_height,
    bg.col = grDevices::adjustcolor(
      stage_colors[stage_levels],
      alpha.f = 0.80
    ),
    bg.border = "black",
    panel.fun = function(x, y) {
      current_stage <- circlize::CELL_META$sector.index

      circlize::circos.text(
        circlize::CELL_META$xcenter,
        0.50,
        labels = stage_labels[current_stage],
        facing = "bending.inside",
        niceFacing = TRUE,
        cex = 1.05,
        font = 2,
        adj = c(0.5, 0.5)
      )
    }
  )

  # 主柱体轨道。
  circlize::circos.trackPlotRegion(
    factors = stage_levels,
    ylim = c(0, 1),
    track.height = main_track_height,
    bg.col = grDevices::adjustcolor(
      stage_colors[stage_levels],
      alpha.f = 0.24
    ),
    bg.border = "black",
    panel.fun = function(x, y) {
      current_stage <- circlize::CELL_META$sector.index

      sector_summary <- plot_summary %>%
        filter(Stage == current_stage) %>%
        arrange(xcenter)

      sector_raw <- plot_raw %>%
        filter(Stage == current_stage) %>%
        filter(
          !(
            Value > break_spec$break_lower &
              Value < break_spec$break_upper
          )
        ) %>%
        arrange(Point_x)

      circlize::circos.lines(
        rep(circlize::CELL_META$cell.xlim[1], 2),
        c(0, 1),
        col = "black",
        lwd = 1.4
      )
      circlize::circos.lines(
        rep(circlize::CELL_META$cell.xlim[2], 2),
        c(0, 1),
        col = "black",
        lwd = 1.4
      )

      # 径向网格线。
      for (tick_value in grid_breaks) {
        tick_y <- map_broken_y(
          tick_value,
          break_spec
        )
        circlize::circos.lines(
          circlize::CELL_META$cell.xlim,
          rep(tick_y, 2),
          lty = 5,
          col = "grey50",
          lwd = 0.75
        )
      }

      # 在每个生育期扇区绘制断轴空白带和两条间断线。
      break_y_lower <- break_spec$lower_display_fraction
      break_y_upper <- break_y_lower +
        break_spec$gap_fraction

      circlize::circos.rect(
        circlize::CELL_META$cell.xlim[1],
        break_y_lower,
        circlize::CELL_META$cell.xlim[2],
        break_y_upper,
        col = "white",
        border = NA
      )
      circlize::circos.lines(
        circlize::CELL_META$cell.xlim,
        rep(break_y_lower, 2),
        col = "black",
        lwd = 0.75
      )
      circlize::circos.lines(
        circlize::CELL_META$cell.xlim,
        rep(break_y_upper, 2),
        col = "black",
        lwd = 0.75
      )

      # 仅在第一个生育期扇区左侧绘制数值刻度。
      if (current_stage == stage_levels[1]) {
        axis_x <- circlize::CELL_META$cell.xlim[1]
        tick_len <- diff(
          circlize::CELL_META$cell.xlim
        ) * 0.035
        label_x <- axis_x + diff(
          circlize::CELL_META$cell.xlim
        ) * 0.048

        for (tick_value in axis_ticks) {
          tick_y <- map_broken_y(
            tick_value,
            break_spec
          )
          circlize::circos.lines(
            c(axis_x, axis_x + tick_len),
            rep(tick_y, 2),
            col = "black",
            lwd = 0.9
          )
          circlize::circos.text(
            label_x,
            tick_y,
            labels = format_tick(
              tick_value,
              axis_max
            ),
            facing = "clockwise",
            niceFacing = TRUE,
            adj = c(0.5, 0.5),
            cex = 0.78,
            font = 2
          )
        }

        # 在径向轴上添加双斜线，明确表示省略区间。
        slash_mid_y <- (
          break_y_lower + break_y_upper
        ) / 2
        slash_dx <- diff(
          circlize::CELL_META$cell.xlim
        ) * 0.018
        slash_dy <- break_spec$gap_fraction * 0.16

        for (
          slash_offset in c(
            -break_spec$gap_fraction * 0.17,
            break_spec$gap_fraction * 0.17
          )
        ) {
          circlize::circos.segments(
            axis_x - slash_dx,
            slash_mid_y - slash_dy + slash_offset,
            axis_x + slash_dx,
            slash_mid_y + slash_dy + slash_offset,
            col = "black",
            lwd = 1.0
          )
        }
      }

      # 均值柱和 SE 误差线。
      for (row_index in seq_len(nrow(sector_summary))) {
        row_i <- sector_summary[row_index, ]
        error_inside_policy <- if (
          row_i$Mean >= break_spec$break_upper
        ) {
          "upper"
        } else {
          "lower"
        }

        mean_y <- map_broken_y(
          row_i$Mean,
          break_spec,
          inside_break = error_inside_policy
        )
        low_y <- map_broken_y(
          pmax(row_i$Mean - row_i$SE, 0),
          break_spec,
          inside_break = error_inside_policy
        )
        high_y <- map_broken_y(
          row_i$Mean + row_i$SE,
          break_spec,
          inside_break = error_inside_policy
        )

        # 柱体分为断轴下方和断轴上方两段，空白带不填充。
        if (row_i$Mean <= break_spec$break_lower) {
          circlize::circos.rect(
            row_i$xleft,
            0,
            row_i$xright,
            mean_y,
            col = row_i$Fill_color,
            border = row_i$Border_color,
            lwd = 1.4
          )
        } else {
          circlize::circos.rect(
            row_i$xleft,
            0,
            row_i$xright,
            break_y_lower,
            col = row_i$Fill_color,
            border = row_i$Border_color,
            lwd = 1.4
          )
          circlize::circos.rect(
            row_i$xleft,
            break_y_upper,
            row_i$xright,
            mean_y,
            col = row_i$Fill_color,
            border = row_i$Border_color,
            lwd = 1.4
          )
        }

        circlize::circos.segments(
          row_i$xcenter,
          low_y,
          row_i$xcenter,
          high_y,
          col = "black",
          lwd = 1.05
        )
        circlize::circos.segments(
          row_i$xcenter - bar_width * 0.22,
          high_y,
          row_i$xcenter + bar_width * 0.22,
          high_y,
          col = "black",
          lwd = 1.05
        )
        circlize::circos.segments(
          row_i$xcenter - bar_width * 0.22,
          low_y,
          row_i$xcenter + bar_width * 0.22,
          low_y,
          col = "black",
          lwd = 1.05
        )
      }

      # 原始日尺度数据点。
      if (show_raw_points) {
        for (row_index in seq_len(nrow(sector_raw))) {
          row_i <- sector_raw[row_index, ]
          circlize::circos.points(
            row_i$Point_x,
            map_broken_y(
              row_i$Value,
              break_spec
            ),
            pch = 21,
            cex = point_cex,
            col = row_i$Point_color,
            bg = grDevices::adjustcolor(
              "white",
              alpha.f = 0
            )
          )
        }
      }

      # Tukey 显著性字母。
      for (row_index in seq_len(nrow(sector_summary))) {
        row_i <- sector_summary[row_index, ]
        high_y <- map_broken_y(
          row_i$Mean + row_i$SE,
          break_spec,
          inside_break = "upper"
        )

        circlize::circos.text(
          row_i$xcenter,
          min(
            high_y + letter_offset_normalized,
            0.985
          ),
          labels = row_i$Tukey_group,
          facing = "inside",
          niceFacing = TRUE,
          adj = c(0.5, 0),
          cex = letter_cex,
          font = 2
        )
      }
    }
  )

  # 中心标题和三因素固定效应检验。
  graphics::text(
    0,
    0.12,
    labels = metric_labels[[metric_code]],
    family = font_family,
    font = 2,
    cex = 1.10,
    adj = c(0.5, 0.5)
  )

  graphics::text(
    0,
    -0.04,
    labels = center_stats,
    family = font_family,
    font = 2,
    cex = 0.60,
    adj = c(0.5, 0.5)
  )

  graphics::text(
    0,
    -0.23,
    labels = "Bars: mean ± SE; open = UP; filled = BP",
    family = font_family,
    font = 1,
    cex = 0.52,
    adj = c(0.5, 0.5)
  )

  circlize::circos.clear()
  invisible(NULL)
}

# =========================
# 8. 安全导出 PDF、SVG、TIFF 和 PNG
# =========================
publish_temp_file <- function(
  temp_path,
  target_path,
  export_stamp
) {
  if (
    !file.exists(temp_path) ||
    file.info(temp_path)$size <= 0
  ) {
    stop("图形设备未生成有效文件：", temp_path)
  }

  copied <- suppressWarnings(
    file.copy(temp_path, target_path, overwrite = TRUE)
  )

  if (!isTRUE(copied)) {
    extension <- tools::file_ext(target_path)
    stem <- tools::file_path_sans_ext(
      basename(target_path)
    )
    alternative_path <- file.path(
      dirname(target_path),
      paste0(
        stem, "_", export_stamp, ".", extension
      )
    )

    copied <- suppressWarnings(
      file.copy(
        temp_path,
        alternative_path,
        overwrite = FALSE
      )
    )

    if (!isTRUE(copied)) {
      stop(
        "无法把图形复制到结果目录。请关闭正在占用的文件：",
        target_path
      )
    }

    warning(
      "原目标文件可能正在被占用，已改为保存：",
      alternative_path,
      call. = FALSE
    )
    target_path <- alternative_path
  }

  unlink(temp_path)
  normalizePath(
    target_path,
    winslash = "/",
    mustWork = FALSE
  )
}

close_new_device <- function(start_device) {
  current_device <- grDevices::dev.cur()
  if (
    current_device != start_device &&
    current_device > 1
  ) {
    try(grDevices::dev.off(), silent = TRUE)
  }
}

export_metric_figure <- function(metric_code) {
  export_stamp <- format(
    Sys.time(),
    "%Y%m%d_%H%M%S"
  )
  prefix <- file.path(
    output_dir,
    paste0(
      metric_code,
      "_分阶段混合模型_Tukey_circlize环形柱状图"
    )
  )

  # SVG
  svg_temp <- tempfile(
    pattern = "soil_ring_",
    fileext = ".svg"
  )
  svg_start_device <- grDevices::dev.cur()
  tryCatch(
    {
      svglite::svglite(
        svg_temp,
        width = figure_width_in,
        height = figure_height_in,
        bg = "white"
      )
      draw_radial_metric(metric_code)
      grDevices::dev.off()
    },
    error = function(error_condition) {
      close_new_device(svg_start_device)
      stop(
        "SVG 导出失败：",
        conditionMessage(error_condition)
      )
    }
  )
  svg_file <- publish_temp_file(
    svg_temp,
    paste0(prefix, ".svg"),
    export_stamp
  )

  # PDF：优先 Cairo，失败时使用 R 内置 PDF 设备。
  pdf_temp <- tempfile(
    pattern = "soil_ring_",
    fileext = ".pdf"
  )
  pdf_start_device <- grDevices::dev.cur()
  cairo_succeeded <- tryCatch(
    {
      grDevices::cairo_pdf(
        pdf_temp,
        width = figure_width_in,
        height = figure_height_in,
        family = "Arial",
        bg = "white"
      )
      draw_radial_metric(metric_code)
      grDevices::dev.off()
      TRUE
    },
    error = function(error_condition) {
      close_new_device(pdf_start_device)
      warning(
        "Cairo PDF 导出失败，改用 R 内置 PDF 设备：",
        conditionMessage(error_condition),
        call. = FALSE
      )
      FALSE
    }
  )

  if (!cairo_succeeded) {
    if (file.exists(pdf_temp)) {
      unlink(pdf_temp)
    }
    grDevices::pdf(
      pdf_temp,
      width = figure_width_in,
      height = figure_height_in,
      family = "sans",
      bg = "white",
      useDingbats = FALSE
    )
    draw_radial_metric(metric_code)
    grDevices::dev.off()
  }

  pdf_file <- publish_temp_file(
    pdf_temp,
    paste0(prefix, ".pdf"),
    export_stamp
  )

  # 600 dpi TIFF
  tiff_temp <- tempfile(
    pattern = "soil_ring_",
    fileext = ".tiff"
  )
  ragg::agg_tiff(
    tiff_temp,
    width = figure_width_in,
    height = figure_height_in,
    units = "in",
    res = figure_dpi,
    compression = "lzw",
    background = "white"
  )
  draw_radial_metric(metric_code)
  grDevices::dev.off()
  tiff_file <- publish_temp_file(
    tiff_temp,
    paste0(prefix, ".tiff"),
    export_stamp
  )

  # 600 dpi PNG
  png_temp <- tempfile(
    pattern = "soil_ring_",
    fileext = ".png"
  )
  ragg::agg_png(
    png_temp,
    width = figure_width_in,
    height = figure_height_in,
    units = "in",
    res = figure_dpi,
    background = "white"
  )
  draw_radial_metric(metric_code)
  grDevices::dev.off()
  png_file <- publish_temp_file(
    png_temp,
    paste0(prefix, ".png"),
    export_stamp
  )

  tibble(
    Metric_code = metric_code,
    Format = c("SVG", "PDF", "TIFF", "PNG"),
    File = c(
      svg_file,
      pdf_file,
      tiff_file,
      png_file
    )
  )
}

figure_files <- bind_rows(
  lapply(metric_codes, export_metric_figure)
)

# 输出与图形完全对应的源数据。
plot_source_data <- bind_rows(
  lapply(
    metric_codes,
    function(metric_code) {
      prepared <- prepare_metric_plot_data(metric_code)
      prepared$summary %>%
        mutate(
          Axis_max = prepared$axis_max,
          Axis_ticks = paste(
            prepared$axis_ticks,
            collapse = ", "
          ),
          Axis_break_lower =
            prepared$break_spec$break_lower,
          Axis_break_upper =
            prepared$break_spec$break_upper,
          Raw_points_in_break =
            prepared$raw_values_in_break
        )
    }
  )
)

# =========================
# 9. 导出统计结果
# =========================
writexl::write_xlsx(
  list(
    Summary_Mean_SE = descriptive_summary,
    Missing_Audit = missing_audit,
    Stage_Date_Counts = stage_date_counts,
    Cell_Counts = cell_counts,
    Date_Audit = date_exclusion_audit,
    TypeIII_3factor = type3_fixed_effects,
    Coeff_3factor = fixed_coefficients,
    Diag_3factor = model_diagnostics,
    EMM_Fert_SxP = cld_fert_by_stage_position,
    Tukey_Fert_SxP = tukey_fert_by_stage_position,
    Tukey_Pos_SxF = tukey_position_by_stage_fert,
    Tukey_Stage_FxP = tukey_stage_by_fert_position,
    EMM_Full = complete_emmeans,
    Tukey_Full = tukey_complete,
    EMM_Group_by_Stage = group_stage_emmeans,
    Tukey_Group_by_Stage = tukey_group_by_stage,
    CLD_Group_by_Stage = cld_group_by_stage,
    EMM_All_GroupStage = all_group_stage_emmeans,
    Tukey_All_GroupStage = tukey_all_group_stage,
    CLD_All_GroupStage = cld_all_group_stage,
    Plot_Source_Data = plot_source_data,
    Figure_Files = figure_files
  ),
  path = result_file
)

message("分析完成。")
message("数据文件：", data_file)
message("统计结果：", result_file)
message("模型对象：", model_file)
message(
  "图形文件：\n",
  paste(
    figure_files$Metric_code,
    figure_files$Format,
    figure_files$File,
    sep = " | ",
    collapse = "\n"
  )
)

# 在 RStudio 中查看固定效应检验结果：
type3_fixed_effects
