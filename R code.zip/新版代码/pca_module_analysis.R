## =====================================================================
## Modular PCA analysis and publication figures - v8
## Key change (vs v7): in the contribution panels (b/c), variables are now
##   sorted by their contribution from HIGH to LOW (top to bottom) within
##   each panel, so PC1 and PC2 each rank their own variables to help read
##   the physiological meaning of each PC. Loading panel (a) unchanged.
## Retained: inward ticks, pooled PCA, near-overlap deep-blue highlight,
##   separated 板下/板间 boxes with whisker caps, fixed Y axis [-5, 5].
## =====================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(ggrepel)
  library(patchwork)
  library(FactoMineR)
  library(modelr)
})

work    <- "C:/Users/Yixiang Wang/WorkBuddy/2026-10-06-21-20-05"
in_csv  <- file.path(work, "pca_input/data_09.csv")
out     <- file.path(work, "pca_output_v8")
fig_dir <- file.path(out, "figures")
tab_dir <- file.path(out, "tables")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

dat <- read_csv(in_csv, show_col_types = FALSE)
stopifnot(nrow(dat) == 150)

modules <- list(
  GP = list(full = "Growth and productivity",
            vars = c("PlantHeight", "LeafAreaIndex", "SpecificLeafArea",
                     "AbovegroundBiomass", "RootBiomass")),
  CA = list(full = "Carbon assimilation capacity",
            vars = c("AQY", "Rd", "LCP", "LSP", "Pnmax", "Rubisco")),
  PE = list(full = "Photochemical performance and energy regulation",
            vars = c("ChlTotal", "ChlaChlb", "FvFm", "PhiPSII", "qL", "NPQ", "YNO")),
  NR = list(full = "Nutrition and resource use",
            vars = c("RootActivity", "AbovegroundN", "RootN",
                     "AbovegroundCN", "RootCN", "PNUEmax")),
  SR = list(full = "Stress resistance and cellular homeostasis",
            vars = c("SOD", "POD", "CAT", "Proline", "SolubleSugar",
                     "SolubleProtein", "MDA", "REC"))
)
all_vars <- unlist(lapply(modules, `[[`, "vars"))
stopifnot(all(all_vars %in% names(dat)))

plotmath_lab <- c(
  PlantHeight = "Plant~height",  LeafAreaIndex = "LAI",
  SpecificLeafArea = "SLA",      AbovegroundBiomass = "Aboveground~biomass",
  RootBiomass = "Root~biomass",  AQY = "AQY",  Rd = "R[d]",
  LCP = "LCP", LSP = "LSP",      Pnmax = "P[n]*'max'",
  Rubisco = "Rubisco~activity",  ChlTotal = "Chl~a+b",
  ChlaChlb = "Chl~a/b",          FvFm = "F[v]/F[m]",
  PhiPSII = "Phi[PSII]",         qL = "qL",  NPQ = "NPQ",  YNO = "Y(NO)",
  RootActivity = "Root~activity", AbovegroundN = "Aboveground~N",
  RootN = "Root~N",              AbovegroundCN = "Aboveground~C:N",
  RootCN = "Root~C:N",           PNUEmax = "PNUE[max]",
  SOD = "SOD", POD = "POD", CAT = "CAT", Proline = "Proline",
  SolubleSugar = "Soluble~sugar", SolubleProtein = "Soluble~protein",
  MDA = "MDA", REC = "REC"
)

fert_cols <- c(CK = "#7F7F7F", F = "#0072B2", MF = "#009E73",
               OF = "#D55E00", FS = "#F0E442")
fert_lvls  <- c("CK", "F", "MF", "OF", "FS")
box_lvls   <- c("CK", "F", "OF", "MF", "FS")
stage_lvls <- c("Erecting stage", "Jointing stage", "Anthesis stage")
stage_key  <- c("Erecting stage" = "Erecting",
                "Jointing stage" = "Jointing",
                "Anthesis stage" = "Anthesis")
pc1_col <- "#AD6FA8"
pc2_col <- "#6FA8AD"
HIGHLIGHT_COL <- "#1F4E9C"   # deep blue for the highlighted near-overlap indicator

TT <- 499
SEED <- 123

dat <- dat %>%
  mutate(
    Fertilization = factor(Fertilization, levels = fert_lvls),
    Position = factor(Position, levels = c("UP", "BP", "FS"))
  )

## ------------------------------------------------ theme --------------
base_theme <- theme_bw(base_size = 7, base_family = "sans") +
  theme(
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.45),
    panel.grid   = element_blank(),
    axis.ticks   = element_line(linewidth = 0.3, colour = "black"),
    axis.ticks.length = unit(-2.5, "pt"),
    axis.title   = element_text(size = 7.5, face = "bold", colour = "black"),
    axis.text    = element_text(size = 6.3, colour = "black"),
    plot.tag     = element_text(size = 9.5, face = "bold", colour = "black"),
    plot.tag.position = "topleft",
    plot.title   = element_text(size = 8.5, face = "bold", hjust = 0, colour = "black"),
    strip.text   = element_text(size = 7, face = "bold"),
    legend.title = element_text(size = 6.2, face = "bold"),
    legend.text  = element_text(size = 5.8),
    legend.key.size = unit(2.8, "mm"),
    plot.margin = margin(4, 5, 4, 5)
  )

## ------------------------------------------------ statistics ---------
kw_dunn <- function(y, g) {
  ok <- is.finite(y)
  y <- y[ok]; g <- droplevels(g[ok])
  n <- length(y); k <- nlevels(g)
  r  <- rank(y)
  Ni <- as.numeric(table(g))
  Rb <- tapply(r, g, mean)
  tt <- table(y)
  Sigt <- sum(tt^3 - tt)
  H  <- (12 / (n * (n + 1))) * sum(Ni * Rb^2) - 3 * (n + 1)
  Hc <- H / (1 - Sigt / (n^3 - n))
  p_kw <- pchisq(Hc, df = k - 1, lower.tail = FALSE)
  vr <- n * (n + 1) / 12 - Sigt / (12 * (n - 1))
  gl <- levels(g)
  cmb <- combn(k, 2)
  z <- p <- numeric(ncol(cmb))
  for (m in seq_len(ncol(cmb))) {
    i1 <- gl[cmb[1, m]]; i2 <- gl[cmb[2, m]]
    z[m] <- (Rb[[i1]] - Rb[[i2]]) /
      sqrt(vr * (1 / Ni[cmb[1, m]] + 1 / Ni[cmb[2, m]]))
    p[m] <- 2 * pnorm(-abs(z[m]))
  }
  p_holm <- p.adjust(p, method = "holm")
  pm <- matrix(1, k, k, dimnames = list(gl, gl))
  for (m in seq_len(ncol(cmb))) {
    pm[gl[cmb[1, m]], gl[cmb[2, m]]] <- p_holm[m]
    pm[gl[cmb[2, m]], gl[cmb[1, m]]] <- p_holm[m]
  }
  list(kw_p = p_kw, mean_rank = Rb,
       pairs = data.frame(g1 = gl[cmb[1, ]], g2 = gl[cmb[2, ]],
                          z = z, p_raw = p, p_holm = p_holm,
                          stringsAsFactors = FALSE),
       padj = pm)
}

cld_letters <- function(order_stat, padj, alpha = 0.05) {
  gs <- names(sort(order_stat, decreasing = TRUE))
  k  <- length(gs)
  sets <- vector("list", k); names(sets) <- gs
  nxt <- 1
  for (i in seq_len(k)) {
    gi <- gs[i]
    cand <- character(0)
    for (j in seq_len(i - 1)) {
      gj <- gs[j]
      if (!is.na(padj[gi, gj]) && padj[gi, gj] >= alpha) cand <- union(cand, sets[[gj]])
    }
    valid <- character(0)
    for (l in cand) {
      holders <- gs[vapply(gs, function(g) l %in% sets[[g]], logical(1))]
      if (all(padj[gi, holders] >= alpha)) valid <- c(valid, l)
    }
    if (length(valid) == 0) {
      repeat {
        valid <- letters[nxt]; nxt <- nxt + 1
        if (!valid %in% unlist(sets)) break
      }
    }
    sets[[gi]] <- sort(unique(valid))
  }
  vapply(sets, paste, character(1), collapse = "")
}

fmt_p <- function(p) if (p < 0.001) "KW p<0.001" else sprintf("KW p=%.3f", p)

run_pca <- function(X) {
  res <- FactoMineR::PCA(X, scale.unit = TRUE, ncp = 2, graph = FALSE)
  list(ind     = res$ind$coord[, 1:2, drop = FALSE],
       var     = res$var$coord[, 1:2, drop = FALSE],
       contrib = res$var$contrib[, 1:2, drop = FALSE],
       eig     = res$eig[1:2, 2])
}

score_rows <- list(); contrib_rows <- list(); loading_rows <- list()
eig_rows <- list(); kw_group_rows <- list(); kw_pair_rows <- list()
highlight_rows <- list()
fig_log <- character(0)

COMP_W <- 8.27; COMP_H <- 3.15
BOX_W <- 9.00; BOX_H <- 6.00

## =====================================================================
## PART 1: pooled PCA (all three stages together), per module
## =====================================================================
for (md in names(modules)) {
  vlist <- modules[[md]]$vars
  X <- as.data.frame(dat[, vlist])
  rownames(X) <- dat$SampleID
  full <- run_pca(X)

  set.seed(SEED)
  bs <- modelr::bootstrap(X, n = TT)
  p  <- ncol(X)
  boot_contrib <- array(NA_real_, c(TT, p, 2))
  boot_var     <- array(NA_real_, c(TT, p, 2))
  boot_eig     <- matrix(NA_real_, TT, 2)
  for (j in seq_len(TT)) {
    Xb <- as.data.frame(bs$strap[[j]])
    rb <- run_pca(Xb)
    boot_contrib[j, , ] <- rb$contrib
    boot_var[j, , ]     <- rb$var
    boot_eig[j, ]       <- rb$eig
  }

  contr_sum <- bind_rows(lapply(1:2, function(k) {
    data.frame(module = md, var = colnames(X), PC = paste0("PC", k),
               contrib_full   = full$contrib[, k],
               contrib_mean   = colMeans(boot_contrib[, , k]),
               contrib_median = apply(boot_contrib[, , k], 2, median),
               contrib_sd     = apply(boot_contrib[, , k], 2, sd))
  }))
  load_sum <- bind_rows(lapply(1:2, function(k) {
    data.frame(module = md, var = colnames(X), PC = paste0("PC", k),
               loading_full   = full$var[, k],
               loading_mean   = colMeans(boot_var[, , k]),
               loading_median = apply(boot_var[, , k], 2, median),
               loading_sd     = apply(boot_var[, , k], 2, sd))
  }))
  eig_sum <- data.frame(module = md, PC = c("PC1", "PC2"),
                        eig_full_pct = full$eig,
                        eig_mean_pct = colMeans(boot_eig),
                        eig_median_pct = apply(boot_eig, 2, median),
                        eig_sd_pct   = apply(boot_eig, 2, sd))
  contrib_rows[[length(contrib_rows) + 1]] <- contr_sum
  loading_rows[[length(loading_rows) + 1]] <- load_sum
  eig_rows[[length(eig_rows) + 1]] <- eig_sum

  ## sample scores (one PCA; scores carry each sample's stage for later plots)
  sc <- data.frame(
    SampleID = dat$SampleID, module = md,
    stage = as.character(dat$Stage), Replicate = dat$Replicate,
    Position = as.character(dat$Position),
    Fertilization = as.character(dat$Fertilization),
    PC1 = full$ind[, 1], PC2 = full$ind[, 2], stringsAsFactors = FALSE)
  score_rows[[length(score_rows) + 1]] <- sc

  eig1 <- full$eig[1]; eig2 <- full$eig[2]
  xlab <- sprintf("PC1 (%.1f%%)", eig1)
  ylab <- sprintf("PC2 (%.1f%%)", eig2)

  ## ---- (a) loading-only PCA plot ----
  vr <- data.frame(var = colnames(X), x = full$var[, 1], y = full$var[, 2])
  vr$lab <- plotmath_lab[vr$var]
  ang <- atan2(vr$y, vr$x)
  n <- nrow(vr)

  ## near-parallel pairs (angle diff < 12 deg); highlight ONLY ONE member
  ## of each connected near-overlap cluster (deep blue), the rest stay grey.
  ## Rule: within a cluster, keep the member with the largest loading norm
  ## grey (it is the "reference"); every other member is highlighted blue.
  angmat <- outer(ang, ang, function(a, b) {
    d <- (a - b + pi) %% (2 * pi) - pi
    abs(d) < 12 * pi / 180
  })
  diag(angmat) <- FALSE
  cluster <- rep(NA_integer_, n); nc <- 0
  for (i in seq_len(n)) {
    if (is.na(cluster[i])) {
      nc <- nc + 1
      queue <- i; cluster[i] <- nc
      while (length(queue) > 0) {
        cur <- queue[1]; queue <- queue[-1]
        nbr <- which(angmat[cur, ] & is.na(cluster))
        cluster[nbr] <- nc; queue <- c(queue, nbr)
      }
    }
  }
  vr$cluster <- cluster
  norm <- sqrt(vr$x^2 + vr$y^2)
  vr$highlight <- FALSE
  for (cl in unique(cluster)) {
    cli <- which(cluster == cl)
    if (length(cli) > 1) {
      ref <- cli[which.max(norm[cli])]           # largest-loading member = grey ref
      vr$highlight[setdiff(cli, ref)] <- TRUE   # others (the near-overlap ones) blue
    }
  }

  ## stagger label anchors by angle rank within each cluster
  vr$mult <- 1.12
  for (cl in unique(cluster)) {
    cli <- which(cluster == cl)
    if (length(cli) > 1) {
      ord <- order(ang[cli]); rk <- match(cli, cli[ord])
      for (m in seq_along(cli)) {
        r_i <- max(norm[cli[m]], 0.3)
        vr$mult[cli[m]] <- min(1.12 + 0.15 * (rk[m] - 1), 1.32 / r_i)
      }
    }
  }
  vr$xl <- vr$x * vr$mult; vr$yl <- vr$y * vr$mult
  vr$arrow_col <- ifelse(vr$highlight, HIGHLIGHT_COL, "grey20")
  vr$lab_col   <- ifelse(vr$highlight, HIGHLIGHT_COL, "grey10")
  vr$seg_col   <- ifelse(vr$highlight, HIGHLIGHT_COL, "grey55")

  ## record which variables were highlighted (for the QA note)
  if (any(vr$highlight)) {
    highlight_rows[[length(highlight_rows) + 1]] <- data.frame(
      module = md, var = vr$var[vr$highlight],
      cluster = vr$cluster[vr$highlight], stringsAsFactors = FALSE)
  }

  is_horiz <- abs(sin(ang)) < sin(35 * pi / 180)
  vr_h <- vr[is_horiz, ]; vr_o <- vr[!is_horiz, ]
  cir <- data.frame(x = cos(seq(0, 2 * pi, length.out = 181)),
                    y = sin(seq(0, 2 * pi, length.out = 181)))
  pa <- ggplot() +
    geom_path(data = cir, aes(x, y), linetype = "longdash",
              colour = "grey70", linewidth = 0.25) +
    geom_vline(xintercept = 0, linetype = "dashed", colour = "grey62", linewidth = 0.25) +
    geom_hline(yintercept = 0, linetype = "dashed", colour = "grey62", linewidth = 0.25) +
    geom_segment(data = vr, aes(x = 0, y = 0, xend = x, yend = y),
                 arrow = grid::arrow(length = unit(1.7, "mm"), type = "closed"),
                 linewidth = 0.42, lineend = "round", colour = vr$arrow_col) +
    geom_text_repel(data = vr_h, aes(xl, yl, label = lab), direction = "y",
                    parse = TRUE, size = 2.05, colour = vr_h$lab_col,
                    fontface = "bold", seed = 7, max.overlaps = Inf,
                    min.segment.length = 0.12, box.padding = 0.78,
                    point.padding = 0.35, force = 7.5, force_pull = 0.35,
                    max.time = 6, max.iter = 20000,
                    segment.colour = vr_h$seg_col, segment.size = 0.25,
                    show.legend = FALSE) +
    geom_text_repel(data = vr_o, aes(xl, yl, label = lab), direction = "both",
                    parse = TRUE, size = 2.05, colour = vr_o$lab_col,
                    fontface = "bold", seed = 7, max.overlaps = Inf,
                    min.segment.length = 0.12, box.padding = 0.78,
                    point.padding = 0.35, force = 7.5, force_pull = 0.35,
                    max.time = 6, max.iter = 20000,
                    segment.colour = vr_o$seg_col, segment.size = 0.25,
                    show.legend = FALSE) +
    coord_cartesian(xlim = c(-1.32, 1.32), ylim = c(-1.32, 1.32), clip = "off") +
    labs(x = xlab, y = ylab, tag = "a") +
    base_theme

  ## ---- (b)(c) contribution plots (shared y-range; variables sorted by
  ##      contribution, high -> low = top -> bottom after coord_flip) ----
  cont_max <- max(contr_sum$contrib_mean + contr_sum$contrib_sd, na.rm = TRUE)
  make_contrib <- function(k, colr, tagg) {
    dtrue <- contr_sum %>% filter(PC == paste0("PC", k))
    ## ascending order so the HIGHEST contribution is the last factor level
    ## and thus appears at the TOP after coord_flip
    ord <- dtrue$var[order(dtrue$contrib_full)]
    dtrue <- dtrue %>% mutate(var_f = factor(var, levels = ord))
    dboot <- as.data.frame(boot_contrib[, , k]) %>%
      setNames(colnames(X)) %>%
      pivot_longer(everything(), names_to = "var", values_to = "cb") %>%
      mutate(var_f = factor(var, levels = ord))
    ggplot(dtrue, aes(var_f, contrib_full)) +
      geom_col(fill = colr, colour = "grey15", linewidth = 0.2, width = 0.62) +
      geom_errorbar(aes(ymin = pmax(contrib_mean - contrib_sd, 0),
                        ymax = contrib_mean + contrib_sd),
                    width = 0.32, linewidth = 0.32, colour = "grey15") +
      geom_jitter(data = dboot, aes(var_f, cb), width = 0.13,
                  alpha = 0.06, colour = "grey25", shape = 18, size = 0.32) +
      geom_point(aes(var_f, contrib_mean), shape = 18, size = 1.35,
                 colour = "grey10", alpha = 0.95) +
      coord_flip(ylim = c(0, cont_max * 1.06), clip = "off") +
      scale_x_discrete(labels = function(l) parse(text = plotmath_lab[l])) +
      labs(x = NULL, y = paste0("PC", k, " contribution (%)"), tag = tagg) +
      base_theme +
      theme(axis.text.y = element_text(size = 6.0, colour = "black"))
  }
  pb1 <- make_contrib(1, pc1_col, "b")
  pb2 <- make_contrib(2, pc2_col, "c")

  comp <- (pa | pb1 | pb2) +
    plot_layout(widths = c(1.05, 1, 1)) +
    plot_annotation(
      title = paste0(md, " module (all stages pooled)"),
      theme = theme(plot.title = element_text(size = 8.5, face = "bold",
                                              hjust = 0, colour = "black",
                                              family = "sans"))
    )

  fname <- paste0("PCA_", md)
  grDevices::png(file.path(fig_dir, paste0(fname, ".png")),
                 width = COMP_W, height = COMP_H, units = "in",
                 res = 600, type = "cairo", family = "sans", bg = "white")
  print(comp); dev.off()
  grDevices::cairo_pdf(file.path(fig_dir, paste0(fname, ".pdf")),
                       width = COMP_W, height = COMP_H, family = "sans")
  print(comp); dev.off()
  grDevices::svg(file.path(fig_dir, paste0(fname, ".svg")),
                 width = COMP_W, height = COMP_H, family = "sans")
  print(comp); dev.off()
  fig_log <- c(fig_log, paste0(fname, ": done (", nrow(X), " samples pooled)"))
  cat("finished:", fname, "\n")
}

## =====================================================================
## PART 2: merged score boxplots (per module: PC1/PC2 x 3 stages)
## Within each stage subplot, the two planting positions are plotted as
## SEPARATE boxes for the SAME fertilization treatment:
##   UP = Under panel   = 板下  -> hollow box
##   BP = Between panel = 板间  -> solid box
##   FS = Full-sun reference (Anthesis only) -> single solid box
## v6 (per user request):
##   - ALL raw data points hollow (white interior) + grey + ~45% smaller,
##     drawn ABOVE the box layer (position is encoded by the BOX only);
##   - vertical mean +/- SD error bars added, KW letters removed;
##   - Y axis fixed to [-5, 5] with breaks -5 / -2.5 / 0 / 2.5 / 5.
## =====================================================================
score_df <- bind_rows(score_rows)

pos_fill_rule <- function(pos, fert) {
  ifelse(pos == "UP", "white", unname(fert_cols[as.character(fert)]))
}
dodge_gap <- 0.20
box_w     <- 0.34        # box width
cap_w     <- box_w * 0.8 # whisker-cap width = 80% of box width

for (md in names(modules)) {
  smod <- score_df %>% filter(module == md)
  panel_list <- list(); idx <- 0
  for (k in 1:2) {
    ycol <- paste0("PC", k)
    for (st in stage_lvls) {
      idx <- idx + 1
      tagg <- c("a", "b", "c", "d", "e", "f")[idx]
      sdf <- smod %>% filter(stage == st) %>%
        mutate(Fert = droplevels(factor(Fertilization, levels = box_lvls)))
      trt_lvls <- levels(sdf$Fert)
      fert_x   <- setNames(seq_along(trt_lvls), trt_lvls)
      sdf <- sdf %>%
        mutate(
          x = ifelse(Position == "UP", as.integer(Fert) - dodge_gap,
              ifelse(Position == "BP", as.integer(Fert) + dodge_gap,
                     as.integer(Fert))),
          Grp = factor(paste0(Fert, "_", Position)),
          BoxFill = pos_fill_rule(Position, Fert)
        )
      ## KW + Dunn(Holm) retained for the summary tables only (not plotted)
      kw  <- kw_dunn(sdf[[ycol]], sdf$Grp)
      let <- cld_letters(kw$mean_rank, kw$padj)
      kw_group_rows[[length(kw_group_rows) + 1]] <- data.frame(
        module = md, stage = st, PC = ycol,
        group = names(let),
        fert = sub("_.*$", "", names(let)),
        position = sub("^.*_", "", names(let)),
        n = as.numeric(table(sdf$Grp)[names(let)]),
        mean_score = as.numeric(tapply(sdf[[ycol]], sdf$Grp, mean)[names(let)]),
        mean_rank = as.numeric(kw$mean_rank[names(let)]),
        kw_p = kw$kw_p,
        letter = unname(let), row.names = NULL)
      kw_pair_rows[[length(kw_pair_rows) + 1]] <-
        data.frame(module = md, stage = st, PC = ycol, kw$pairs, row.names = NULL)
      top_row  <- k == 1
      left_col <- st == stage_lvls[1]
      gp <- ggplot(sdf, aes(x, .data[[ycol]])) +
        ## horizontal whisker caps at the upper/lower whisker tips (80% of box)
        stat_boxplot(aes(group = Grp, colour = Fert), geom = "errorbar",
                     width = cap_w, linewidth = 0.28) +
        geom_boxplot(aes(group = Grp, fill = BoxFill, colour = Fert),
                     outlier.shape = NA, width = box_w, linewidth = 0.28,
                     alpha = 0.92, median.linewidth = 0.5) +
        geom_jitter(shape = 21, fill = "white", colour = "grey45",
                    size = 0.8, stroke = 0.35, width = 0.07, alpha = 0.9) +
        stat_summary(aes(group = Grp), fun = mean, geom = "point",
                     shape = 18, size = 1.4, colour = "black") +
        scale_fill_identity() +
        scale_colour_manual(values = fert_cols) +
        scale_x_continuous(breaks = as.numeric(fert_x), labels = trt_lvls,
                           limits = c(0.45, length(trt_lvls) + 0.55)) +
        scale_y_continuous(limits = c(-5, 5), breaks = seq(-5, 5, 2.5),
                           oob = scales::squish) +
        labs(y = if (left_col) paste0("PC", k, " score") else NULL,
             x = if (!top_row) "Fertilization" else NULL,
             title = if (top_row) st else NULL,
             tag = tagg) +
        base_theme +
        theme(legend.position = "none",
              axis.text.x = element_text(size = 6.0, colour = "black"))
      panel_list[[idx]] <- gp
    }
  }
  merged <- (panel_list[[1]] | panel_list[[2]] | panel_list[[3]]) /
            (panel_list[[4]] | panel_list[[5]] | panel_list[[6]])
  ## position legend (open = 板下 / filled = 板间), placed at the bottom
  leg_df <- data.frame(
    Position = factor(c("UP", "BP"), levels = c("UP", "BP")))
  leg <- ggplot(leg_df, aes(1, 1, fill = Position)) +
    geom_point(shape = 22, size = 2.6, colour = "grey35", stroke = 0.5) +
    scale_fill_manual(
      values = c("UP" = "white", "BP" = "grey35"),
      labels = c("UP" = "\u677F\u4E0B Under panel (UP)",
                 "BP" = "\u677F\u95F4 Between panel (BP)"),
      name = NULL) +
    theme_void() +
    theme(legend.position = "bottom", legend.direction = "horizontal",
          legend.justification = "center",
          legend.text = element_text(size = 7, colour = "black",
                                     family = "Microsoft YaHei"),
          legend.key.size = unit(3.2, "mm"),
          legend.margin = margin(0, 0, 0, 0))
  leg_g <- ggplotGrob(leg)
  leg_only <- leg_g$grobs[[which(leg_g$layout$name == "guide-box-bottom")]]
  merged <- (merged / wrap_elements(full = leg_only)) +
    plot_layout(widths = rep(1, 3), heights = c(1, 1, 0.10)) +
    plot_annotation(
      title = paste0(md, " module | PC scores (pooled PCA)"),
      theme = theme(plot.title = element_text(size = 9, face = "bold",
                                              hjust = 0, colour = "black",
                                              family = "sans"))
    )
  fname <- paste0("PCA_scores_", md)
  grDevices::png(file.path(fig_dir, paste0(fname, ".png")),
                 width = BOX_W, height = BOX_H, units = "in",
                 res = 600, type = "cairo", family = "sans", bg = "white")
  print(merged); dev.off()
  grDevices::cairo_pdf(file.path(fig_dir, paste0(fname, ".pdf")),
                       width = BOX_W, height = BOX_H, family = "sans")
  print(merged); dev.off()
  grDevices::svg(file.path(fig_dir, paste0(fname, ".svg")),
                 width = BOX_W, height = BOX_H, family = "sans")
  print(merged); dev.off()
  fig_log <- c(fig_log, paste0(fname, ": done (板下/板间 separated)"))
  cat("finished:", fname, "\n")
}

## ------------------------------------------------ tables -------------
contrib_df <- bind_rows(contrib_rows)
loading_df <- bind_rows(loading_rows)
eig_df     <- bind_rows(eig_rows)
score_df$stage <- factor(score_df$stage, levels = stage_lvls)
write_csv(contrib_df, file.path(tab_dir, "PCA_variable_contributions_bootstrap.csv"))
write_csv(loading_df, file.path(tab_dir, "PCA_variable_loadings_bootstrap.csv"))
write_csv(eig_df,     file.path(tab_dir, "PCA_explained_variance.csv"))
write_csv(score_df,   file.path(tab_dir, "PC_scores_per_sample.csv"))
write_csv(bind_rows(kw_group_rows), file.path(tab_dir, "KW_Dunn_group_letters.csv"))
write_csv(bind_rows(kw_pair_rows),  file.path(tab_dir, "KW_Dunn_pairwise_pvalues.csv"))
if (length(highlight_rows)) {
  write_csv(bind_rows(highlight_rows), file.path(tab_dir, "highlighted_near_overlap_variables.csv"))
}

method_note <- c(
  "Modular PCA analysis v8 - method note",
  "",
  "v8 change (per user request):",
  "1. Contribution panels (b/c): variables are now sorted by contribution",
  "   from HIGH to LOW (top to bottom) within each panel. PC1 and PC2 each",
  "   rank their own variables, which helps read the physiological meaning",
  "   of each principal component. Loading panel (a) is unchanged.",
  "",
  "Unchanged from v7:",
  "- Boxplots: box + whiskers with horizontal whisker caps (80% of box",
  "  width), hollow-grey raw points above the box, black mean diamond,",
  "  Y axis fixed to [-5, 5] with breaks -5 / -2.5 / 0 / 2.5 / 5.",
  "- Inward tick marks; pooled PCA; near-overlap deep-blue highlight.",
  "",
  "Method (unchanged): FactoMineR::PCA(scale.unit = TRUE, ncp = 2);",
  "modelr::bootstrap(n = 499, seed = 123).",
  "",
  "Note: FS (full-sun reference) exists only at the Anthesis stage."
)
writeLines(method_note, file.path(tab_dir, "README_method.txt"))

cat("\n===== SUMMARY =====\n")
cat(paste(fig_log, collapse = "\n"), "\n")
cat("\nHighlighted near-overlap variables (deep blue):\n")
if (length(highlight_rows)) {
  print(as.data.frame(bind_rows(highlight_rows)))
} else {
  cat("  (none)\n")
}
cat("\nExplained variance (pooled PCA):\n")
print(as.data.frame(eig_df[, c("module", "PC", "eig_full_pct")]))
