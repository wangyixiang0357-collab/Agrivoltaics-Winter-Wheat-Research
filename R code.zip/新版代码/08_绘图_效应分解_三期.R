## ============================================================
##  三期 PLS-PM 效应分解图（v3）
##  · 去掉面板内部网格线，只保留外框与零线
##  · 每个预测变量的 直接效应 + 间接效应 合并为一根堆叠柱（同一 X 位置）
##    总效应单独一根，与之同组
##  · 柱宽 +30%
##  · 组内两柱净距 = 柱宽的 8%
##  · 组间净距、两侧轴线留白 各 +20%
##  输入：01_路径系数与bootstrap区间.csv
##  效应由路径系数反推：T = (I - B)^-1 - I ；indirect = total - direct
## ============================================================
suppressMessages({ library(ggplot2); library(patchwork) })

DIR    <- "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/随机森林/_当前DLI版_结果/20261022"
IN     <- file.path(DIR, "01_路径系数与bootstrap区间.csv")
TARGET <- "Y"      # 效应终点：Y = 产量；改成 "GR" 即看向生长量的效应
ONE_BY <- FALSE    # TRUE = 三个生育期各出一张单图（88 mm 单栏）

## ---------- 1. 读路径系数 ----------
p <- read.csv(IN, stringsAsFactors = FALSE, fileEncoding = "UTF-8")
p$stage <- factor(p$stage,
                  levels = c("Erecting stage", "Jointing stage", "Anthesis stage"),
                  labels = c("Erecting", "Jointing", "Anthesis"))

## ---------- 2. 由 β 反推 直接 / 间接 / 总效应 ----------
eff_one <- function(g, target) {
  nodes <- unique(c(g$from, g$to))
  B <- matrix(0, length(nodes), length(nodes), dimnames = list(nodes, nodes))
  for (i in seq_len(nrow(g))) B[g$to[i], g$from[i]] <- g$beta[i]
  TT <- solve(diag(length(nodes)) - B) - diag(length(nodes))
  pr <- setdiff(nodes, target)
  data.frame(stage = g$stage[1], predictor = pr,
             direct = as.numeric(B[target, pr]),
             total  = as.numeric(TT[target, pr]), stringsAsFactors = FALSE)
}
eff <- do.call(rbind, lapply(split(p, p$stage), eff_one, target = TARGET))
eff$indirect <- eff$total - eff$direct

ORD <- c("PV", "FERT", "SHC", "PR", "SA", "PH", "GR")   # 因果先后顺序
eff$predictor <- factor(eff$predictor, levels = intersect(ORD, unique(eff$predictor)))
write.csv(eff, file.path(DIR, "08_效应_产量_三期.csv"), row.names = FALSE)

## ---------- 3. 几何参数 ----------
## 量纲 = 一个预测变量占 1 个类别单位。
## v2 实测基准（dodge 0.78 三等分）：单柱宽 0.26、组间净距 0.22
BASE_BW  <- 0.26
BASE_GAP <- 0.22

BW    <- BASE_BW * 1.30            # 0.3380  柱宽 +30%
INNER <- 0.08 * BW                 # 0.0270  组内净距 = 8% 柱宽
GRP   <- 2 * BW + INNER            # 0.7030  一组（堆叠柱 + 总效应柱）总宽
GAP   <- BASE_GAP * 1.20           # 0.2640  组间净距 +20%
D     <- GRP + GAP                 # 0.9670  相邻两组中心距
PAD   <- 0.50 * BW                 # 0.1690  最外侧柱外缘到左右轴线的距离 = 50% 柱宽

## 柱体不描边（linewidth = 0，避免柱缘出现白边/发丝线）
## SEAM = TRUE 时在堆叠柱内部同号接缝处补一条白色细线，便于区分直接/间接两段
SEAM     <- FALSE
SEAM_LWD <- 0.45

TOL <- 1e-9

COL <- c("Direct effect"   = "#4477AA",
         "Indirect effect" = "#F0E442",
         "Total effect"    = "#6FA8DC")
LEV <- c("Direct effect", "Indirect effect", "Total effect")

## ---------- 4. 生成矩形 ----------
## 正分量自零线向上累加、负分量自零线向下累加：
## 堆叠柱上端 = 正分量之和，下端 = 负分量之和，净长度恒等于总效应。
## 返回 list(rect = 柱体, seg = 堆叠接缝, cx = 各组中心坐标)
mk_rects <- function(g) {
  g  <- g[order(g$predictor), ]
  n  <- nrow(g)
  cx <- (seq_len(n) - 1) * D
  out <- vector("list", 0)
  seg <- vector("list", 0)
  push <- function(xc, y0, y1, ef, pred) {
    if (abs(y1 - y0) < TOL) return(invisible(NULL))
    out[[length(out) + 1]] <<- data.frame(
      xmin = xc - BW / 2, xmax = xc + BW / 2, ymin = y0, ymax = y1,
      effect = ef, predictor = pred, stringsAsFactors = FALSE)
    invisible(NULL)
  }
  for (k in seq_len(n)) {
    d <- g$direct[k]; i <- g$indirect[k]; tt <- g$total[k]
    pred <- as.character(g$predictor[k])
    xl <- cx[k] - (BW + INNER) / 2      # 左柱：直接 + 间接
    xr <- cx[k] + (BW + INNER) / 2      # 右柱：总效应
    up <- 0; dn <- 0
    for (ef in c("Direct effect", "Indirect effect")) {
      v <- if (ef == "Direct effect") d else i
      if (v > TOL)       { push(xl, up, up + v, ef, pred); up <- up + v }
      else if (v < -TOL) { push(xl, dn + v, dn, ef, pred); dn <- dn + v }
    }
    ## 同号两段相接处补一条白色细线（只在接缝内部画，不占柱宽）
    if (abs(d) > TOL && abs(i) > TOL && sign(d) == sign(i))
      seg[[length(seg) + 1]] <- data.frame(
        x = xl - BW / 2, xend = xl + BW / 2, y = d,
        effect = "Direct effect", predictor = pred, stringsAsFactors = FALSE)
    push(xr, 0, tt, "Total effect", pred)
  }
  rect <- do.call(rbind, out); rect$stage <- g$stage[1]
  sg <- if (length(seg)) do.call(rbind, seg) else
    data.frame(x = numeric(0), xend = numeric(0), y = numeric(0),
               effect = character(0), predictor = character(0), stringsAsFactors = FALSE)
  list(rect = rect, seg = sg, cx = cx)
}
objs <- lapply(split(eff, eff$stage), mk_rects)

## y 轴三期共用，便于横向比较
all_r <- do.call(rbind, lapply(objs, function(o) o$rect[, c("xmin", "xmax", "ymin", "ymax")]))
yr <- range(c(all_r$ymin, all_r$ymax, 0))
YLO <- yr[1] - 0.10 * diff(yr)
YHI <- yr[2] + 0.12 * diff(yr)

## ---------- 5. 单面板 ----------
mk_panel <- function(o, st, show_y, show_x) {
  rect <- o$rect; seg <- o$seg; cx <- o$cx
  ## 注意：最外侧柱的外缘在 组中心 ± GRP/2 处（不是 BW/2），
  ## 否则最左/最右那根柱会落在 limits 之外被裁掉
  xlim <- c(min(cx) - GRP / 2 - PAD, max(cx) + GRP / 2 + PAD)
  lev  <- levels(droplevels(factor(rect$predictor, levels = unique(rect$predictor))))
  ggplot(rect, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = effect)) +
    geom_hline(yintercept = 0, colour = "grey15", linewidth = 0.30) +
    geom_rect(colour = NA, linewidth = 0) +      # 柱体不描边：柱缘无白边
    { if (SEAM) geom_segment(data = seg, aes(x = x, xend = xend, y = y, yend = y),
                             inherit.aes = FALSE, colour = "white",
                             linewidth = SEAM_LWD) } +
    scale_fill_manual(values = COL, breaks = LEV, limits = LEV, drop = FALSE, name = NULL) +
    scale_x_continuous(breaks = cx, labels = lev, limits = xlim,
                       expand = expansion(mult = 0)) +
    scale_y_continuous(limits = c(YLO, YHI), expand = expansion(mult = 0)) +
    labs(x = if (show_x) "Predictor of grain yield" else NULL,
         y = if (show_y) expression("Standardized effect size (" * beta * ")") else NULL,
         title = st) +
    theme_bw(base_size = 9, base_family = "sans") +
    theme(
      panel.grid        = element_blank(),      # 去掉面板内部所有线条
      panel.border      = element_rect(colour = "black", fill = NA, linewidth = 0.5),
      axis.text         = element_text(colour = "black", size = 8),
      axis.text.x       = element_text(angle = 35, hjust = 1, vjust = 1, size = 7.6,
                                       margin = margin(t = 1.4)),
      axis.title.x      = element_text(size = 9, margin = margin(t = 2.5)),
      axis.title.y      = element_text(size = 9, margin = margin(r = 3)),
      axis.ticks        = element_line(colour = "black", linewidth = 0.35),
      axis.ticks.length = unit(1.2, "mm"),
      plot.title        = element_text(hjust = 0.5, face = "bold", size = 8.5,
                                       margin = margin(b = 2.5)),
      plot.title.position = "panel",
      legend.position   = "right",
      legend.text       = element_text(size = 8, margin = margin(l = 1.2)),
      legend.key.size   = unit(3.4, "mm"),
      legend.background = element_blank(),
      plot.margin       = margin(3, 3, 3, if (show_y) 3 else 3)
    ) +
    if (!show_y) theme(axis.text.y = element_blank(), axis.ticks.y = element_blank())
}

ns <- vapply(objs, function(o) length(o$cx), integer(1))
plots <- Map(function(o, st, k) mk_panel(o, st, k == 1, k == 2),
             objs, names(objs), seq_along(objs))

## ---------- 6. 组合与导出 ----------
g <- wrap_plots(plots, nrow = 1) +
  plot_layout(widths = ns, guides = "collect") &
  theme(legend.position = "right")

if (!ONE_BY) {
  ggsave(file.path(DIR, "Fig_effects_three_stages.pdf"), g,
         width = 190, height = 82, units = "mm", device = cairo_pdf)
  ggsave(file.path(DIR, "Fig_effects_three_stages.tiff"), g,
         width = 190, height = 82, units = "mm", dpi = 600,
         compression = "lzw", bg = "white")
} else {
  for (k in seq_along(plots)) {
    st <- names(rects)[k]
    ggsave(file.path(DIR, paste0("Fig_effects_", st, ".pdf")), plots[[k]],
           width = 88, height = 74, units = "mm", device = cairo_pdf)
    ggsave(file.path(DIR, paste0("Fig_effects_", st, ".tiff")), plots[[k]],
           width = 88, height = 74, units = "mm", dpi = 600,
           compression = "lzw", bg = "white")
  }
}

## ---------- 7. 几何自检 ----------
cat(sprintf("柱宽 BW = %.4f   组内净距 = %.4f (= %.1f%% BW)   组占 = %.4f\n",
            BW, INNER, 100 * INNER / BW, GRP))
cat(sprintf("组间净距 = %.4f (+20%%)   类别间距 D = %.4f   轴线留白 = %.4f (= %.0f%% BW)\n",
            GAP, D, PAD, 100 * PAD / BW))
print(eff[order(eff$stage, eff$predictor), ], row.names = FALSE)
