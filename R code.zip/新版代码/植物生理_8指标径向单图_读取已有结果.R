library(readxl)
library(ggplot2)
library(dplyr)
library(tidyr)
library(stringr)
library(tibble)
library(grid)
library(geomtextpath)

# =========================================================
# 每张图只呈现1个指标；8个指标分别生成8张三生育期径向单图。
# 不重新计算均值、SD、ANOVA、Tukey或显著性字母。
# 柱高、误差线和字母：Anthesis_letters；空心数据点：Raw_Sheet1。
# 保留原来的配色、UP空白/BP实心、扇区间距、外圈文字和共用刻度轴。
# =========================================================

# 1. 参数设置 ------------------------------------------------
file_path <- paste0(
  "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/",
  "小麦光合生理/生长与资源获取/植物生理指标完整分析结果.xlsx"
)
metric_pick <- "POD (U/g FW)" # 单独绘图时，在这里修改指标。
plot_all_8 <- TRUE           # TRUE：8指标各1张；FALSE：仅metric_pick。
export_files <- TRUE         # 运行代码时，分别导出PDF、SVG和600 dpi PNG。
show_plots <- TRUE           # 是否在R绘图窗口逐张显示。
output_dir <- file.path(dirname(file_path), "植物生理_8指标径向单图")

# 当前表中，Excel第2至73行是8指标各9组、包含FS的开花期结果。
# 后面的开花期8组字母属于不含FS的另一套比较，不能与9组字母混用。
# 如果移动/重排了该工作表，请同步修改这个范围；范围不匹配时会停止。
anthesis_excel_rows <- c(2L, 73L)

stage_levels <- c("Erecting stage", "Jointing stage", "Anthesis stage")
stage_labels <- setNames(stage_levels, stage_levels)
fert_levels <- c("CK", "F", "MF", "OF", "FS")
plot_group_levels <- c("CKUP", "CKBP", "FUP", "FBP", "MFUP", "MFBP",
                       "OFUP", "OFBP", "FS")
groups8 <- c("BP_CK", "UP_CK", "BP_F", "UP_F",
             "BP_MF", "UP_MF", "BP_OF", "UP_OF")
groups9 <- c(groups8, "FS_FS")
fert_cols <- c(CK = "#7F7F7F", F = "#0072B2", MF = "#009E73",
               OF = "#D55E00", FS = "#F0E442")
stage_cols <- c("Erecting stage" = "#E8D8F6",
                "Jointing stage" = "#DDECFB",
                "Anthesis stage" = "#FFF0C2")
bar_width <- 0.38
inner_gap <- bar_width * 0.05
outer_gap <- bar_width * 0.30
group_span <- 2 * bar_width + inner_gap + outer_gap
stage_gap_ratio <- 0.09 # 与提供的代码相同：平均单扇区宽度的9%。

# 原始点只沿柱宽方向轻微错开，不改变实际纵坐标值。
point_size <- 2.0
point_stroke <- 0.6
point_alpha <- 0.70
point_jitter_width <- bar_width * 0.22
point_seed <- 2026L

# 2. 读取已计算的结果和原始数据 ------------------------------
sum_source <- read_excel(file_path, sheet = "Anthesis_letters")
raw_source <- read_excel(file_path, sheet = "Raw_Sheet1")
summary_columns <- c("Metric", "Stage", "Treatment", "n", "Mean", "SD", "Letter")
raw_group_columns <- c("Stage", "Location", "Fertilization")
if (!all(summary_columns %in% names(sum_source))) {
  stop("Anthesis_letters缺少列：",
       paste(setdiff(summary_columns, names(sum_source)), collapse = ", "))
}
if (!all(raw_group_columns %in% names(raw_source))) {
  stop("Raw_Sheet1缺少Stage、Location或Fertilization列。")
}
sum_source <- sum_source %>%
  mutate(ExcelRow = row_number() + 1L,
         across(all_of(c("Metric", "Stage", "Treatment", "Letter")),
                ~ str_squish(as.character(.x))))
raw_source <- raw_source %>%
  mutate(across(all_of(raw_group_columns), ~ str_squish(as.character(.x))))

# 完整保留表内8个指标，直接沿用原始列名，避免特殊字符不一致。
metrics_all <- names(raw_source)[names(raw_source) %in% unique(sum_source$Metric)]
if (length(metrics_all) != 8L) stop("没有匹配到完整8个指标，请检查两个sheet的指标名。")
if (!metric_pick %in% metrics_all) stop("metric_pick不在表中。可选：",
                                      paste(metrics_all, collapse = "；"))
metrics_to_plot <- if (plot_all_8) metrics_all else metric_pick

# Y轴：NA表示按该指标的原始点及Mean+SD自动确定。
# 每个指标可分别手动设置，不要继续沿用原Rd指标的固定上限5.3。
axis_max <- setNames(rep(NA_real_, length(metrics_all)), metrics_all)
axis_step <- setNames(rep(NA_real_, length(metrics_all)), metrics_all)
axis_digits <- setNames(rep(NA_integer_, length(metrics_all)), metrics_all)
# 手动控制示例：取消注释，再按实际范围修改。
# axis_max["POD (U/g FW)"] <- 6000
# axis_step["POD (U/g FW)"] <- 1000
# axis_digits["POD (U/g FW)"] <- 0
# axis_max["REC (%)"] <- 0.30
# axis_step["REC (%)"] <- 0.05
# axis_digits["REC (%)"] <- 2

# 起身期和拔节期：读取该表中已有8组结果。
# 开花期：明确读取前面的9组结果，不采用后面重复的8组字母。
sum_selected <- bind_rows(
  sum_source %>% filter(Stage %in% stage_levels[1:2]),
  sum_source %>% filter(Stage == "Anthesis stage",
                         ExcelRow >= anthesis_excel_rows[1],
                         ExcelRow <= anthesis_excel_rows[2])
) %>% select(all_of(summary_columns))
expected_keys <- bind_rows(
  expand_grid(Metric = metrics_all, Stage = stage_levels[1:2], Treatment = groups8),
  expand_grid(Metric = metrics_all, Stage = stage_levels[3], Treatment = groups9)
)
key_columns <- c("Metric", "Stage", "Treatment")
if (anyDuplicated(as.data.frame(sum_selected[key_columns]))) {
  stop("选用的汇总结果有重复处理，请核查anthesis_excel_rows，不自动取第一条。")
}
if (nrow(anti_join(expected_keys, sum_selected, by = key_columns)) > 0L ||
    nrow(anti_join(sum_selected, expected_keys, by = key_columns)) > 0L) {
  stop("汇总结果不是每指标8+8+9组；请核查开花期结果行范围。")
}
if (anyNA(sum_selected) || any(sum_selected$Letter == "")) {
  stop("选用的均值、SD、n或字母存在缺失，不自动删除。")
}
if (!all(vapply(sum_selected[c("Mean", "SD", "n")], is.numeric, logical(1))) ||
    any(!is.finite(as.matrix(sum_selected[c("Mean", "SD", "n")])))) {
  stop("Mean、SD和n必须是有限数值。")
}
if (any(sum_selected$SD < 0) || any(sum_selected$Mean < 0)) {
  stop("当前保留的径向柱图以0为基线，不适用于负均值或负SD。")
}
sum_dat_all <- sum_selected %>%
  mutate(Location = sub("_.*$", "", Treatment),
         Fertilization = sub("^[^_]+_", "", Treatment),
         PlotGroup = if_else(Treatment == "FS_FS", "FS",
                              paste0(Fertilization, Location)),
         mean = Mean, sd = SD, groups = Letter,
         Stage = factor(Stage, levels = stage_levels),
         Fertilization = factor(Fertilization, levels = fert_levels),
         PlotGroup = factor(PlotGroup, levels = plot_group_levels))

# 校验原始记录的处理标识及数量；不计算原始数据的均值或SD。
raw_dat <- raw_source %>%
  mutate(Treatment = paste(Location, Fertilization, sep = "_"),
         PlotGroup = if_else(Treatment == "FS_FS", "FS",
                              paste0(Fertilization, Location)))
if (!all(vapply(raw_dat[metrics_all], is.numeric, logical(1))) ||
    anyNA(raw_dat[c(raw_group_columns, metrics_all)]) ||
    any(!is.finite(as.matrix(raw_dat[metrics_all])))) {
  stop("原始数据有缺失、文本或无穷值，不自动删点。")
}
if (any(as.matrix(raw_dat[metrics_all]) < 0)) {
  stop("原始点有负值；当前以0为基线的径向模板需另行调整，不能静默截断。")
}
raw_counts <- raw_dat %>% count(Stage, Treatment, name = "n_raw")
expected_groups <- expected_keys %>% distinct(Stage, Treatment)
if (nrow(anti_join(raw_counts, expected_groups, by = c("Stage", "Treatment"))) > 0L ||
    nrow(anti_join(expected_groups, raw_counts, by = c("Stage", "Treatment"))) > 0L) {
  stop("原始数据处理组合与汇总结果不一致。")
}
count_check <- sum_selected %>%
  left_join(raw_counts, by = c("Stage", "Treatment"))
if (any(count_check$n != count_check$n_raw)) stop("汇总n与原始点数不一致。")
message("保留全部", nrow(raw_dat), "条原始记录；选用", nrow(sum_selected),
        "条已有汇总结果。开花期采用含FS的9组字母，不混用重复8组结果。")

# 3. 沿用原代码的径向位置 ------------------------------------
pos_list <- sector_list <- list()
layout_groups <- sum_dat_all %>% distinct(Stage, Fertilization, Location, PlotGroup)
for (st in stage_levels) {
  stage_groups <- layout_groups %>% filter(Stage == st) %>%
    mutate(across(c(Fertilization, Location, PlotGroup), as.character))
  fert_use <- fert_levels[fert_levels %in% stage_groups$Fertilization]
  pos_stage <- tibble(Fertilization = fert_use,
                      x_center = seq_along(fert_use) * group_span) %>%
    left_join(stage_groups, by = "Fertilization") %>%
    mutate(x_pos = case_when(
      Location == "UP" ~ x_center - (bar_width + inner_gap) / 2,
      Location == "BP" ~ x_center + (bar_width + inner_gap) / 2,
      Location == "FS" ~ x_center
    )) %>% arrange(match(PlotGroup, plot_group_levels))
  pos_list[[st]] <- tibble(Stage = st, PlotGroup = pos_stage$PlotGroup,
                           x_pos = pos_stage$x_pos)
  sector_list[[st]] <- tibble(
    Stage = st,
    xmin = min(pos_stage$x_pos - bar_width / 2) - outer_gap,
    xmax = max(pos_stage$x_pos + bar_width / 2) + outer_gap,
    x_center = mean(range(pos_stage$x_pos))
  )
}
pos_dat <- bind_rows(pos_list)
sector_dat <- bind_rows(sector_list)
sector_width <- sector_dat$xmax - sector_dat$xmin
stage_gap <- mean(sector_width) * stage_gap_ratio
sector_start <- c(0, cumsum(head(sector_width, -1) + stage_gap))
sector_dat$shift <- sector_start - sector_dat$xmin
pos_dat <- pos_dat %>% left_join(sector_dat %>% select(Stage, shift), by = "Stage") %>%
  mutate(x_pos = x_pos + shift) %>% select(-shift)
sector_dat <- sector_dat %>%
  mutate(xmin = xmin + shift, xmax = xmax + shift, x_center = x_center + shift,
         stage_label = stage_labels[Stage], fill_col = stage_cols[Stage]) %>%
  select(-shift)
x_min_plot <- min(sector_dat$xmin) - stage_gap / 2
x_max_plot <- max(sector_dat$xmax) + stage_gap / 2
axis_x <- sector_dat$xmin[sector_dat$Stage == "Jointing stage"]
polar_start <- -2 * pi * (axis_x - x_min_plot) / (x_max_plot - x_min_plot)
axis_tick_len <- stage_gap * 0.18

# 刻度小数位只影响显示，避免REC、PRO等小数指标被显示成多个0。
tick_digits <- function(step) {
  for (d in 0:8) if (abs(step - round(step, d)) < abs(step) * 1e-7) return(d)
  8L
}

# 4. 一次构建1个指标的完整径向图 ------------------------------
make_one_plot <- function(metric) {
  sum_dat <- sum_dat_all %>% filter(Metric == metric) %>%
    mutate(Stage = as.character(Stage), PlotGroup = as.character(PlotGroup)) %>%
    left_join(pos_dat, by = c("Stage", "PlotGroup")) %>%
    mutate(fill_col = if_else(Location == "UP", "white",
                              unname(fert_cols[as.character(Fertilization)])))
  point_dat <- raw_dat %>%
    mutate(Value = .data[[metric]]) %>%
    left_join(pos_dat, by = c("Stage", "PlotGroup"))
  if (anyNA(sum_dat$x_pos) || anyNA(point_dat$x_pos)) stop("径向位置匹配失败。")

  # 最大原始值仅用于防止点/字母遮挡，不重新统计均值、SD或显著性。
  raw_top <- point_dat %>% group_by(Stage, PlotGroup) %>%
    summarise(raw_top = max(Value), .groups = "drop")
  sum_dat <- sum_dat %>% left_join(raw_top, by = c("Stage", "PlotGroup"))
  data_y_max <- max(c(point_dat$Value, sum_dat$mean + sum_dat$sd))
  if (data_y_max <= 0) stop(metric, "没有可用的正值径向范围。")
  y_axis_max <- unname(axis_max[metric])
  if (is.na(y_axis_max)) y_axis_max <- max(pretty(c(0, data_y_max * 1.10), n = 5))
  y_axis_step <- unname(axis_step[metric])
  if (is.na(y_axis_step)) y_axis_step <- diff(pretty(c(0, y_axis_max), n = 5))[1]
  if (!is.finite(y_axis_max) || !is.finite(y_axis_step) ||
      y_axis_step <= 0 || y_axis_max < data_y_max) {
    stop(metric, "的Y轴上限过小或步长无效；必须包含全部原始点及Mean+SD。")
  }
  axis_breaks <- seq(0, y_axis_max, by = y_axis_step)
  y_grid_breaks <- axis_breaks[axis_breaks > 0 & axis_breaks < y_axis_max]
  digits <- unname(axis_digits[metric])
  if (is.na(digits)) digits <- tick_digits(y_axis_step)
  inner_hole <- y_axis_max * 0.42
  stage_ring_inner <- y_axis_max * 1.08
  stage_ring_outer <- y_axis_max * 1.20
  stage_label_y <- (stage_ring_inner + stage_ring_outer) / 2
  sig_offset <- y_axis_max * 0.06
  sum_dat <- sum_dat %>% mutate(sig_y = pmax(mean + sd, raw_top) + sig_offset)
  axis_tick_dat <- tibble(
    x = axis_x, xend = axis_x + axis_tick_len,
    y = axis_breaks, yend = axis_breaks,
    label = formatC(axis_breaks, format = "f", digits = digits),
    label_x = axis_x - axis_tick_len * 1.2
  )
  stage_text_dat <- bind_rows(lapply(seq_len(nrow(sector_dat)), function(i) {
    z <- sector_dat[i, ]
    inset <- 0.08 * (z$xmax - z$xmin)
    tibble(Stage = z$Stage, stage_label = z$stage_label,
            x = c(z$xmin + inset, z$xmax - inset), y = stage_label_y)
  }))

  ggplot() +
    geom_rect(data = sector_dat,
              aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = stage_ring_outer,
                  fill = fill_col), color = NA, alpha = 0.25,
              inherit.aes = FALSE, show.legend = FALSE) +
    geom_hline(yintercept = y_grid_breaks, color = "grey65",
               linetype = "dashed", linewidth = 0.45) +
    geom_segment(data = axis_tick_dat,
                 aes(x = x, xend = xend, y = y, yend = yend),
                 color = "black", linewidth = 0.65, inherit.aes = FALSE) +
    geom_text(data = axis_tick_dat, aes(x = label_x, y = y, label = label),
              family = "Arial", fontface = "bold", size = 3.2,
              hjust = 1, vjust = 0.5, inherit.aes = FALSE) +
    geom_col(data = sum_dat,
             aes(x = x_pos, y = mean, fill = fill_col, color = Fertilization),
             width = bar_width, linewidth = 0.9, show.legend = FALSE) +
    # 新增空心原始点：只在角度方向错开，height=0保留真实观测值。
    geom_point(data = point_dat, aes(x = x_pos, y = Value),
               position = position_jitter(width = point_jitter_width,
                                           height = 0, seed = point_seed),
               shape = 21, fill = "white", color = "#757575",
               size = point_size, stroke = point_stroke, alpha = point_alpha,
               show.legend = FALSE) +
    geom_errorbar(data = sum_dat,
                  aes(x = x_pos, ymin = pmax(mean - sd, 0), ymax = mean + sd),
                  width = bar_width * 0.35, linewidth = 0.75, color = "black") +
    geom_text(data = sum_dat, aes(x = x_pos, y = sig_y, label = groups),
              angle = 0, hjust = 0.5, vjust = 0.5, size = 3.2,
              family = "Arial", fontface = "bold") +
    geom_rect(data = sector_dat,
              aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = stage_ring_inner),
              fill = NA, color = "black", linewidth = 0.7,
              inherit.aes = FALSE, show.legend = FALSE) +
    geom_rect(data = sector_dat,
              aes(xmin = xmin, xmax = xmax, ymin = stage_ring_inner,
                  ymax = stage_ring_outer, fill = fill_col),
              color = "black", linewidth = 0.7, alpha = 0.75,
              inherit.aes = FALSE, show.legend = FALSE) +
    geomtextpath::geom_textpath(
      data = stage_text_dat,
      aes(x = x, y = y, group = Stage, label = stage_label),
      size = 4.0, family = "Arial", fontface = "bold", hjust = 0.5, vjust = 0.5,
      text_only = TRUE, upright = TRUE, inherit.aes = FALSE, show.legend = FALSE
    ) +
    scale_x_continuous(limits = c(x_min_plot, x_max_plot), expand = c(0, 0)) +
    scale_y_continuous(limits = c(-inner_hole, stage_ring_outer * 1.05),
                       breaks = y_grid_breaks, expand = c(0, 0)) +
    scale_color_manual(values = fert_cols, guide = "none") +
    scale_fill_identity() +
    coord_polar(start = polar_start, direction = 1, clip = "off") +
    labs(x = NULL, y = NULL, title = expression()) +
    theme_void(base_size = 14, base_family = "Arial") +
    theme(text = element_text(family = "Arial"),
          plot.title = element_text(hjust = 0.5, size = 18, face = "bold",
                                    margin = margin(b = 10)),
          plot.margin = margin(20, 20, 20, 20))
}

# 5. 分别显示/导出，不拼接 -----------------------------------
save_one_plot <- function(p, filename) {
  grDevices::cairo_pdf(paste0(filename, ".pdf"), width = 8.5, height = 8.5,
                       family = "Arial")
  tryCatch(print(p), finally = grDevices::dev.off())
  svglite::svglite(paste0(filename, ".svg"), width = 8.5, height = 8.5)
  tryCatch(print(p), finally = grDevices::dev.off())
  ragg::agg_png(paste0(filename, ".png"), width = 8.5, height = 8.5,
                units = "in", res = 600)
  tryCatch(print(p), finally = grDevices::dev.off())
}
if (export_files) dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
plots <- setNames(vector("list", length(metrics_to_plot)), metrics_to_plot)
for (i in seq_along(metrics_to_plot)) {
  metric <- metrics_to_plot[i]
  p <- make_one_plot(metric)
  plots[[metric]] <- p
  if (show_plots) print(p)
  if (export_files) {
    safe_name <- str_replace_all(metric, "[^[:alnum:]_.-]+", "_")
    out_base <- file.path(output_dir, paste0(sprintf("%02d_", i), safe_name,
                                             "_三生育期径向单图"))
    save_one_plot(p, out_base)
    message("已分别导出：", metric)
  }
}
# 单张调用也可以：print(plots[["POD (U/g FW)"]])
