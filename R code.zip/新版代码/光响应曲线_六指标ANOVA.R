# 光响应曲线 sheet1：六指标三因素 ANOVA、阶段内 Tukey、开花期 FS 单因素 ANOVA
# 运行前提：每条记录代表独立试验单元；若同一光伏行内的样本相关，应改用层级/混合模型。

# 可在命令行传入 CSV 路径用于复核；通常直接读取下方 Excel 文件。
args <- commandArgs(trailingOnly = TRUE)
input_file <- if (length(args)) args[1] else
  "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/光响应/光合数据计算/光响应曲线.xlsx"

if (grepl("\\.csv$", input_file, ignore.case = TRUE)) {
  raw <- read.csv(input_file, fileEncoding = "UTF-8-BOM", check.names = FALSE)
} else {
  if (!requireNamespace("readxl", quietly = TRUE)) {
    stop("请先安装 readxl：install.packages('readxl')")
  }
  raw <- as.data.frame(readxl::read_excel(input_file, sheet = "sheet1"))
}

metrics <- c("AQY", "Rd", "LCP", "LSP", "Pnmax", "PNUEmax")
needed <- c("Stage", "Location", "Fertilization", metrics)
if (!all(needed %in% names(raw))) {
  stop("缺少列：", paste(setdiff(needed, names(raw)), collapse = ", "))
}
if (anyNA(raw[needed])) stop("所需列存在缺失值，请先核查原表。")
if (!all(c("Block", "RowID") %in% names(raw))) {
  warning("原表没有 Block/RowID，无法核实同一光伏行内样本是否独立；ANOVA 推断须以独立微区为前提。")
}
if (!all(vapply(raw[metrics], is.numeric, logical(1)))) {
  stop("六个指标必须是数值列；请检查 Excel 中的文本或单位。")
}
if (any(!is.finite(as.matrix(raw[metrics])))) stop("指标存在无穷值或非数值。")

stages <- c("Erecting stage", "Jointing stage", "Anthesis stage")
locations <- c("BP", "UP")
fertilizations <- c("CK", "F", "MF", "OF")
groups8 <- c("BP_CK", "UP_CK", "BP_F", "UP_F",
             "BP_MF", "UP_MF", "BP_OF", "UP_OF")
groups9 <- c(groups8, "FS_FS")

raw$Stage <- as.character(raw$Stage)
raw$Location <- as.character(raw$Location)
raw$Fertilization <- as.character(raw$Fertilization)
main_id <- raw$Stage %in% stages & raw$Location %in% locations &
  raw$Fertilization %in% fertilizations
fs_id <- raw$Stage == "Anthesis stage" & raw$Location == "FS" &
  raw$Fertilization == "FS"
if (!all(main_id | fs_id)) stop("发现预期 24+1 个处理组合以外的记录，请核查。")
main <- raw[main_id, , drop = FALSE]
fs <- raw[fs_id, , drop = FALSE]
if (nrow(fs) == 0) stop("开花期 FS 组不存在，不能执行指定的补充检验。")

main$Stage <- factor(main$Stage, levels = stages)
main$Location <- factor(main$Location, levels = locations)
main$Fertilization <- factor(main$Fertilization, levels = fertilizations)
main$Treatment <- factor(paste(main$Location, main$Fertilization, sep = "_"),
                         levels = groups8)
cell_n <- xtabs(~ Stage + Location + Fertilization, data = main)
if (any(cell_n == 0) || length(unique(as.vector(cell_n))) != 1) {
  stop("主模型存在空组合或重复数不相等；本代码的平衡设计 ANOVA 不适用。")
}
if (any(as.vector(cell_n) < 2) || nrow(fs) < 2) {
  stop("至少一个处理组合少于 2 条记录，无法计算组内标准差。")
}
message("主模型每组合 n = ", unique(as.vector(cell_n)),
        "；FS n = ", nrow(fs), "。请确认这些记录是独立试验单元。")

# 1. 所有 25 个组合的算术均值、样本标准差和 n（原始值，不是边际均值）
all_data <- rbind(main[needed], fs[needed])
group_id <- paste(all_data$Stage, all_data$Location,
                  all_data$Fertilization, sep = "|")
summary_list <- lapply(split(seq_len(nrow(all_data)), group_id), function(i) {
  z <- all_data[i, , drop = FALSE]
  out <- data.frame(Stage = z$Stage[1], Location = z$Location[1],
                    Fertilization = z$Fertilization[1], n = nrow(z))
  for (v in metrics) {
    out[[paste0(v, "_mean")]] <- mean(z[[v]])
    out[[paste0(v, "_SD")]] <- sd(z[[v]])
  }
  out
})
summary_table <- do.call(rbind, summary_list)
rownames(summary_table) <- NULL
summary_table <- summary_table[order(match(summary_table$Stage, stages),
                                     match(summary_table$Location,
                                           c(locations, "FS")),
                                     match(summary_table$Fertilization,
                                           c(fertilizations, "FS"))), ]
cat("\n=== 各处理原始均值、SD、n ===\n")
print(summary_table, row.names = FALSE, digits = 6)

# 2. 三因素固定效应 ANOVA。主数据为完整平衡设计，顺序平方和与
#    其他常见平方和类型对各正交效应的检验一致；不平衡时上方已停止。
#    阶段内 Tukey 使用该三因素模型的共同残差均方和自由度。
threeway_rows <- list()
tukey_stage_rows <- list()
stage_letters_rows <- list()
diagnostic_rows <- list()
if (!requireNamespace("multcompView", quietly = TRUE)) {
  stop("生成 Tukey 显著性字母需要 multcompView；请先运行 install.packages('multcompView')。")
}

for (v in metrics) {
  d <- main[c("Stage", "Location", "Fertilization", "Treatment", v)]
  names(d)[5] <- "Y"
  d$Cell <- interaction(d$Stage, d$Treatment, drop = TRUE)
  fit <- aov(Y ~ Stage * Location * Fertilization, data = d)
  a <- summary(fit)[[1]]
  terms <- rownames(a)[trimws(rownames(a)) != "Residuals"]
  threeway_rows[[v]] <- data.frame(
    Metric = v, Term = trimws(terms), df1 = a[terms, "Df"],
    df2 = df.residual(fit), F = a[terms, "F value"],
    p = a[terms, "Pr(>F)"], row.names = NULL
  )

  mse <- deviance(fit) / df.residual(fit)
  n_cell <- unique(as.vector(cell_n))
  for (st in stages) {
    means <- tapply(d$Y[d$Stage == st], d$Treatment[d$Stage == st], mean)
    pairs <- combn(groups8, 2, simplify = FALSE)
    z <- do.call(rbind, lapply(pairs, function(g) {
      difference <- unname(means[g[1]] - means[g[2]])
      se_q <- sqrt(mse / n_cell)
      q <- abs(difference) / se_q
      q_crit <- qtukey(0.95, nmeans = 8, df = df.residual(fit))
      data.frame(Metric = v, Stage = st,
                 Contrast = paste(g[1], "-", g[2]),
                 Difference = difference,
                 Lower95 = difference - q_crit * se_q,
                 Upper95 = difference + q_crit * se_q,
                 p_Tukey = ptukey(q, nmeans = 8,
                                  df = df.residual(fit), lower.tail = FALSE))
    }))
    tukey_stage_rows[[paste(v, st)]] <- z

    # 直接使用上方同一三因素模型、同一阶段 8 组 Tukey 校正后的 p 值生成字母。
    # 每个指标、每个生育期独立标记；按组均值从大到小排列，最大值从 a 开始。
    d_stage <- droplevels(d[d$Stage == st, c("Y", "Treatment"), drop = FALSE])
    p_stage <- z$p_Tukey
    names(p_stage) <- gsub(" - ", "-", z$Contrast, fixed = TRUE)
    cld_stage <- multcompView::multcompLetters2(
      Y ~ Treatment, p_stage, d_stage
    )$Letters
    mean_stage <- tapply(d_stage$Y, d_stage$Treatment, mean)
    sd_stage <- tapply(d_stage$Y, d_stage$Treatment, sd)
    n_stage <- table(d_stage$Treatment)
    letter_tbl <- data.frame(
      Metric = v, Stage = st,
      Treatment = names(mean_stage),
      n = as.integer(n_stage[names(mean_stage)]),
      Mean = as.numeric(mean_stage),
      SD = as.numeric(sd_stage[names(mean_stage)]),
      Letter = unname(cld_stage[names(mean_stage)]),
      row.names = NULL
    )
    letter_tbl <- letter_tbl[order(-letter_tbl$Mean), , drop = FALSE]
    if (!grepl("a", letter_tbl$Letter[1], fixed = TRUE)) {
      stop(v, " / ", st, " 的字母顺序未从最高均值 a 开始，请核查。")
    }
    stage_letters_rows[[paste(v, st)]] <- letter_tbl
  }

  diagnostic_rows[[paste(v, "threeway")]] <- data.frame(
    Metric = v, Model = "threeway",
    Shapiro_p = shapiro.test(residuals(fit))$p.value,
    Fligner_p = fligner.test(Y ~ Cell, data = d)$p.value
  )
}
threeway_anova <- do.call(rbind, threeway_rows)
rownames(threeway_anova) <- NULL
threeway_anova$p_Holm6 <- NA_real_
for (term in unique(threeway_anova$Term)) {
  k <- which(threeway_anova$Term == term)
  threeway_anova$p_Holm6[k] <- p.adjust(threeway_anova$p[k], "holm")
}
tukey_by_stage <- do.call(rbind, tukey_stage_rows)
rownames(tukey_by_stage) <- NULL
stage_letters <- do.call(rbind, stage_letters_rows)
rownames(stage_letters) <- NULL

# 3. 开花期：8 个 BP/UP×施肥组合加 FS，共 9 组的单因素 ANOVA。
anthesis <- raw[raw$Stage == "Anthesis stage", needed, drop = FALSE]
anthesis$Treatment <- factor(paste(anthesis$Location,
                                   anthesis$Fertilization, sep = "_"),
                             levels = groups9)
if (anyNA(anthesis$Treatment) || any(table(anthesis$Treatment) == 0)) {
  stop("开花期 9 组不完整，请核查。")
}
fs_anova_rows <- list()
tukey_fs_rows <- list()
letters_fs_rows <- list()
for (v in metrics) {
  d <- anthesis[c("Treatment", v)]
  names(d)[2] <- "Y"
  fit <- aov(Y ~ Treatment, data = d)
  a <- summary(fit)[[1]]
  fs_anova_rows[[v]] <- data.frame(
    Metric = v, df1 = a["Treatment", "Df"],
    df2 = a["Residuals", "Df"], F = a["Treatment", "F value"],
    p = a["Treatment", "Pr(>F)"]
  )
  tukey_result <- TukeyHSD(fit, "Treatment")$Treatment
  z <- as.data.frame(tukey_result)
  tukey_fs_rows[[v]] <- data.frame(
    Metric = v, Contrast = rownames(z), Difference = z$diff,
    Lower95 = z$lwr, Upper95 = z$upr, p_Tukey = z$`p adj`,
    row.names = NULL
  )

  # 与上方完全相同的 Tukey 校正 p 值生成紧凑字母；
  # multcompLetters2 先按均值降序排列，使最高均值组从 a 开始。
  cld <- multcompView::multcompLetters2(
    Y ~ Treatment, tukey_result[, "p adj"], d
  )$Letters
  group_mean <- tapply(d$Y, d$Treatment, mean)
  group_sd <- tapply(d$Y, d$Treatment, sd)
  group_n <- table(d$Treatment)
  letters_fs_rows[[v]] <- data.frame(
    Metric = v,
    Treatment = names(group_mean),
    n = as.integer(group_n[names(group_mean)]),
    Mean = as.numeric(group_mean),
    SD = as.numeric(group_sd[names(group_mean)]),
    Letter = unname(cld[names(group_mean)]),
    row.names = NULL
  )
  letters_fs_rows[[v]] <- letters_fs_rows[[v]][
    order(-letters_fs_rows[[v]]$Mean), , drop = FALSE
  ]
  if (!grepl("a", letters_fs_rows[[v]]$Letter[1], fixed = TRUE)) {
    stop(v, " 的字母顺序未从最高均值 a 开始，请核查。")
  }
  diagnostic_rows[[paste(v, "anthesis")]] <- data.frame(
    Metric = v, Model = "anthesis_9groups",
    Shapiro_p = shapiro.test(residuals(fit))$p.value,
    Fligner_p = fligner.test(Y ~ Treatment, data = d)$p.value
  )
}
fs_anova <- do.call(rbind, fs_anova_rows)
rownames(fs_anova) <- NULL
fs_anova$p_Holm6 <- p.adjust(fs_anova$p, "holm")
tukey_fs <- do.call(rbind, tukey_fs_rows)
rownames(tukey_fs) <- NULL
anthesis_letters <- do.call(rbind, letters_fs_rows)
rownames(anthesis_letters) <- NULL
diagnostics <- do.call(rbind, diagnostic_rows)
rownames(diagnostics) <- NULL

cat("\n=== 三因素 ANOVA：原始 p 与同一效应跨六指标 Holm p ===\n")
print(threeway_anova, row.names = FALSE, digits = 5)
cat("\n=== 三个生育期各 8 组 Tukey 显著性字母（各指标、各阶段均值降序） ===\n")
print(stage_letters, row.names = FALSE, digits = 5)
cat("\n=== 开花期 9 组单因素 ANOVA ===\n")
print(fs_anova, row.names = FALSE, digits = 5)
cat("\n=== 开花期 9 组 Tukey 显著性字母（各指标均值降序） ===\n")
print(anthesis_letters, row.names = FALSE, digits = 5)
cat("\n=== 残差正态性与组间离散程度诊断（小样本时仅作辅助判断） ===\n")
print(diagnostics, row.names = FALSE, digits = 5)
cat("\n三个生育期的显著性字母保存在 stage_letters（每阶段 8 组）；\n",
    "阶段内 Tukey 结果保存在 tukey_by_stage（每阶段 8 组）；\n",
    "开花期含 FS 的 Tukey 结果保存在 tukey_fs（9 组）。\n", sep = "")
cat("可用 print(tukey_by_stage) 或 print(tukey_fs) 查看全部差异、95% CI 与校正 p 值。\n")

# 4. 将全部结果导出至一个 Excel 文件；原始 sheet1 不作修改。
if (!requireNamespace("writexl", quietly = TRUE)) {
  stop("导出 Excel 需要 writexl；请先运行 install.packages('writexl')。")
}
output_file <- file.path(dirname(input_file), "光响应曲线_六指标完整分析结果.xlsx")
writexl::write_xlsx(
  list(
    Raw_sheet1 = as.data.frame(raw),
    Means_SD = summary_table,
    Three_way_ANOVA = threeway_anova,
    Stage_Tukey = tukey_by_stage,
    Stage_letters = stage_letters,
    Anthesis_ANOVA = fs_anova,
    Anthesis_Tukey = tukey_fs,
    Anthesis_letters = anthesis_letters,
    Diagnostics = diagnostics
  ),
  path = output_file
)
cat("\n全部结果已导出：", output_file, "\n")
