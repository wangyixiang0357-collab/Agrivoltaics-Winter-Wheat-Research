# ============================================================
# 空气温度、相对湿度与 DLI 的分阶段混合线性模型及柱状图
#
# 数据层级：
# - 每一行是一个日期的日均值/日积分；
# - 同一天在 UP、BP、FS 三个位置重复测量；
# - 日期作为随机截距，避免将同一天的三个位置视为完全独立样本。
#
# 固定效应：
#   光伏板位置（Position）× 生育期（Stage）
#
# 生育期划分：
#   S1：截至 2026-03-16（包含 3 月 16 日）
#   S2：2026-03-17 至 2026-04-08
#   S3：2026-04-09 至 2026-04-30
#   S4：2026-05-01 以后
#
# 统计：
# - lmerTest 混合线性模型；
# - 第 III 类平方和，Satterthwaite 自由度；
# - emmeans 估计边际均值；
# - Tukey 校正的处理均值两两比较和显著性字母。
#
# 图形：
# - 空气温度、相对湿度与 DLI 分别生成独立图片，不进行拼接；
# - 柱：原始日尺度数据的均值；
# - 误差线：标准误（SE = SD / sqrt(n)，n 为日期数）；
# - 字母：混合模型估计边际均值在各生育期内的位置 Tukey 分组；
# - 组间间隔为柱宽的 25%，组内间隔为柱宽的 5%；
# - 温度和 DLI 均从 0 起始；相对湿度在 5%–35% 处断轴；
# - X 轴不显示刻度线，三个面板均保留四周轴框。
# ============================================================

required_packages <- c(
  "dplyr", "tidyr", "stringr", "tibble",
  "lme4", "lmerTest", "emmeans", "multcomp", "multcompView",
  "writexl", "ggplot2", "ggbreak",
  "svglite", "ragg"
)

missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  stop(
    "缺少以下 R 包：", paste(missing_packages, collapse = ", "),
    "\n请先运行：install.packages(c(",
    paste(sprintf('"%s"', missing_packages), collapse = ", "),
    "))"
  )
}

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(tibble)
  library(lme4)
  library(lmerTest)
  library(emmeans)
  library(ggplot2)
  library(ggbreak)
})

# 第 III 类平方和需要和对比（sum contrasts）。
options(contrasts = c("contr.sum", "contr.poly"))
emmeans::emm_options(lmer.df = "satterthwaite")

# ---------- 1. 文件路径 ----------
# Windows 中 path.expand("~") 有时会返回 Documents，因此优先使用
# USERPROFILE（例如 C:/Users/用户名）定位桌面。
user_profile <- Sys.getenv("USERPROFILE", unset = "")
if (!nzchar(user_profile)) {
  user_profile <- path.expand("~")
}

data_candidates <- c(
  file.path(
    user_profile,
    "Desktop", "项目区气象数据", "空气温湿度.csv"
  ),
  file.path(
    path.expand("~"),
    "Desktop", "项目区气象数据", "空气温湿度.csv"
  ),
  file.path(
    getwd(),
    "空气温湿度.csv"
  )
)

existing_data_files <- data_candidates[file.exists(data_candidates)]
if (length(existing_data_files) == 0) {
  stop(
    "找不到数据文件“空气温湿度.csv”。已搜索：\n",
    paste(normalizePath(
      data_candidates,
      winslash = "/",
      mustWork = FALSE
    ), collapse = "\n")
  )
}
data_file <- existing_data_files[[1]]

project_dir <- file.path(
  user_profile,
  "Desktop", "光伏农业小麦相关", "2025-2026生长季"
)

output_dir <- file.path(
  project_dir,
  "图", "空气温湿度_DLI_分阶段混合模型"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

result_file <- file.path(
  output_dir,
  "空气温湿度_DLI_分阶段混合模型_Tukey结果.xlsx"
)
model_file <- file.path(
  output_dir,
  "空气温湿度_DLI_混合模型对象.rds"
)
figure_prefixes <- c(
  Air_temperature = file.path(
    output_dir,
    "空气温度_分阶段均值SE_Tukey柱状图"
  ),
  Relative_humidity = file.path(
    output_dir,
    "空气相对湿度_分阶段均值SE_Tukey柱状图"
  ),
  DLI = file.path(
    output_dir,
    "DLI_分阶段均值SE_Tukey柱状图"
  )
)

# ---------- 2. 读取两行表头的日尺度 CSV ----------
raw_data <- read.csv(
  data_file,
  skip = 2,
  header = FALSE,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  na.strings = c("", "NA", "NaN")
)

if (ncol(raw_data) != 11) {
  stop(
    "CSV 应包含 11 列：日期、3 列温度、3 列湿度、",
    "3 列 DLI 和 1 列降雨。当前列数为：", ncol(raw_data)
  )
}

names(raw_data) <- c(
  "Date",
  "Temp_BP", "Temp_UP", "Temp_FS",
  "RH_BP", "RH_UP", "RH_FS",
  "DLI_BP", "DLI_UP", "DLI_FS",
  "Rainfall"
)

raw_data <- raw_data %>%
  mutate(
    Date = as.Date(Date, format = "%Y/%m/%d"),
    across(-Date, ~ suppressWarnings(as.numeric(.x)))
  ) %>%
  arrange(Date)

if (anyNA(raw_data$Date)) {
  stop("存在无法按 YYYY/MM/DD 解析的日期。")
}

if (anyDuplicated(raw_data$Date)) {
  duplicated_dates <- unique(raw_data$Date[duplicated(raw_data$Date)])
  stop(
    "日期存在重复记录：",
    paste(duplicated_dates, collapse = ", "),
    "。请先确认日均值的计算方式。"
  )
}

if (nrow(raw_data) < 4) {
  stop("有效日期数不足，无法拟合四阶段混合模型。")
}

# ---------- 3. 转成长数据并划分生育期 ----------
# 边界日期均计入其前一个阶段，因此不会遗漏 3 月 16 日或 4 月 30 日。
stage1_end <- as.Date("2026-03-16")
stage2_end <- as.Date("2026-04-08")
stage3_end <- as.Date("2026-04-30")

stage_levels <- c(
  "≤16 Mar",
  "17 Mar–8 Apr",
  "9–30 Apr",
  ">30 Apr"
)
position_levels <- c("UP", "BP", "FS")
metric_levels <- c(
  "Air temperature (°C)",
  "Relative humidity (%)",
  "DLI (mol m^-2 d^-1)"
)

metric_labels <- c(
  Temp = "Air temperature (°C)",
  RH = "Relative humidity (%)",
  DLI = "DLI (mol m^-2 d^-1)"
)

long_all <- raw_data %>%
  select(
    Date,
    Temp_UP, Temp_BP, Temp_FS,
    RH_UP, RH_BP, RH_FS,
    DLI_UP, DLI_BP, DLI_FS
  ) %>%
  pivot_longer(
    cols = -Date,
    names_to = c("Metric_code", "Position"),
    names_pattern = "^(Temp|RH|DLI)_(UP|BP|FS)$",
    values_to = "Value"
  ) %>%
  mutate(
    Stage = case_when(
      Date <= stage1_end ~ "≤16 Mar",
      Date <= stage2_end ~ "17 Mar–8 Apr",
      Date <= stage3_end ~ "9–30 Apr",
      TRUE ~ ">30 Apr"
    ),
    Stage = factor(Stage, levels = stage_levels),
    Position = factor(Position, levels = position_levels),
    Metric = factor(
      unname(metric_labels[Metric_code]),
      levels = metric_levels
    ),
    Date_ID = factor(Date),
    Treatment = interaction(
      Stage, Position,
      sep = " | ",
      lex.order = TRUE,
      drop = TRUE
    )
  ) %>%
  arrange(Metric, Stage, Date, Position)

missing_audit <- long_all %>%
  group_by(Metric, Stage, Position) %>%
  summarise(
    Total_rows = n(),
    Missing_rows = sum(!is.finite(Value)),
    Valid_rows = sum(is.finite(Value)),
    .groups = "drop"
  )

analysis_data <- long_all %>%
  filter(is.finite(Value))

stage_date_counts <- analysis_data %>%
  distinct(Stage, Date) %>%
  count(Stage, name = "Number_of_dates") %>%
  tidyr::complete(
    Stage = factor(stage_levels, levels = stage_levels),
    fill = list(Number_of_dates = 0L)
  ) %>%
  arrange(Stage)

cell_counts <- analysis_data %>%
  count(Metric, Stage, Position, name = "n") %>%
  tidyr::complete(
    Metric = factor(metric_levels, levels = metric_levels),
    Stage = factor(stage_levels, levels = stage_levels),
    Position = factor(position_levels, levels = position_levels),
    fill = list(n = 0L)
  )

if (any(cell_counts$n == 0)) {
  empty_cells <- cell_counts %>%
    filter(n == 0) %>%
    transmute(Cell = paste(Metric, Stage, Position, sep = " | ")) %>%
    pull(Cell)
  stop(
    "以下“指标 × 生育期 × 位置”组合没有有效数据：\n",
    paste(empty_cells, collapse = "\n")
  )
}

# ---------- 4. 描述统计：均值、标准差和标准误 ----------
descriptive_summary <- analysis_data %>%
  group_by(Metric, Stage, Position) %>%
  summarise(
    n_dates = n_distinct(Date),
    n_values = n(),
    Mean = mean(Value),
    SD = sd(Value),
    SE = SD / sqrt(n_dates),
    .groups = "drop"
  ) %>%
  mutate(
    `Mean ± SE` = sprintf("%.2f ± %.2f", Mean, SE)
  ) %>%
  arrange(Metric, Stage, Position)

# ---------- 5. 混合线性模型、Type III 检验及 Tukey 比较 ----------
significance_code <- function(p) {
  case_when(
    is.na(p) ~ "",
    p < 0.001 ~ "***",
    p < 0.01 ~ "**",
    p < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

analyse_one_metric <- function(metric_name, data_long) {
  dat_metric <- data_long %>%
    filter(Metric == metric_name) %>%
    mutate(
      Stage = factor(Stage, levels = stage_levels),
      Position = factor(Position, levels = position_levels),
      Date_ID = factor(Date_ID)
    ) %>%
    droplevels()

  model <- lmerTest::lmer(
    Value ~ Position * Stage + (1 | Date_ID),
    data = dat_metric,
    REML = TRUE,
    na.action = na.exclude,
    control = lme4::lmerControl(
      optimizer = "bobyqa",
      optCtrl = list(maxfun = 200000)
    )
  )

  # 固定效应与交互作用：第 III 类平方和。
  type3_raw <- as.data.frame(
    anova(
      model,
      type = 3,
      ddf = "Satterthwaite"
    )
  )
  type3_raw$Term <- rownames(type3_raw)
  rownames(type3_raw) <- NULL

  type3_table <- tibble(
    Metric = metric_name,
    Term = type3_raw$Term,
    `Type III Sum Sq` = type3_raw[["Sum Sq"]],
    `Mean Sq` = type3_raw[["Mean Sq"]],
    NumDF = type3_raw[["NumDF"]],
    DenDF = type3_raw[["DenDF"]],
    `F value` = type3_raw[["F value"]],
    `Pr(>F)` = type3_raw[["Pr(>F)"]]
  ) %>%
    mutate(Significance = significance_code(`Pr(>F)`))

  fixed_coefficients <- as.data.frame(coef(summary(model)))
  fixed_coefficients$Coefficient <- rownames(fixed_coefficients)
  rownames(fixed_coefficients) <- NULL
  fixed_coefficients <- as_tibble(fixed_coefficients) %>%
    mutate(Metric = metric_name, .before = 1)

  # 各生育期内比较三个位置；用于柱状图显著性字母。
  emm_position_by_stage <- emmeans::emmeans(
    model,
    specs = ~ Position | Stage
  )
  tukey_position_by_stage <- as.data.frame(
    emmeans::contrast(
      emm_position_by_stage,
      method = "pairwise",
      adjust = "tukey"
    )
  ) %>%
    as_tibble() %>%
    mutate(Metric = metric_name, .before = 1)

  cld_position_by_stage <- as.data.frame(
    multcomp::cld(
      emm_position_by_stage,
      adjust = "tukey",
      Letters = letters,
      sort = TRUE,
      reversed = TRUE
    )
  ) %>%
    as_tibble() %>%
    mutate(
      Metric = metric_name,
      Tukey_group = str_squish(.group),
      .before = 1
    ) %>%
    select(-.group)

  # 各位置内比较四个生育期，用于解释交互作用后的简单效应。
  emm_stage_by_position <- emmeans::emmeans(
    model,
    specs = ~ Stage | Position
  )
  tukey_stage_by_position <- as.data.frame(
    emmeans::contrast(
      emm_stage_by_position,
      method = "pairwise",
      adjust = "tukey"
    )
  ) %>%
    as_tibble() %>%
    mutate(Metric = metric_name, .before = 1)

  # 对全部 12 个“位置 × 生育期”处理均值进行统一 Tukey 比较。
  emm_all_treatments <- emmeans::emmeans(
    model,
    specs = ~ Position * Stage
  )
  all_emmeans <- as.data.frame(emm_all_treatments) %>%
    as_tibble() %>%
    mutate(Metric = metric_name, .before = 1)

  tukey_all_treatments <- as.data.frame(
    emmeans::contrast(
      emm_all_treatments,
      method = "pairwise",
      adjust = "tukey"
    )
  ) %>%
    as_tibble() %>%
    mutate(Metric = metric_name, .before = 1)

  cld_all_treatments <- as.data.frame(
    multcomp::cld(
      emm_all_treatments,
      adjust = "tukey",
      Letters = letters,
      sort = FALSE
    )
  ) %>%
    as_tibble() %>%
    mutate(
      Metric = metric_name,
      Tukey_group = str_squish(.group),
      .before = 1
    ) %>%
    select(-.group)

  variance_components <- as.data.frame(lme4::VarCorr(model))
  date_variance <- variance_components %>%
    filter(grp == "Date_ID") %>%
    pull(vcov)
  if (length(date_variance) == 0) {
    date_variance <- NA_real_
  }

  diagnostics <- tibble(
    Metric = metric_name,
    n_observations = stats::nobs(model),
    n_dates = n_distinct(dat_metric$Date),
    n_positions = n_distinct(dat_metric$Position),
    n_stages = n_distinct(dat_metric$Stage),
    Date_random_intercept_variance = date_variance[[1]],
    Residual_variance = sigma(model)^2,
    Singular_fit = lme4::isSingular(model, tol = 1e-4),
    REML_logLik = as.numeric(logLik(model))
  )

  list(
    model = model,
    type3 = type3_table,
    coefficients = fixed_coefficients,
    emmeans = all_emmeans,
    tukey_position_by_stage = tukey_position_by_stage,
    cld_position_by_stage = cld_position_by_stage,
    tukey_stage_by_position = tukey_stage_by_position,
    tukey_all_treatments = tukey_all_treatments,
    cld_all_treatments = cld_all_treatments,
    diagnostics = diagnostics
  )
}

analysis_results <- setNames(
  lapply(
    metric_levels,
    analyse_one_metric,
    data_long = analysis_data
  ),
  metric_levels
)

bind_component <- function(component_name) {
  bind_rows(lapply(
    analysis_results,
    function(result) result[[component_name]]
  ))
}

type3_fixed_effects <- bind_component("type3")
fixed_coefficients <- bind_component("coefficients")
all_emmeans <- bind_component("emmeans")
tukey_position_by_stage <- bind_component("tukey_position_by_stage")
cld_position_by_stage <- bind_component("cld_position_by_stage")
tukey_stage_by_position <- bind_component("tukey_stage_by_position")
tukey_all_treatments <- bind_component("tukey_all_treatments")
cld_all_treatments <- bind_component("cld_all_treatments")
model_diagnostics <- bind_component("diagnostics")

model_objects <- lapply(analysis_results, function(result) result$model)
saveRDS(model_objects, model_file)

# ---------- 6. 柱状图数据与精确横坐标 ----------
position_colors <- c(
  UP = "#4477AA",
  BP = "#6FA8DC",
  FS = "#F0E442"
)

plot_data <- descriptive_summary %>%
  left_join(
    cld_position_by_stage %>%
      select(Metric, Stage, Position, Tukey_group),
    by = c("Metric", "Stage", "Position")
  )

# 以柱宽为 1 个单位：
# - 同一生育期内相邻柱之间净空 = 5%；
# - 相邻生育期组之间净空 = 25%。
bar_width <- 1
within_group_gap_pct <- 0.05
between_stage_gap_pct <- 0.25
within_group_gap <- bar_width * within_group_gap_pct
between_stage_gap <- bar_width * between_stage_gap_pct

bars_per_stage <- length(position_levels)
stage_span <- bars_per_stage * bar_width +
  (bars_per_stage - 1) * within_group_gap

stage_layout <- tibble(
  Stage = factor(stage_levels, levels = stage_levels),
  stage_index = seq_along(stage_levels)
) %>%
  mutate(
    x_start = (stage_index - 1) * (stage_span + between_stage_gap),
    x_end = x_start + stage_span,
    x_center = (x_start + x_end) / 2
  )

position_layout <- tidyr::expand_grid(
  Stage = factor(stage_levels, levels = stage_levels),
  Position = factor(position_levels, levels = position_levels)
) %>%
  arrange(Stage, Position) %>%
  left_join(
    stage_layout %>% select(Stage, x_start),
    by = "Stage"
  ) %>%
  group_by(Stage) %>%
  mutate(
    position_index = row_number(),
    x = x_start + bar_width / 2 +
      (position_index - 1) * (bar_width + within_group_gap)
  ) %>%
  ungroup()

stage_separators <- stage_layout %>%
  filter(row_number() < n()) %>%
  transmute(x = x_end + between_stage_gap / 2)

metric_label_padding <- plot_data %>%
  group_by(Metric) %>%
  summarise(
    y_min = min(Mean - SE, na.rm = TRUE),
    y_max = max(Mean + SE, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    y_span = y_max - y_min,
    label_padding = if_else(
      is.finite(y_span) & y_span > 0,
      y_span * 0.060,
      pmax(abs(y_max), 1) * 0.060
    )
  )

plot_data <- plot_data %>%
  left_join(
    position_layout %>% select(Stage, Position, x),
    by = c("Stage", "Position")
  ) %>%
  left_join(
    metric_label_padding %>% select(Metric, label_padding),
    by = "Metric"
  ) %>%
  mutate(
    Label_y = Mean + SE + label_padding,
    Within_group_gap_pct = within_group_gap_pct * 100,
    Between_stage_gap_pct = between_stage_gap_pct * 100
  )

stage_axis_labels <- c(
  "≤16 Mar" = "≤16 Mar",
  "17 Mar–8 Apr" = "17 Mar–\n8 Apr",
  "9–30 Apr" = "9–30 Apr",
  ">30 Apr" = ">30 Apr"
)

# ---------- 7. 绘制均值 ± SE 柱状图 ----------
# 三项指标分别绘制并分别导出，不进行拼接。
make_metric_bar_plot <- function(
  metric_name,
  y_breaks,
  y_limits,
  y_tick_labels = y_breaks
) {
  metric_plot_data <- plot_data %>%
    filter(Metric == metric_name)

  ggplot(
    metric_plot_data,
    aes(x = x, y = Mean, fill = Position)
  ) +
    geom_vline(
      data = stage_separators,
      aes(xintercept = x),
      inherit.aes = FALSE,
      colour = "#B3B3B3",
      linewidth = 0.30,
      linetype = "dashed"
    ) +
    geom_col(
      width = bar_width,
      colour = "black",
      linewidth = 0.30
    ) +
    geom_errorbar(
      aes(ymin = Mean - SE, ymax = Mean + SE),
      width = bar_width * 0.45,
      linewidth = 0.35
    ) +
    geom_text(
      aes(y = Label_y, label = Tukey_group),
      vjust = 0,
      size = 2.35,
      family = "Arial",
      na.rm = TRUE
    ) +
    scale_fill_manual(
      values = position_colors,
      breaks = position_levels,
      drop = FALSE
    ) +
    scale_x_continuous(
      breaks = stage_layout$x_center,
      labels = unname(
        stage_axis_labels[as.character(stage_layout$Stage)]
      ),
      expand = expansion(mult = c(0.015, 0.015))
    ) +
    scale_y_continuous(
      breaks = y_breaks,
      labels = y_tick_labels,
      limits = y_limits,
      expand = expansion(mult = c(0, 0))
    ) +
    labs(
      title = metric_name,
      x = "Growth stage",
      y = "Mean ± SE",
      fill = "PV position"
    ) +
    theme_classic(
      base_size = 7,
      base_family = "Arial"
    ) +
    theme(
      # panel.border 同时绘制上、下、左、右四条轴框；
      # axis.line 关闭，避免左轴和下轴与边框重复叠加。
      axis.line = element_blank(),
      panel.border = element_rect(
        fill = NA,
        colour = "black",
        linewidth = 0.35
      ),
      axis.ticks.y = element_line(
        linewidth = 0.35,
        colour = "black"
      ),
      axis.ticks.x = element_blank(),
      axis.ticks.length.x = grid::unit(0, "pt"),
      axis.text.x = element_text(
        size = 6.2,
        lineheight = 0.88
      ),
      axis.text.y = element_text(size = 6.5),
      axis.title = element_text(size = 7),
      plot.title = element_text(
        size = 7,
        face = "bold",
        hjust = 0.5
      ),
      panel.grid = element_blank(),
      legend.position = "top",
      legend.title = element_text(size = 6.8),
      legend.text = element_text(size = 6.5),
      legend.key.size = grid::unit(0.34, "cm"),
      plot.margin = margin(4, 4, 4, 4, unit = "pt")
    )
}

temperature_plot <- make_metric_bar_plot(
  metric_name = metric_labels[["Temp"]],
  y_breaks = c(0, 6, 12, 18, 24, 30),
  y_limits = c(0, 30)
)

relative_humidity_plot <- make_metric_bar_plot(
  metric_name = metric_labels[["RH"]],
  y_breaks = c(0, 40, 60, 80, 100),
  y_tick_labels = paste0(c(0, 40, 60, 80, 100), "%"),
  y_limits = c(0, 100)
) +
  # 仅相对湿度面板删除 5%–35% 的空白区间。
  ggbreak::scale_y_break(
    breaks = c(5, 35),
    scales = "fixed",
    expand = FALSE,
    space = 0.06
  ) +
  # ggbreak 默认可能在右侧重复显示 Y 轴刻度。
  # 删除重复标签与刻度，但 panel.border 仍保留右侧轴框。
  theme(
    axis.text.y.right = element_blank(),
    axis.ticks.y.right = element_blank(),
    axis.title.y.right = element_blank()
  )

# 原要求同时出现“40 刻度”和“终点 32”，两者不能同时显示；
# 此处按明确指定的终点 32，保留 0–32 范围内的有效刻度。
dli_plot <- make_metric_bar_plot(
  metric_name = metric_labels[["DLI"]],
  y_breaks = c(0, 9, 18, 27, 36),
  y_limits = c(0, 36)
)

# 三张独立图片均显示完整图例，便于单独使用。
standalone_legend_theme <- theme(
  legend.position = "top",
  legend.justification = "center",
  legend.box.just = "center",
  legend.box = "horizontal"
)

temperature_plot <- temperature_plot + standalone_legend_theme
relative_humidity_plot <- relative_humidity_plot + standalone_legend_theme
dli_plot <- dli_plot + standalone_legend_theme

# ---------- 8. 导出 SVG、PDF、600 dpi TIFF 和 PNG ----------
# Windows 下若旧文件正在阅读器中打开，目标文件可能被锁定。
# 所有设备先写入临时英文路径，再复制到目标目录；若目标被占用，
# 自动保存为带时间戳的新文件，避免中断后续统计结果的导出。
save_publication_figure <- function(
  plot_object,
  filename_prefix,
  width_mm = 88,
  height_mm = 82,
  dpi = 600
) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4
  export_stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")

  close_new_device <- function(start_device) {
    current_device <- grDevices::dev.cur()
    if (current_device != start_device && current_device > 1) {
      try(grDevices::dev.off(), silent = TRUE)
    }
  }

  publish_temp_file <- function(temp_path, target_path) {
    if (!file.exists(temp_path) || file.info(temp_path)$size <= 0) {
      stop("图形设备未生成有效文件：", temp_path)
    }

    copied <- suppressWarnings(
      file.copy(temp_path, target_path, overwrite = TRUE)
    )

    if (!isTRUE(copied)) {
      extension <- tools::file_ext(target_path)
      stem <- tools::file_path_sans_ext(basename(target_path))
      alternative_path <- file.path(
        dirname(target_path),
        paste0(stem, "_", export_stamp, ".", extension)
      )

      suffix_index <- 1L
      while (file.exists(alternative_path)) {
        alternative_path <- file.path(
          dirname(target_path),
          paste0(
            stem, "_", export_stamp, "_", suffix_index, ".", extension
          )
        )
        suffix_index <- suffix_index + 1L
      }

      copied <- suppressWarnings(
        file.copy(temp_path, alternative_path, overwrite = FALSE)
      )

      if (!isTRUE(copied)) {
        stop(
          "无法将图形文件复制到结果目录。请关闭正在占用该文件的程序：",
          target_path
        )
      }

      warning(
        "目标文件可能正在被占用，已改为保存：",
        alternative_path,
        call. = FALSE
      )
      target_path <- alternative_path
    }

    unlink(temp_path)
    normalizePath(target_path, winslash = "/", mustWork = FALSE)
  }

  svg_temp <- tempfile(pattern = "air_env_", fileext = ".svg")
  svglite::svglite(
    svg_temp,
    width = width_in,
    height = height_in,
    bg = "white"
  )
  print(plot_object)
  grDevices::dev.off()
  svg_file <- publish_temp_file(
    svg_temp,
    paste0(filename_prefix, ".svg")
  )

  pdf_temp <- tempfile(pattern = "air_env_", fileext = ".pdf")
  cairo_start_device <- grDevices::dev.cur()
  cairo_succeeded <- tryCatch(
    {
      grDevices::cairo_pdf(
        pdf_temp,
        width = width_in,
        height = height_in,
        family = "Arial",
        bg = "white"
      )
      print(plot_object)
      grDevices::dev.off()
      TRUE
    },
    error = function(error_condition) {
      close_new_device(cairo_start_device)
      warning(
        "Cairo PDF 导出失败，将改用 R 内置 PDF 设备：",
        conditionMessage(error_condition),
        call. = FALSE
      )
      FALSE
    }
  )

  if (!cairo_succeeded) {
    if (file.exists(pdf_temp)) {
      unlink(pdf_temp)
    }
    grDevices::pdf(
      pdf_temp,
      width = width_in,
      height = height_in,
      family = "sans",
      bg = "white",
      useDingbats = FALSE
    )
    print(plot_object)
    grDevices::dev.off()
  }

  pdf_file <- publish_temp_file(
    pdf_temp,
    paste0(filename_prefix, ".pdf")
  )

  tiff_temp <- tempfile(pattern = "air_env_", fileext = ".tiff")
  ragg::agg_tiff(
    tiff_temp,
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    compression = "lzw",
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()
  tiff_file <- publish_temp_file(
    tiff_temp,
    paste0(filename_prefix, ".tiff")
  )

  png_temp <- tempfile(pattern = "air_env_", fileext = ".png")
  ragg::agg_png(
    png_temp,
    width = width_in,
    height = height_in,
    units = "in",
    res = dpi,
    background = "white"
  )
  print(plot_object)
  grDevices::dev.off()

  png_file <- publish_temp_file(
    png_temp,
    paste0(filename_prefix, ".png")
  )

  c(
    SVG = svg_file,
    PDF = pdf_file,
    TIFF = tiff_file,
    PNG = png_file
  )
}

figure_files <- list(
  Air_temperature = save_publication_figure(
    temperature_plot,
    figure_prefixes[["Air_temperature"]],
    width_mm = 88,
    height_mm = 82,
    dpi = 600
  ),
  Relative_humidity = save_publication_figure(
    relative_humidity_plot,
    figure_prefixes[["Relative_humidity"]],
    width_mm = 88,
    height_mm = 82,
    dpi = 600
  ),
  DLI = save_publication_figure(
    dli_plot,
    figure_prefixes[["DLI"]],
    width_mm = 88,
    height_mm = 82,
    dpi = 600
  )
)

# ---------- 9. 导出统计结果 ----------
writexl::write_xlsx(
  list(
    Descriptive_Mean_SE = descriptive_summary,
    Fixed_Effects_TypeIII = type3_fixed_effects,
    Fixed_Coefficients = fixed_coefficients,
    EMM_All_Treatments = all_emmeans,
    Tukey_Position_by_Stage = tukey_position_by_stage,
    CLD_Position_by_Stage = cld_position_by_stage,
    Tukey_Stage_by_Position = tukey_stage_by_position,
    Tukey_All_Treatments = tukey_all_treatments,
    CLD_All_Treatments = cld_all_treatments,
    Model_Diagnostics = model_diagnostics,
    Stage_Date_Counts = stage_date_counts,
    Cell_Counts = cell_counts,
    Missing_Audit = missing_audit,
    Plot_Source_Data = plot_data
  ),
  path = result_file
)

message("分析完成。")
message("统计结果：", result_file)
message("模型对象：", model_file)
for (metric_name in names(figure_files)) {
  message(
    metric_name, " 图形文件：\n",
    paste(
      names(figure_files[[metric_name]]),
      figure_files[[metric_name]],
      sep = ": ",
      collapse = "\n"
    )
  )
}

# 在 RStudio 中依次显示三张独立图片：
print(temperature_plot)
print(relative_humidity_plot)
print(dli_plot)
