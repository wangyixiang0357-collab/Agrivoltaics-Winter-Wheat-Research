library(readxl)
library(ggplot2)
library(agricolae)
library(dplyr)
library(tidyr)
library(stringr)
library(tibble)
library(grid)
library(car)
library(geomtextpath)  # 将完整生育期名称沿外圈弧线排版

# =========================================================
# 三生育期 Pnmax 径向分组柱状图
# 每个生育期内：单因素 ANOVA + Tukey HSD 显著性
# 图中央留白，不显示三因素 ANOVA 结果
# =========================================================

# =========================
# 1. 参数设置
# =========================
file_path <- "C:/Users/Yixiang Wang/Desktop/光伏农业小麦相关/2025-2026生长季/小麦光合生理/光响应/光合数据计算/光响应曲线.xlsx"
sheet_pick <- "sheet1"
metric_pick <- "Rd"
export_files <- FALSE  # TRUE：另外导出 PDF、SVG 和 600 dpi PNG

stage_levels <- c("Erecting stage", "Jointing stage", "Anthesis stage")
stage_labels <- c(
  "Erecting stage" = "Erecting stage",
  "Jointing stage" = "Jointing stage",
  "Anthesis stage" = "Anthesis stage"
)

fert_levels <- c("CK", "F", "MF", "OF", "FS")
plot_group_levels <- c("CKUP", "CKBP", "FUP", "FBP", "MFUP", "MFBP", "OFUP", "OFBP", "FS")

fert_cols <- c(
  CK = "#7F7F7F",
  F  = "#0072B2",
  MF = "#009E73",
  OF = "#D55E00",
  FS = "#F0E442"
)

stage_cols <- c(
  "Erecting stage" = "#E8D8F6",
  "Jointing stage" = "#DDECFB",
  "Anthesis stage" = "#FFF0C2"
)

bar_width <- 0.38
inner_gap <- bar_width * 0.05
outer_gap <- bar_width * 0.30
group_span <- 2 * bar_width + inner_gap + outer_gap
stage_gap_ratio <- 0.09  # 三处扇区空隙相等，均为平均单个扇区宽度的 9%

# =========================
# 2. 读入与整理数据
# =========================
dat <- read_excel(file_path, sheet = sheet_pick) %>%
  mutate(
    Stage = str_squish(as.character(Stage)),
    Fertilization = str_squish(as.character(Fertilization)),
    Location = str_squish(as.character(Location)),
    Pmax = as.numeric(.data[[metric_pick]]),
    Fertilization = case_when(
      Fertilization == "FS" ~ "FS",
      Fertilization %in% c("CK", "F", "MF", "OF") ~ Fertilization,
      TRUE ~ Fertilization
    ),
    Location = case_when(
      Fertilization == "FS" ~ "FS",
      TRUE ~ Location
    ),
    PlotGroup = case_when(
      Fertilization == "FS" ~ "FS",
      TRUE ~ paste0(Fertilization, Location)
    )
  ) %>%
  filter(
    Stage %in% stage_levels,
    Fertilization %in% fert_levels,
    PlotGroup %in% plot_group_levels,
    !is.na(Pmax)
  ) %>%
  mutate(
    Stage = factor(Stage, levels = stage_levels),
    Fertilization = factor(Fertilization, levels = fert_levels),
    Location = factor(Location, levels = c("UP", "BP", "FS")),
    PlotGroup = factor(PlotGroup, levels = plot_group_levels)
  )

if (nrow(dat) == 0) {
  stop("没有读取到有效 Pmax 数据，请检查 sheet_pick、metric_pick 或字段名称。")
}

# =========================
# 3. 均值、标准差与每期 Tukey HSD 显著性
# =========================
sum_dat <- dat %>%
  group_by(Stage, Fertilization, Location, PlotGroup) %>%
  summarise(
    mean = mean(Pmax, na.rm = TRUE),
    sd = sd(Pmax, na.rm = TRUE),
    n = n(),
    .groups = "drop"
  )

group_n <- dat %>%
  count(Stage, PlotGroup)

if (any(group_n$n < 2)) {
  print(group_n)
  stop("至少有一个生育期-处理组合的数据点少于 2 个，无法进行 Tukey HSD 显著性分析。")
}

sig_dat <- dat %>%
  group_by(Stage) %>%
  group_modify(~ {
    aov_model <- aov(Pmax ~ PlotGroup, data = .x)
    tukey_hsd <- HSD.test(
      aov_model,
      "PlotGroup",
      alpha = 0.05,
      group = TRUE,
      console = FALSE,
      unbalanced = TRUE
    )

    tukey_hsd$groups %>%
      rownames_to_column("PlotGroup") %>%
      select(PlotGroup, groups)
  }) %>%
  ungroup()

sum_dat <- sum_dat %>%
  left_join(sig_dat, by = c("Stage", "PlotGroup"))

# =========================
# 4. 径向位置计算
# =========================
pos_list <- list()
sector_list <- list()

for (st in stage_levels) {
  stage_groups <- sum_dat %>%
    filter(Stage == st) %>%
    distinct(Fertilization, Location, PlotGroup) %>%
    mutate(
      Fertilization = as.character(Fertilization),
      Location = as.character(Location),
      PlotGroup = as.character(PlotGroup)
    )

  fert_use <- fert_levels[fert_levels %in% stage_groups$Fertilization]
  fert_centers <- seq_along(fert_use) * group_span

  pos_stage <- tibble(
    Fertilization = fert_use,
    x_center = fert_centers
  ) %>%
    left_join(stage_groups, by = "Fertilization") %>%
    mutate(
      x_pos = case_when(
        Location == "UP" ~ x_center - (bar_width + inner_gap) / 2,
        Location == "BP" ~ x_center + (bar_width + inner_gap) / 2,
        Location == "FS" ~ x_center
      )
    ) %>%
    arrange(match(PlotGroup, plot_group_levels))

  pos_list[[st]] <- tibble(
    Stage = factor(st, levels = stage_levels),
    PlotGroup = factor(pos_stage$PlotGroup, levels = plot_group_levels),
    x_pos = pos_stage$x_pos
  )

  sector_list[[st]] <- tibble(
    Stage = factor(st, levels = stage_levels),
    xmin = min(pos_stage$x_pos - bar_width / 2) - outer_gap,
    xmax = max(pos_stage$x_pos + bar_width / 2) + outer_gap,
    x_center = mean(range(pos_stage$x_pos))
  )

}

pos_dat <- bind_rows(pos_list)
sector_dat <- bind_rows(sector_list)

# 先按原有柱间距生成每期扇区，再统一平移；首尾闭合处也留同样空隙。
sector_width <- sector_dat$xmax - sector_dat$xmin
stage_gap <- mean(sector_width) * stage_gap_ratio
sector_start <- c(0, cumsum(head(sector_width, -1) + stage_gap))
sector_dat$shift <- sector_start - sector_dat$xmin
pos_dat <- pos_dat %>%
  left_join(sector_dat %>% select(Stage, shift), by = "Stage") %>%
  mutate(x_pos = x_pos + shift) %>%
  select(-shift)
sector_dat <- sector_dat %>%
  mutate(xmin = xmin + shift,
         xmax = xmax + shift,
         x_center = x_center + shift) %>%
  select(-shift)

sum_dat <- sum_dat %>%
  left_join(pos_dat, by = c("Stage", "PlotGroup")) %>%
  mutate(
    fill_col = ifelse(Location == "UP", "white", fert_cols[as.character(Fertilization)]),
    label_y = mean + sd
  )

data_y_max <- max(sum_dat$mean + sum_dat$sd, na.rm = TRUE)
y_axis_max <- 5.3
y_axis_step <- 1
axis_breaks <- seq(0, y_axis_max, by = y_axis_step)
y_grid_breaks <- axis_breaks[-c(1, length(axis_breaks))]

inner_hole <- y_axis_max * 0.42
stage_ring_inner <- y_axis_max * 1.08
stage_ring_outer <- y_axis_max * 1.20
stage_label_y <- (stage_ring_inner + stage_ring_outer) / 2
sig_offset <- y_axis_max * 0.06

x_min_plot <- min(sector_dat$xmin) - stage_gap / 2
x_max_plot <- max(sector_dat$xmax) + stage_gap / 2

sum_dat <- sum_dat %>%
  mutate(
    sig_y = mean + sd + sig_offset
  )

sector_dat <- sector_dat %>%
  mutate(
    stage_label = stage_labels[as.character(Stage)],
    fill_col = stage_cols[as.character(Stage)]
  )

# 直接使用拔节期左边框作为径向刻度轴，刻度线朝扇区内部。
axis_x <- sector_dat$xmin[2]
# 将该边框转到 12 点方向，使共用的径向刻度轴与页面 Y 轴平行。
# coord_polar() 的 start 以 12 点为 0，x 坐标在整圈中的比例决定旋转量。
polar_start <- -2 * pi * (axis_x - x_min_plot) / (x_max_plot - x_min_plot)
axis_tick_len <- stage_gap * 0.18

axis_tick_dat <- tibble(
  x = axis_x,
  xend = axis_x + axis_tick_len,
  y = axis_breaks,
  yend = axis_breaks,
  label = sprintf("%.0f", axis_breaks),
  label_x = axis_x - axis_tick_len * 1.2
)

# 每期名称保持为完整字符串；两点构成的水平路径在极坐标下成为弧线。
stage_text_dat <- do.call(rbind, lapply(seq_len(nrow(sector_dat)), function(i) {
  z <- sector_dat[i, ]
  inset <- 0.08 * (z$xmax - z$xmin)
  data.frame(Stage = rep(as.character(z$Stage), 2),
             stage_label = rep(z$stage_label, 2),
             x = c(z$xmin + inset, z$xmax - inset),
             y = rep(stage_label_y, 2))
}))

# =========================
# 5. 绘图
# =========================
p <- ggplot() +
  geom_rect(
    data = sector_dat,
    aes(
      xmin = xmin,
      xmax = xmax,
      ymin = 0,
      ymax = stage_ring_outer,
      fill = fill_col
    ),
    inherit.aes = FALSE,
    color = NA,
    alpha = 0.25,
    show.legend = FALSE
  ) +
  geom_hline(
    yintercept = y_grid_breaks,
    color = "grey65",
    linetype = "dashed",
    linewidth = 0.45
  ) +
  geom_segment(
    data = axis_tick_dat,
    aes(x = x, xend = xend, y = y, yend = yend),
    inherit.aes = FALSE,
    color = "black",
    linewidth = 0.65
  ) +
  geom_text(
    data = axis_tick_dat,
    aes(x = label_x, y = y, label = label),
    inherit.aes = FALSE,
    family = "Arial",
    fontface = "bold",
    size = 3.2,
    hjust = 1,
    vjust = 0.5
  ) +
  geom_col(
    data = sum_dat,
    aes(
      x = x_pos,
      y = mean,
      fill = fill_col,
      color = Fertilization
    ),
    width = bar_width,
    linewidth = 0.9,
    show.legend = FALSE
  ) +
  geom_errorbar(
    data = sum_dat,
    aes(
      x = x_pos,
      ymin = pmax(mean - sd, 0),
      ymax = mean + sd
    ),
    width = bar_width * 0.35,
    linewidth = 0.75,
    color = "black"
  ) +
  geom_text(
    data = sum_dat,
    aes(
      x = x_pos,
      y = sig_y,
      label = groups
    ),
    angle = 0,
    hjust = 0.5,
    size = 3.2,
    family = "Arial",
    fontface = "bold",
    vjust = 0.5
  ) +
  # 极坐标下的矩形轮廓即每期扇区的两条径向边、内弧和外弧。
  geom_rect(
    data = sector_dat,
    aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = stage_ring_inner),
    fill = NA,
    color = "black",
    linewidth = 0.7,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geom_rect(
    data = sector_dat,
    aes(
      xmin = xmin,
      xmax = xmax,
      ymin = stage_ring_inner,
      ymax = stage_ring_outer,
      fill = fill_col
    ),
    color = "black",
    linewidth = 0.7,
    alpha = 0.75,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  geomtextpath::geom_textpath(
    data = stage_text_dat,
    aes(x = x, y = y, group = Stage, label = stage_label),
    size = 4.0,
    family = "Arial",
    fontface = "bold",
    hjust = 0.5,
    vjust = 0.5,
    text_only = TRUE,
    upright = TRUE,
    inherit.aes = FALSE,
    show.legend = FALSE
  ) +
  scale_x_continuous(
    limits = c(x_min_plot, x_max_plot),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-inner_hole, stage_ring_outer * 1.05),
    breaks = y_grid_breaks,
    expand = c(0, 0)
  ) +
  scale_color_manual(values = fert_cols, guide = "none") +
  scale_fill_identity() +
  coord_polar(start = polar_start, direction = 1, clip = "off") +
  labs(
    x = NULL,
    y = NULL,
    title = expression()
  ) +
  theme_void(base_size = 14, base_family = "Arial") +
  theme(
    text = element_text(family = "Arial"),
    plot.title = element_text(
      hjust = 0.5,
      size = 18,
      face = "bold",
      margin = margin(b = 10)
    ),
    plot.margin = margin(20, 20, 20, 20)
  )

print(p)

# 如需文件，将脚本开头的 export_files 改为 TRUE。
if (export_files) {
  out_base <- file.path(dirname(dirname(file_path)),
                        paste0("三生育期_", metric_pick, "_径向分组柱状图"))
  grDevices::cairo_pdf(paste0(out_base, ".pdf"), width = 8.5,
                       height = 8.5, family = "Arial")
  print(p)
  dev.off()
  svglite::svglite(paste0(out_base, ".svg"), width = 8.5, height = 8.5)
  print(p)
  dev.off()
  ragg::agg_png(paste0(out_base, ".png"), width = 8.5, height = 8.5,
                units = "in", res = 600)
  print(p)
  dev.off()
}
