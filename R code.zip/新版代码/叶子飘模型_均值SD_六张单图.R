# 六张独立光响应图：点=3个重复的均值，误差棒=SD，曲线=对均值重新拟合的叶子飘模型。
# 正常运行需安装 readxl；在 RStudio 中运行时选择原始 Excel 文件即可。

input_csv <- Sys.getenv("LIGHT_RESPONSE_CSV", "") # 仅供已整理的长表复核使用
input_file <- Sys.getenv("LIGHT_RESPONSE_XLSX", "")
if (!nzchar(input_file)) input_file <- file.choose()
out_dir <- Sys.getenv("LIGHT_RESPONSE_OUTDIR", "")
if (!nzchar(out_dir)) out_dir <- file.path(Sys.getenv("USERPROFILE"),
                                            "Desktop", "Ye_mean_SD_plots")
if (!dir.exists(out_dir) && !dir.create(out_dir, recursive = TRUE))
  stop("无法创建输出目录：", out_dir)
# 某些Windows R环境不能直接把图形设备打开在中文路径；先在临时英文路径作图。
render_dir <- file.path(tempdir(), "ye_mean_sd_plots")
dir.create(render_dir, recursive = TRUE, showWarnings = FALSE)

treatment_colours <- c(
  CK = "#8C8C8C", F = "#0072B2", MF = "#009E73",
  OF = "#E66101", FS = "#F0E442"
)
treatment_shapes <- c(CK = 16, F = 17, MF = 15, OF = 1, FS = 8)
legend_order <- c("CK", "F", "OF", "MF", "FS")
stage_titles <- c("Erecting stage", "Jointing stage", "Anthesis stage")

# 读取原表：每个样品列是一条独立重复；FS在开花期左图中作为独立处理显示。
if (nzchar(input_csv)) {
  dat <- read.csv(input_csv, stringsAsFactors = FALSE, fileEncoding = "UTF-8")
} else {
  if (!requireNamespace("readxl", quietly = TRUE))
    stop("请先安装 readxl：install.packages('readxl')")
  raw <- as.data.frame(readxl::read_excel(
    input_file, sheet = 1, col_names = FALSE, col_types = "text",
    .name_repair = "minimal"), stringsAsFactors = FALSE)
  headers <- which(trimws(ifelse(is.na(raw[[1]]), "", raw[[1]])) == "Qin")
  if (length(headers) != 3L) stop("预期找到3个生育期的 Qin 表头。")
  rows <- list()
  for (s in seq_along(headers)) {
    h <- headers[s]
    last <- if (s < length(headers)) headers[s + 1L] - 2L else nrow(raw)
    rr <- seq.int(h + 1L, last)
    x <- suppressWarnings(as.numeric(raw[[1]][rr]))
    for (j in 2:ncol(raw)) {
      label <- trimws(raw[[j]][h])
      if (is.na(label) || !nzchar(label)) next
      if (label == "FS") {
        position <- "BP"; treatment <- "FS"
      } else {
        m <- regmatches(label, regexec("^(CK|MF|OF|F)(BP|UP)[0-9]*$", label))[[1]]
        if (length(m) != 3L) stop("无法识别样品列名：", label)
        treatment <- m[2]; position <- m[3]
      }
      y <- suppressWarnings(as.numeric(raw[[j]][rr]))
      if (any(!is.finite(x)) || any(!is.finite(y)))
        stop("发现缺失或非数值观测：生育期", s, "，Excel第", j, "列。")
      rows[[length(rows) + 1L]] <- data.frame(
        Stage = s, Position = position, Treatment = treatment,
        PPFD = x, Pn = y)
    }
  }
  dat <- do.call(rbind, rows)
}

# 每个光强下先求均值和样本标准差；不平均各重复的拟合参数。
groups <- split(dat, interaction(dat$Stage, dat$Position,
                                 dat$Treatment, dat$PPFD, drop = TRUE))
avg <- do.call(rbind, lapply(groups, function(z) data.frame(
  Stage = z$Stage[1], Position = z$Position[1],
  Treatment = z$Treatment[1], PPFD = z$PPFD[1],
  Mean = mean(z$Pn), SD = sd(z$Pn), n = nrow(z)
)))
row.names(avg) <- NULL
if (any(avg$n != 3L)) stop("某些生育期×位置×处理×光强并非3个重复，请核对原表。")

# 叶子飘（双曲线修正）模型：Pn = alpha*I*(1-beta*I)/(1+gamma*I)-Rd。
ye <- function(I, p) p[1] * I * (1 - p[2] * I) / (1 + p[3] * I) - p[4]
fit_ye <- function(z) {
  x <- z$PPFD; y <- z$Mean; imax <- max(x)
  low <- x <= 150
  alpha0 <- if (sum(low) >= 3L) unname(coef(lm(y[low] ~ x[low]))[2]) else 0.05
  alpha0 <- max(0.008, min(0.14, alpha0))
  rd0 <- max(0.05, -y[which.min(x)])
  lower <- c(0.0001, 1e-8, 1e-6, 0)
  upper <- c(0.25, 0.98 / imax, 0.02, max(8, 2.5 * rd0 + 1))
  starts <- expand.grid(beta = c(0.2, 0.55, 0.85) * upper[2],
                        gamma = c(0.0002, 0.001, 0.003))
  best <- NULL
  for (k in seq_len(nrow(starts))) {
    p0 <- c(alpha0, starts$beta[k], starts$gamma[k], rd0)
    fit <- tryCatch(optim(p0, function(p) sum((y - ye(x, p))^2),
                          method = "L-BFGS-B", lower = lower, upper = upper,
                          control = list(maxit = 2000, factr = 1e7,
                                         parscale = pmax(abs(p0),
                                                         0.15 * (upper - lower),
                                                         1e-6))), error = function(e) NULL)
    if (!is.null(fit) && fit$convergence == 0 && is.finite(fit$value) &&
        (is.null(best) || fit$value < best$value)) best <- fit
  }
  if (is.null(best)) stop("叶子飘模型拟合失败：", unique(z$Stage), "/",
                          unique(z$Position), "/", unique(z$Treatment))
  best$par
}

# 按参考图绘制：统一坐标、无网格、彩色曲线、均值点及±SD误差棒。
files <- c("01_Erecting_BP.png", "02_Erecting_UP.png",
           "03_Jointing_BP.png", "04_Jointing_UP.png",
           "05_Anthesis_BP_FS.png", "06_Anthesis_UP.png")
for (s in 1:3) for (pos in c("BP", "UP")) {
  panel <- (s - 1L) * 2L + match(pos, c("BP", "UP"))
  z <- avg[avg$Stage == s & avg$Position == pos, ]
  if (!nrow(z)) stop("缺少绘图数据：", s, "/", pos)
  present <- legend_order[legend_order %in% z$Treatment]

  draw_panel <- function() {
    par(mar = c(4.2, 4.7, 1.2, 0.7), mgp = c(2.4, 0.65, 0),
      tcl = 0.25, family = "Arial", xaxs = "i", yaxs = "i") # 正值：刻度线朝绘图区内
  plot(NA, xlim = c(-50, 1850), ylim = c(-6, 24),
       xaxt = "n", yaxt = "n", xlab = "", ylab = "", bty = "o")
  axis(1, at = seq(0, 1800, 300), labels = seq(0, 1800, 300),
       cex.axis = 0.85, lwd = 0.7)
  axis(2, at = seq(-6, 24, 6), labels = seq(-6, 24, 6),
       las = 1, cex.axis = 0.85, lwd = 0.7)
  mtext(expression("Photosynthetic photon flux density ("*mu*"mol photons m"^{-2}*" s"^{-1}*")"),
        side = 1, line = 2.6, cex = 0.82, font = 2)
  mtext(expression("Net photosynthetic rate ("*mu*"mol CO"[2]*" m"^{-2}*" s"^{-1}*")"),
        side = 2, line = 3.1, cex = 0.82, font = 2)

  for (tr in present) {
    v <- z[z$Treatment == tr, ]
    v <- v[order(v$PPFD), ]
    col <- treatment_colours[tr]
    err_col <- grDevices::adjustcolor(col, alpha.f = 0.55)
    segments(v$PPFD, v$Mean - v$SD, v$PPFD, v$Mean + v$SD,
             col = err_col, lwd = 0.75)
    segments(v$PPFD - 12, v$Mean - v$SD, v$PPFD + 12, v$Mean - v$SD,
             col = err_col, lwd = 0.75)
    segments(v$PPFD - 12, v$Mean + v$SD, v$PPFD + 12, v$Mean + v$SD,
             col = err_col, lwd = 0.75)
    p <- fit_ye(v)
    gx <- seq(0, 1800, length.out = 400)
    lines(gx, ye(gx, p), col = col, lwd = 1.8)
    points(v$PPFD, v$Mean, col = col, pch = treatment_shapes[tr],
           cex = if (tr == "FS") 0.95 else 0.75, lwd = 1.1)
  }
  text(25, 22.7, letters[panel], adj = c(0, 1), font = 2, cex = 1.1)
  title <- paste0(if (s == 3L && pos == "BP") "BP+FS" else pos,
                  ", ", stage_titles[s])
  text(1800, 22.7, title, adj = c(1, 1), font = 2, cex = 0.94)
  legend("bottomright", legend = present,
         col = treatment_colours[present], pch = treatment_shapes[present],
         lty = 1, lwd = 1.6, pt.cex = 0.85, cex = 0.88,
         seg.len = 1.2, x.intersp = 0.5, y.intersp = 0.86, bty = "n")
    box(lwd = 0.7)
  }
  png(file.path(render_dir, files[panel]), width = 120, height = 100,
      units = "mm", res = 600, type = "cairo-png", bg = "white")
  draw_panel()
  dev.off()
  pdf_file <- sub("\\.png$", ".pdf", files[panel])
  grDevices::cairo_pdf(file.path(render_dir, pdf_file),
                       width = 120 / 25.4, height = 100 / 25.4,
                       family = "Arial")
  draw_panel()
  dev.off()
  svg_file <- sub("\\.png$", ".svg", files[panel])
  if (requireNamespace("svglite", quietly = TRUE)) {
    svglite::svglite(file.path(render_dir, svg_file),
                     width = 120 / 25.4, height = 100 / 25.4)
  } else {
    grDevices::svg(file.path(render_dir, svg_file),
                   width = 120 / 25.4, height = 100 / 25.4)
  }
  draw_panel()
  dev.off()
}
all_files <- unlist(lapply(files, function(f)
  c(f, sub("\\.png$", ".pdf", f), sub("\\.png$", ".svg", f))))
if (!all(file.copy(file.path(render_dir, all_files),
                   file.path(out_dir, all_files), overwrite = TRUE)))
  stop("图片已绘制，但复制到输出目录失败；请检查目录权限或中文路径。")
message("已生成六张单图：", out_dir)
